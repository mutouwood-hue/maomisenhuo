/* badge_ui_spec.h —— 由「吧唧渲染参考.html（交互规范）」自动生成，请勿手改。版本 0.3.0 */
#pragma once
#include <stdint.h>

/* 屏幕：坐标原点左上角，中心 (233,233)。LVGL：lv_obj_align(o, LV_ALIGN_CENTER, X-233, Y-233) */
#define BADGE_SCR_W 466
#define BADGE_SCR_H 466
#define BADGE_CX 233
#define BADGE_CY 233
#define BADGE_SAFE_R 212  /* 按钮和文字外框四角都在这个半径内 */

/* 颜色：RGB888 与 RGB565 */
#define BC_BG 0x000000
#define BC_BG_565 0x0000
#define BC_TEXT 0xFFF4E0
#define BC_TEXT_565 0xFFBC
#define BC_SUB 0xB9A88F
#define BC_SUB_565 0xBD51
#define BC_DIM 0x6E6253
#define BC_DIM_565 0x6B0A
#define BC_ACCENT 0xF0A35E
#define BC_ACCENT_565 0xF50B
#define BC_ACCENTDK 0x8A5A2E
#define BC_ACCENTDK_565 0x8AC5
#define BC_CARD 0x241D17
#define BC_CARD_565 0x20E2
#define BC_CARDHI 0x3A2F25
#define BC_CARDHI_565 0x3964
#define BC_LINE 0x4A3E33
#define BC_LINE_565 0x49E6
#define BC_WARN 0xFF6B6B
#define BC_WARN_565 0xFB4D
#define BC_OK 0x7ED492
#define BC_OK_565 0x7EB2
#define BC_COIN 0xF6C85F
#define BC_COIN_565 0xF64B
#define BC_BT 0x7FB6FF
#define BC_BT_565 0x7DBF
#define BC_FOOD 0xF0BF73
#define BC_FOOD_565 0xF5EE
#define BC_MOOD 0xF29AA8
#define BC_MOOD_565 0xF4D5
#define BC_CLEAN 0x8FC7E0
#define BC_CLEAN_565 0x8E3C
#define BC_ENERGY 0xA8D88E
#define BC_ENERGY_565 0xAED1
#define BC_HEALTH 0xFF8A8A
#define BC_HEALTH_565 0xFC51
#define BC_RINGSLEEP 0x8F8BC4
#define BC_RINGSLEEP_565 0x8C58
#define BC_RINGHOME 0xF0BF73
#define BC_RINGHOME_565 0xF5EE
#define BC_RINGCOMMUTE 0x9BB8CC
#define BC_RINGCOMMUTE_565 0x9DD9
#define BC_RINGWORK 0x6FA08B
#define BC_RINGWORK_565 0x6D11
#define BC_RINGOUT 0xE8907A
#define BC_RINGOUT_565 0xEC8F
#define BC_RINGTRACK 0x2A2236
#define BC_RINGTRACK_565 0x2906

/* 字体：思源黑体 Medium 子集，4bpp（见 fonts/） */
#define BF_F16_SIZE 16
#define BF_F16_LINE_H 22
#define BF_F20_SIZE 20
#define BF_F20_LINE_H 28
#define BF_F24_SIZE 24
#define BF_F24_LINE_H 32
#define BF_N40_SIZE 40
#define BF_N40_LINE_H 48

/* 时间参数（毫秒 / 像素） */
#define BT_TAP_MAX_MS 300
#define BT_TAP_MOVE_MAX 12
#define BT_LONG_PRESS_MS 600
#define BT_SWIPE_MIN_PX 50
#define BT_SWIPE_MAX_MS 500
#define BT_TRANSITION_MS 220
#define BT_TOAST_MS 1800
#define BT_BUBBLE_MS 3500
#define BT_PLAY_TO_COMP_MS 10000
#define BT_COMP_TO_AOD_MS 30000
#define BT_AOD_REDRAW_MS 60000
#define BT_CARE_COOLDOWN_MS 4000
#define BT_PET_COOLDOWN_MS 2000
#define BT_BITE_GAP_MS 450
#define BT_VOICE_MAX_MS 8000
#define BT_VOICE_SILENCE_MS 1200
#define BT_VOICE_THINK_MS 600
#define BT_MEET_TIMEOUT_MS 30000
#define BT_TAP_CONFIRM_TIMEOUT_MS 20000
#define BT_MEET_DONE_MS 4000
#define BT_QUIRK_MIN_MS 35000
#define BT_QUIRK_MAX_MS 80000
#define BT_QUIRK_IDLE_MS 9000
#define BT_SLEEP_HOLD_MS 1500
#define BT_SLEEP_DEMO_MS 6000
#define BT_PLAY_POUNCE_SPEED 900
#define BT_PLAY_POUNCE_GAP_MS 700
#define BT_PLAY_TIMEOUT_MS 25000
#define BT_BOOT_MS 1500
#define BT_CALL_HOME_MS 1800000

/* 阈值 */
#define BTH_LOW_STAT 30
#define BTH_FULL 95
#define BTH_MOOD_FULL 98
#define BTH_MIN_ENERGY_PLAY 10
#define BTH_BAT_NO_WAKE 20
#define BTH_BAT_CRITICAL 5

/* 工作模式 */
#define BM_DESK_FPS 30
#define BM_DESK_RES 466
#define BM_DESK_BRIGHT_PCT 100
#define BM_PLAY_FPS 30
#define BM_PLAY_RES 233
#define BM_PLAY_BRIGHT_PCT 100
#define BM_COMP_FPS 12
#define BM_COMP_RES 466
#define BM_COMP_BRIGHT_PCT 100
#define BM_AOD_FPS 0
#define BM_AOD_RES 466
#define BM_AOD_BRIGHT_PCT 35
#define BM_OFF_FPS 0
#define BM_OFF_RES 0
#define BM_OFF_BRIGHT_PCT 0

/* M1 打样板外设（实测核查）：1 = 板上有，0 = 没有、需外接 */
#define BADGE_HW_MOTOR 0   /* 震动马达：板上没有，必须外接；为 0 时震动改为边缘光圈 + 提示音 */
#define BADGE_HW_SPEAKER 1 /* 喇叭：ES8311 + 功放通路齐全，开机调用板级喇叭初始化；喇叭本体待确认，按外接 8Ω 准备 */
#define BADGE_HW_IMU 1     /* QMI8658 在 0x6b；板级支持包不管（BSP_CAPS_IMU = 0），需加依赖 waveshare/qmi8658 */
#define BADGE_IMU_I2C_ADDR 0x6b

/* LVGL：M1 固件锁定 v9.5.0，只用 lvgl/badge_screens_v9.c。建议 idf_component.yml 依赖收紧为 lvgl/lvgl: '9.*'（现为 >=8,<10，重解析落到 v8 会编译失败或颜色错位） */
#define BADGE_LVGL_MAJOR 9

/* 触摸（CST9217，0x5a）：板级支持包默认 不交换轴、X/Y 镜像、旋转 0°；镜像由 esp_lcd_touch 软件完成（x = x_max - x），CST9217 驱动本身不支持方向设置。电容屏出厂已标定，不需要标定代码 */
#define BADGE_TOUCH_SWAP_XY 0
#define BADGE_TOUCH_MIRROR_X 1
#define BADGE_TOUCH_MIRROR_Y 1
#define BADGE_TOUCH_MAX 465  /* x_max 传 466 时镜像结果为 1..466，会多出越界值 466；读坐标后钳到 0..465 */
static inline int16_t badge_touch_clamp(int16_t v){ return v < 0 ? 0 : (v > BADGE_TOUCH_MAX ? BADGE_TOUCH_MAX : v); }
#define BADGE_HW_NFC 0     /* NFC：板上没有，必须外接；为 0 时遇见确认走 meet_scan（扫码） */
#define BADGE_SPK_CODEC_ADDR 0x18
#define BADGE_SPK_PA_GPIO 46  /* 功放使能：播放前拉高，播完 200ms 拉低 */
#define BADGE_HAPTIC_FALLBACK_RING_R 227
#define BADGE_HAPTIC_FALLBACK_RING_W 6
#define BADGE_HAPTIC_FALLBACK_MS 320  /* 无马达：外圈亮一圈 + 提示音 */

/* 震动节奏（毫秒：震, 停, 震 …），以 0 结尾 */
static const uint16_t BADGE_HAPTIC_MEET[] = { 80, 80, 80, 0 };
static const uint16_t BADGE_HAPTIC_CARE_DONE[] = { 40, 0 };
static const uint16_t BADGE_HAPTIC_WAKE[] = { 30, 0 };
static const uint16_t BADGE_HAPTIC_ERROR[] = { 20, 60, 20, 0 };

/* 提示音（数据见 sounds/badge_sounds.c，16kHz 16 位单声道） */
typedef enum {
  SND_PET = 0, /* meow_short */
  SND_CARE_DONE = 1, /* meow_happy */
  SND_MEET = 2, /* chime */
  SND_WAKE = 3, /* blip */
  SND_ERROR = 4, /* bonk */
} badge_snd_t;

/* 照料数值（与 App 3.3 一致；吧唧先本地显示，连上手机由 App 正式结算） */
typedef struct { int8_t food, mood, clean, energy, health; int8_t growth; int8_t coins; uint8_t steps; } badge_care_t;
static const badge_care_t CARE_PET = { 0, 9, 0, 0, 0, 3, 0, 1 }; /* 摸摸 */
static const badge_care_t CARE_FEED = { 25, 3, -2, 0, 0, 8, -3, 3 }; /* 喂食 */
static const badge_care_t CARE_WATER = { 0, 3, 0, 6, 0, 4, 0, 3 }; /* 喝水 */
static const badge_care_t CARE_PLAY = { -3, 12, 0, -5, 0, 8, 0, 5 }; /* 逗猫 */
static const badge_care_t CARE_SLEEP = { -4, 0, 0, 35, 2, 6, 0, 1 }; /* 睡觉 */

/* 上行事件（吧唧 → App，BLE 队列，离线最多缓存 200 条 = 1.6KB；缓冲区用文件级 static，不要放任务栈上） */
typedef enum {
  EVT_PET = 1, /* 摸摸；a=—；b=— */
  EVT_FEED = 2, /* 喂食完成；a=口数；b=— */
  EVT_WATER = 3, /* 喝水完成；a=口数；b=— */
  EVT_PLAY = 4, /* 逗猫完成；a=扑的次数；b=— */
  EVT_SLEEP = 5, /* 睡觉完成；a=—；b=— */
  EVT_CARE_CANCEL = 6, /* 照料中途取消；a=照料编号；b=— */
  EVT_VOICE_CMD = 7, /* 命中离线命令词；a=命令词编号；b=— */
  EVT_VOICE_FREE = 8, /* 自由对话（经手机）；a=意图编号；b=— */
  EVT_QUIRK_CATCH = 9, /* 接住怪行为；a=怪行为编号；b=— */
  EVT_MEET = 10, /* 遇见并确认；a=0 碰一碰 / 1 扫码；b=对方短编号 */
  EVT_CALL_HOME = 11, /* 叫小猫回家；a=地点编号；b=— */
  EVT_WAKE = 12, /* 唤醒；a=0 抬起 / 1 触摸 / 2 唤醒词；b=— */
  EVT_FACE = 13, /* 切换表盘；a=表盘编号；b=— */
  EVT_SETTING = 14, /* 改设置；a=设置项；b=新值 */
} badge_evt_type_t;
typedef struct __attribute__((packed)) { uint32_t ts; uint8_t type; uint8_t a; int16_t b; } badge_evt_t; /* 8 字节 */

/* 离线命令词编号（ESP-SR 命令词表顺序） */
#define VCMD_1 1 /* 小橘过来 */
#define VCMD_2 2 /* 摸摸 */
#define VCMD_3 3 /* 吃饭啦 */
#define VCMD_4 4 /* 喝水啦 */
#define VCMD_5 5 /* 陪我玩 */
#define VCMD_6 6 /* 去睡觉 */
#define VCMD_7 7 /* 晚安 */
#define VCMD_8 8 /* 早上好 */
#define VCMD_9 9 /* 你好 */
#define VCMD_10 10 /* 真乖 */
#define VCMD_11 11 /* 想你了 */
#define VCMD_12 12 /* 我累了 */
#define VCMD_13 13 /* 我回来了 */
#define VCMD_14 14 /* 我出门了 */
#define VCMD_15 15 /* 看看状态 */
#define VCMD_16 16 /* 换个表盘 */
#define VCMD_17 17 /* 小橘 */

/* 画面元素坐标：UI_<画面>_<元素>_X / _Y / _W / _H / _R */
/* main_a：主表盘 A · 只有小猫 */
#define UI_MAIN_A_CAT_DIST 90
#define UI_MAIN_A_CAT_OX 0
#define UI_MAIN_A_CAT_OY 24
#define UI_MAIN_A_CAT_DIM_PCT 100
#define UI_MAIN_A_TIME_X 233
#define UI_MAIN_A_TIME_Y 70
#define UI_MAIN_A_ICO_BT_X 196
#define UI_MAIN_A_ICO_BT_Y 112
#define UI_MAIN_A_ICO_BT_OFF_X 196
#define UI_MAIN_A_ICO_BT_OFF_Y 112
#define UI_MAIN_A_ICO_BAT_X 226
#define UI_MAIN_A_ICO_BAT_Y 112
#define UI_MAIN_A_ICO_BAT_W 22
#define UI_MAIN_A_ICO_BAT_H 12
#define UI_MAIN_A_LBL_BAT_X 244
#define UI_MAIN_A_LBL_BAT_Y 112
#define UI_MAIN_A_ARC_FOOD_W 8
#define UI_MAIN_A_ARC_FOOD_R 214
#define UI_MAIN_A_ARC_FOOD_A0 119
#define UI_MAIN_A_ARC_FOOD_A1 133
#define UI_MAIN_A_ARC_MOOD_W 8
#define UI_MAIN_A_ARC_MOOD_R 214
#define UI_MAIN_A_ARC_MOOD_A0 101
#define UI_MAIN_A_ARC_MOOD_A1 115
#define UI_MAIN_A_ARC_CLEAN_W 8
#define UI_MAIN_A_ARC_CLEAN_R 214
#define UI_MAIN_A_ARC_CLEAN_A0 83
#define UI_MAIN_A_ARC_CLEAN_A1 97
#define UI_MAIN_A_ARC_ENERGY_W 8
#define UI_MAIN_A_ARC_ENERGY_R 214
#define UI_MAIN_A_ARC_ENERGY_A0 65
#define UI_MAIN_A_ARC_ENERGY_A1 79
#define UI_MAIN_A_ARC_HEALTH_W 8
#define UI_MAIN_A_ARC_HEALTH_R 214
#define UI_MAIN_A_ARC_HEALTH_A0 47
#define UI_MAIN_A_ARC_HEALTH_A1 61
#define UI_MAIN_A_ALERT_X 233
#define UI_MAIN_A_ALERT_Y 140
#define UI_MAIN_A_ALERT_R 24
#define UI_MAIN_A_HIT_CAT_X 233
#define UI_MAIN_A_HIT_CAT_Y 262
#define UI_MAIN_A_HIT_CAT_R 110
/* main_b：主表盘 B · 24 小时时间环 */
#define UI_MAIN_B_CAT_DIST 100
#define UI_MAIN_B_CAT_OX 0
#define UI_MAIN_B_CAT_OY 0
#define UI_MAIN_B_CAT_DIM_PCT 100
#define UI_MAIN_B_RING_W 18
#define UI_MAIN_B_RING_R 218
#define UI_MAIN_B_RING_R2 200
#define UI_MAIN_B_RING_W2 6
#define UI_MAIN_B_ICO_BT_X 196
#define UI_MAIN_B_ICO_BT_Y 60
#define UI_MAIN_B_ICO_BT_OFF_X 196
#define UI_MAIN_B_ICO_BT_OFF_Y 60
#define UI_MAIN_B_ICO_BAT_X 226
#define UI_MAIN_B_ICO_BAT_Y 60
#define UI_MAIN_B_ICO_BAT_W 22
#define UI_MAIN_B_ICO_BAT_H 12
#define UI_MAIN_B_LBL_BAT_X 244
#define UI_MAIN_B_LBL_BAT_Y 60
#define UI_MAIN_B_TIME_X 233
#define UI_MAIN_B_TIME_Y 398
#define UI_MAIN_B_ALERT_X 233
#define UI_MAIN_B_ALERT_Y 132
#define UI_MAIN_B_ALERT_R 24
#define UI_MAIN_B_HIT_CAT_X 233
#define UI_MAIN_B_HIT_CAT_Y 245
#define UI_MAIN_B_HIT_CAT_R 110
/* main_c：主表盘 C · 时间环 + 心动 */
#define UI_MAIN_C_CAT_DIST 100
#define UI_MAIN_C_CAT_OX 0
#define UI_MAIN_C_CAT_OY 0
#define UI_MAIN_C_CAT_DIM_PCT 100
#define UI_MAIN_C_RING_W 18
#define UI_MAIN_C_RING_R 218
#define UI_MAIN_C_RING_R2 200
#define UI_MAIN_C_RING_W2 6
#define UI_MAIN_C_ICO_BT_X 196
#define UI_MAIN_C_ICO_BT_Y 60
#define UI_MAIN_C_ICO_BT_OFF_X 196
#define UI_MAIN_C_ICO_BT_OFF_Y 60
#define UI_MAIN_C_ICO_BAT_X 226
#define UI_MAIN_C_ICO_BAT_Y 60
#define UI_MAIN_C_ICO_BAT_W 22
#define UI_MAIN_C_ICO_BAT_H 12
#define UI_MAIN_C_LBL_BAT_X 244
#define UI_MAIN_C_LBL_BAT_Y 60
#define UI_MAIN_C_TIME_X 233
#define UI_MAIN_C_TIME_Y 398
#define UI_MAIN_C_ALERT_X 233
#define UI_MAIN_C_ALERT_Y 132
#define UI_MAIN_C_ALERT_R 24
#define UI_MAIN_C_HIT_CAT_X 233
#define UI_MAIN_C_HIT_CAT_Y 245
#define UI_MAIN_C_HIT_CAT_R 110
/* aod：待机常显 */
#define UI_AOD_CAT_DIST 100
#define UI_AOD_CAT_OX 0
#define UI_AOD_CAT_OY -6
#define UI_AOD_CAT_DIM_PCT 35
#define UI_AOD_TIME_X 233
#define UI_AOD_TIME_Y 398
#define UI_AOD_HIT_WAKE_X 233
#define UI_AOD_HIT_WAKE_Y 233
#define UI_AOD_HIT_WAKE_R 233
/* care_menu：照料轮盘 */
#define UI_CARE_MENU_CAT_DIST 120
#define UI_CARE_MENU_CAT_OX 0
#define UI_CARE_MENU_CAT_OY -50
#define UI_CARE_MENU_CAT_DIM_PCT 100
#define UI_CARE_MENU_TITLE_X 233
#define UI_CARE_MENU_TITLE_Y 56
#define UI_CARE_MENU_SUB_X 233
#define UI_CARE_MENU_SUB_Y 88
#define UI_CARE_MENU_BTN_FEED_X 105
#define UI_CARE_MENU_BTN_FEED_Y 322
#define UI_CARE_MENU_BTN_FEED_R 36
#define UI_CARE_MENU_LBL_FEED_X 105
#define UI_CARE_MENU_LBL_FEED_Y 374
#define UI_CARE_MENU_BTN_WATER_X 190
#define UI_CARE_MENU_BTN_WATER_Y 352
#define UI_CARE_MENU_BTN_WATER_R 36
#define UI_CARE_MENU_LBL_WATER_X 190
#define UI_CARE_MENU_LBL_WATER_Y 404
#define UI_CARE_MENU_BTN_PLAY_X 276
#define UI_CARE_MENU_BTN_PLAY_Y 352
#define UI_CARE_MENU_BTN_PLAY_R 36
#define UI_CARE_MENU_LBL_PLAY_X 276
#define UI_CARE_MENU_LBL_PLAY_Y 404
#define UI_CARE_MENU_BTN_SLEEP_X 361
#define UI_CARE_MENU_BTN_SLEEP_Y 322
#define UI_CARE_MENU_BTN_SLEEP_R 36
#define UI_CARE_MENU_LBL_SLEEP_X 361
#define UI_CARE_MENU_LBL_SLEEP_Y 374
/* care_feed：喂食中 */
#define UI_CARE_FEED_CAT_DIST 92
#define UI_CARE_FEED_CAT_OX 0
#define UI_CARE_FEED_CAT_OY -14
#define UI_CARE_FEED_CAT_DIM_PCT 100
#define UI_CARE_FEED_PROG_W 8
#define UI_CARE_FEED_PROG_R 222
#define UI_CARE_FEED_PROG_A0 219
#define UI_CARE_FEED_PROG_A1 321
#define UI_CARE_FEED_PROG_N 3
#define UI_CARE_FEED_PROG_GAP 6
#define UI_CARE_FEED_TITLE_X 233
#define UI_CARE_FEED_TITLE_Y 62
#define UI_CARE_FEED_HINT_X 233
#define UI_CARE_FEED_HINT_Y 94
#define UI_CARE_FEED_BTN_BOWL_X 233
#define UI_CARE_FEED_BTN_BOWL_Y 376
#define UI_CARE_FEED_BTN_BOWL_R 40
/* care_water：喝水中 */
#define UI_CARE_WATER_CAT_DIST 92
#define UI_CARE_WATER_CAT_OX 0
#define UI_CARE_WATER_CAT_OY -14
#define UI_CARE_WATER_CAT_DIM_PCT 100
#define UI_CARE_WATER_PROG_W 8
#define UI_CARE_WATER_PROG_R 222
#define UI_CARE_WATER_PROG_A0 219
#define UI_CARE_WATER_PROG_A1 321
#define UI_CARE_WATER_PROG_N 3
#define UI_CARE_WATER_PROG_GAP 6
#define UI_CARE_WATER_TITLE_X 233
#define UI_CARE_WATER_TITLE_Y 62
#define UI_CARE_WATER_HINT_X 233
#define UI_CARE_WATER_HINT_Y 94
#define UI_CARE_WATER_BTN_BOWL_X 233
#define UI_CARE_WATER_BTN_BOWL_Y 376
#define UI_CARE_WATER_BTN_BOWL_R 40
/* care_play：逗猫中 */
#define UI_CARE_PLAY_CAT_DIST 86
#define UI_CARE_PLAY_CAT_OX 0
#define UI_CARE_PLAY_CAT_OY 14
#define UI_CARE_PLAY_CAT_DIM_PCT 100
#define UI_CARE_PLAY_PROG_W 8
#define UI_CARE_PLAY_PROG_R 222
#define UI_CARE_PLAY_PROG_A0 219
#define UI_CARE_PLAY_PROG_A1 321
#define UI_CARE_PLAY_PROG_N 5
#define UI_CARE_PLAY_PROG_GAP 6
#define UI_CARE_PLAY_TITLE_X 233
#define UI_CARE_PLAY_TITLE_Y 62
#define UI_CARE_PLAY_HINT_X 233
#define UI_CARE_PLAY_HINT_Y 94
/* care_sleep：哄睡 */
#define UI_CARE_SLEEP_CAT_DIST 92
#define UI_CARE_SLEEP_CAT_OX 0
#define UI_CARE_SLEEP_CAT_OY -14
#define UI_CARE_SLEEP_CAT_DIM_PCT 100
#define UI_CARE_SLEEP_TITLE_X 233
#define UI_CARE_SLEEP_TITLE_Y 62
#define UI_CARE_SLEEP_HINT_X 233
#define UI_CARE_SLEEP_HINT_Y 94
#define UI_CARE_SLEEP_BTN_MOON_X 233
#define UI_CARE_SLEEP_BTN_MOON_Y 376
#define UI_CARE_SLEEP_BTN_MOON_R 40
/* sleeping：睡着了 */
#define UI_SLEEPING_CAT_DIST 92
#define UI_SLEEPING_CAT_OX 0
#define UI_SLEEPING_CAT_OY -14
#define UI_SLEEPING_CAT_DIM_PCT 25
#define UI_SLEEPING_HINT_X 233
#define UI_SLEEPING_HINT_Y 94
#define UI_SLEEPING_ZZZ_X 300
#define UI_SLEEPING_ZZZ_Y 150
/* status：状态 */
#define UI_STATUS_NAME_X 233
#define UI_STATUS_NAME_Y 62
#define UI_STATUS_STAGE_X 233
#define UI_STATUS_STAGE_Y 94
#define UI_STATUS_LBL_FOOD_X 90
#define UI_STATUS_LBL_FOOD_Y 136
#define UI_STATUS_BAR_FOOD_X 140
#define UI_STATUS_BAR_FOOD_Y 131
#define UI_STATUS_BAR_FOOD_W 190
#define UI_STATUS_BAR_FOOD_H 10
#define UI_STATUS_VAL_FOOD_X 376
#define UI_STATUS_VAL_FOOD_Y 136
#define UI_STATUS_HIT_FOOD_X 233
#define UI_STATUS_HIT_FOOD_Y 136
#define UI_STATUS_HIT_FOOD_W 300
#define UI_STATUS_HIT_FOOD_H 34
#define UI_STATUS_LBL_MOOD_X 90
#define UI_STATUS_LBL_MOOD_Y 172
#define UI_STATUS_BAR_MOOD_X 140
#define UI_STATUS_BAR_MOOD_Y 167
#define UI_STATUS_BAR_MOOD_W 190
#define UI_STATUS_BAR_MOOD_H 10
#define UI_STATUS_VAL_MOOD_X 376
#define UI_STATUS_VAL_MOOD_Y 172
#define UI_STATUS_HIT_MOOD_X 233
#define UI_STATUS_HIT_MOOD_Y 172
#define UI_STATUS_HIT_MOOD_W 300
#define UI_STATUS_HIT_MOOD_H 34
#define UI_STATUS_LBL_CLEAN_X 90
#define UI_STATUS_LBL_CLEAN_Y 208
#define UI_STATUS_BAR_CLEAN_X 140
#define UI_STATUS_BAR_CLEAN_Y 203
#define UI_STATUS_BAR_CLEAN_W 190
#define UI_STATUS_BAR_CLEAN_H 10
#define UI_STATUS_VAL_CLEAN_X 376
#define UI_STATUS_VAL_CLEAN_Y 208
#define UI_STATUS_HIT_CLEAN_X 233
#define UI_STATUS_HIT_CLEAN_Y 208
#define UI_STATUS_HIT_CLEAN_W 300
#define UI_STATUS_HIT_CLEAN_H 34
#define UI_STATUS_LBL_ENERGY_X 90
#define UI_STATUS_LBL_ENERGY_Y 244
#define UI_STATUS_BAR_ENERGY_X 140
#define UI_STATUS_BAR_ENERGY_Y 239
#define UI_STATUS_BAR_ENERGY_W 190
#define UI_STATUS_BAR_ENERGY_H 10
#define UI_STATUS_VAL_ENERGY_X 376
#define UI_STATUS_VAL_ENERGY_Y 244
#define UI_STATUS_HIT_ENERGY_X 233
#define UI_STATUS_HIT_ENERGY_Y 244
#define UI_STATUS_HIT_ENERGY_W 300
#define UI_STATUS_HIT_ENERGY_H 34
#define UI_STATUS_LBL_HEALTH_X 90
#define UI_STATUS_LBL_HEALTH_Y 280
#define UI_STATUS_BAR_HEALTH_X 140
#define UI_STATUS_BAR_HEALTH_Y 275
#define UI_STATUS_BAR_HEALTH_W 190
#define UI_STATUS_BAR_HEALTH_H 10
#define UI_STATUS_VAL_HEALTH_X 376
#define UI_STATUS_VAL_HEALTH_Y 280
#define UI_STATUS_HIT_HEALTH_X 233
#define UI_STATUS_HIT_HEALTH_Y 280
#define UI_STATUS_HIT_HEALTH_W 300
#define UI_STATUS_HIT_HEALTH_H 34
#define UI_STATUS_ICO_COIN_X 206
#define UI_STATUS_ICO_COIN_Y 322
#define UI_STATUS_COINS_X 222
#define UI_STATUS_COINS_Y 322
#define UI_STATUS_DEV_X 233
#define UI_STATUS_DEV_Y 354
#define UI_STATUS_SYNC_X 233
#define UI_STATUS_SYNC_Y 380
#define UI_STATUS_BTN_GEAR_X 233
#define UI_STATUS_BTN_GEAR_Y 414
#define UI_STATUS_BTN_GEAR_R 24
/* settings：设置 */
#define UI_SETTINGS_TITLE_X 233
#define UI_SETTINGS_TITLE_Y 62
#define UI_SETTINGS_LBL_BRIGHT_X 86
#define UI_SETTINGS_LBL_BRIGHT_Y 126
#define UI_SETTINGS_VAL_BRIGHT_X 380
#define UI_SETTINGS_VAL_BRIGHT_Y 126
#define UI_SETTINGS_HIT_BRIGHT_X 233
#define UI_SETTINGS_HIT_BRIGHT_Y 126
#define UI_SETTINGS_HIT_BRIGHT_W 310
#define UI_SETTINGS_HIT_BRIGHT_H 48
#define UI_SETTINGS_LBL_WAKE_X 86
#define UI_SETTINGS_LBL_WAKE_Y 178
#define UI_SETTINGS_TG_WAKE_X 380
#define UI_SETTINGS_TG_WAKE_Y 178
#define UI_SETTINGS_TG_WAKE_W 52
#define UI_SETTINGS_TG_WAKE_H 28
#define UI_SETTINGS_HIT_WAKE_X 233
#define UI_SETTINGS_HIT_WAKE_Y 178
#define UI_SETTINGS_HIT_WAKE_W 310
#define UI_SETTINGS_HIT_WAKE_H 48
#define UI_SETTINGS_LBL_DISCOVER_X 86
#define UI_SETTINGS_LBL_DISCOVER_Y 230
#define UI_SETTINGS_TG_DISCOVER_X 380
#define UI_SETTINGS_TG_DISCOVER_Y 230
#define UI_SETTINGS_TG_DISCOVER_W 52
#define UI_SETTINGS_TG_DISCOVER_H 28
#define UI_SETTINGS_HIT_DISCOVER_X 233
#define UI_SETTINGS_HIT_DISCOVER_Y 230
#define UI_SETTINGS_HIT_DISCOVER_W 310
#define UI_SETTINGS_HIT_DISCOVER_H 48
#define UI_SETTINGS_LBL_AOD_X 86
#define UI_SETTINGS_LBL_AOD_Y 282
#define UI_SETTINGS_TG_AOD_X 380
#define UI_SETTINGS_TG_AOD_Y 282
#define UI_SETTINGS_TG_AOD_W 52
#define UI_SETTINGS_TG_AOD_H 28
#define UI_SETTINGS_HIT_AOD_X 233
#define UI_SETTINGS_HIT_AOD_Y 282
#define UI_SETTINGS_HIT_AOD_W 310
#define UI_SETTINGS_HIT_AOD_H 48
#define UI_SETTINGS_FOOT_X 233
#define UI_SETTINGS_FOOT_Y 346
#define UI_SETTINGS_HIT_VER_X 233
#define UI_SETTINGS_HIT_VER_Y 346
#define UI_SETTINGS_HIT_VER_W 200
#define UI_SETTINGS_HIT_VER_H 40
/* touch_test：触摸自检（开发用） */
#define UI_TOUCH_TEST_TITLE_X 233
#define UI_TOUCH_TEST_TITLE_Y 64
#define UI_TOUCH_TEST_TT_1_X 113
#define UI_TOUCH_TEST_TT_1_Y 113
#define UI_TOUCH_TEST_TT_1_W 52
#define UI_TOUCH_TEST_TT_1_H 52
#define UI_TOUCH_TEST_TT_2_X 353
#define UI_TOUCH_TEST_TT_2_Y 113
#define UI_TOUCH_TEST_TT_2_W 52
#define UI_TOUCH_TEST_TT_2_H 52
#define UI_TOUCH_TEST_TT_3_X 353
#define UI_TOUCH_TEST_TT_3_Y 353
#define UI_TOUCH_TEST_TT_3_W 52
#define UI_TOUCH_TEST_TT_3_H 52
#define UI_TOUCH_TEST_TT_4_X 113
#define UI_TOUCH_TEST_TT_4_Y 353
#define UI_TOUCH_TEST_TT_4_W 52
#define UI_TOUCH_TEST_TT_4_H 52
#define UI_TOUCH_TEST_TT_5_X 233
#define UI_TOUCH_TEST_TT_5_Y 233
#define UI_TOUCH_TEST_TT_5_W 52
#define UI_TOUCH_TEST_TT_5_H 52
#define UI_TOUCH_TEST_XY_X 233
#define UI_TOUCH_TEST_XY_Y 176
#define UI_TOUCH_TEST_RES_X 233
#define UI_TOUCH_TEST_RES_Y 292
#define UI_TOUCH_TEST_FOOT_X 233
#define UI_TOUCH_TEST_FOOT_Y 410
/* voice：按住说话 / 唤醒后在听 */
#define UI_VOICE_CAT_DIST 92
#define UI_VOICE_CAT_OX 0
#define UI_VOICE_CAT_OY -14
#define UI_VOICE_CAT_DIM_PCT 50
#define UI_VOICE_WAVE_R 206
#define UI_VOICE_BTN_MIC_X 233
#define UI_VOICE_BTN_MIC_Y 368
#define UI_VOICE_BTN_MIC_R 34
#define UI_VOICE_STATE_X 233
#define UI_VOICE_STATE_Y 422
/* meet：遇见：附近有小猫 */
#define UI_MEET_CAT_DIST 108
#define UI_MEET_CAT_OX 0
#define UI_MEET_CAT_OY -28
#define UI_MEET_CAT_DIM_PCT 100
#define UI_MEET_TITLE_X 233
#define UI_MEET_TITLE_Y 70
#define UI_MEET_PEER_X 233
#define UI_MEET_PEER_Y 322
#define UI_MEET_PEER_SUB_X 233
#define UI_MEET_PEER_SUB_Y 348
#define UI_MEET_BTN_HI_X 172
#define UI_MEET_BTN_HI_Y 386
#define UI_MEET_BTN_HI_W 112
#define UI_MEET_BTN_HI_H 44
#define UI_MEET_BTN_SKIP_X 294
#define UI_MEET_BTN_SKIP_Y 386
#define UI_MEET_BTN_SKIP_W 112
#define UI_MEET_BTN_SKIP_H 44
/* meet_tap：遇见：碰一碰确认 */
#define UI_MEET_TAP_TITLE_X 233
#define UI_MEET_TAP_TITLE_Y 70
#define UI_MEET_TAP_ICO_X 233
#define UI_MEET_TAP_ICO_Y 196
#define UI_MEET_TAP_HINT_X 233
#define UI_MEET_TAP_HINT_Y 292
#define UI_MEET_TAP_HINT2_X 233
#define UI_MEET_TAP_HINT2_Y 322
#define UI_MEET_TAP_BTN_CANCEL_X 233
#define UI_MEET_TAP_BTN_CANCEL_Y 384
#define UI_MEET_TAP_BTN_CANCEL_W 112
#define UI_MEET_TAP_BTN_CANCEL_H 44
/* meet_scan：遇见：扫码确认（没有 NFC 时） */
#define UI_MEET_SCAN_TITLE_X 233
#define UI_MEET_SCAN_TITLE_Y 64
#define UI_MEET_SCAN_QR_X 233
#define UI_MEET_SCAN_QR_Y 188
#define UI_MEET_SCAN_QR_W 156
#define UI_MEET_SCAN_QR_H 156
#define UI_MEET_SCAN_HINT_X 233
#define UI_MEET_SCAN_HINT_Y 300
#define UI_MEET_SCAN_HINT2_X 233
#define UI_MEET_SCAN_HINT2_Y 330
#define UI_MEET_SCAN_BTN_CANCEL_X 233
#define UI_MEET_SCAN_BTN_CANCEL_Y 384
#define UI_MEET_SCAN_BTN_CANCEL_W 112
#define UI_MEET_SCAN_BTN_CANCEL_H 44
/* meet_done：遇见：成为朋友 */
#define UI_MEET_DONE_ICO_X 233
#define UI_MEET_DONE_ICO_Y 186
#define UI_MEET_DONE_TITLE_X 233
#define UI_MEET_DONE_TITLE_Y 286
#define UI_MEET_DONE_GIFT_X 233
#define UI_MEET_DONE_GIFT_Y 320
#define UI_MEET_DONE_HIT_ANY_X 233
#define UI_MEET_DONE_HIT_ANY_Y 233
#define UI_MEET_DONE_HIT_ANY_R 233
/* away：生活同步：小猫在外面 */
#define UI_AWAY_TIME_X 233
#define UI_AWAY_TIME_Y 64
#define UI_AWAY_PLACE_X 233
#define UI_AWAY_PLACE_Y 182
#define UI_AWAY_WHERE_X 233
#define UI_AWAY_WHERE_Y 280
#define UI_AWAY_DOING_X 233
#define UI_AWAY_DOING_Y 310
#define UI_AWAY_BTN_HOME_X 233
#define UI_AWAY_BTN_HOME_Y 376
#define UI_AWAY_BTN_HOME_W 150
#define UI_AWAY_BTN_HOME_H 46
/* lowbat：电量不足 */
#define UI_LOWBAT_ICO_X 233
#define UI_LOWBAT_ICO_Y 196
#define UI_LOWBAT_TITLE_X 233
#define UI_LOWBAT_TITLE_Y 286
#define UI_LOWBAT_SUB_X 233
#define UI_LOWBAT_SUB_Y 320
/* boot：开机 */
#define UI_BOOT_LOGO_X 233
#define UI_BOOT_LOGO_Y 188
#define UI_BOOT_TITLE_X 233
#define UI_BOOT_TITLE_Y 282
#define UI_BOOT_SUB_X 233
#define UI_BOOT_SUB_Y 314
/* pair：配对 */
#define UI_PAIR_TITLE_X 233
#define UI_PAIR_TITLE_Y 120
#define UI_PAIR_CODE_X 233
#define UI_PAIR_CODE_Y 212
#define UI_PAIR_HINT_X 233
#define UI_PAIR_HINT_Y 276
#define UI_PAIR_DOTS_X 233
#define UI_PAIR_DOTS_Y 330
#define UI_PAIR_DOTS_R 4
#define UI_PAIR_DOTS_N 3
#define UI_PAIR_DOTS_GAP 16
/* guide：首次引导 */
#define UI_GUIDE_ICO_X 233
#define UI_GUIDE_ICO_Y 184
#define UI_GUIDE_TITLE_X 233
#define UI_GUIDE_TITLE_Y 280
#define UI_GUIDE_SUB_X 233
#define UI_GUIDE_SUB_Y 312
#define UI_GUIDE_DOTS_X 233
#define UI_GUIDE_DOTS_Y 360
#define UI_GUIDE_DOTS_R 4
#define UI_GUIDE_DOTS_N 5
#define UI_GUIDE_DOTS_GAP 18
#define UI_GUIDE_HIT_ANY_X 233
#define UI_GUIDE_HIT_ANY_Y 233
#define UI_GUIDE_HIT_ANY_R 233

/* 像素图标：16×16 调色板索引（0 = 透明），按整数倍最近邻放大 */
static const uint16_t BADGE_ICON_PAL565[21] = { 0x0000, 0xF50B, 0xCBA7, 0xF64B, 0xCCA5, 0xFFBC, 0xBD51, 0x6B0A, 0x8E3C, 0x4C77, 0xF4D5, 0xDB50, 0xFB4D, 0xBA28, 0xAED1, 0x5CCA, 0x9B48, 0x6A45, 0x7DBF, 0x3B98, 0xB53D };
static const uint8_t BADGE_ICON_BT[256] = { 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,18,18,0,0,0,0,0,0,0,0,0,0,0,0,0,0,18,18,18,0,0,0,0,0,0,0,0,0,0,0,0,0,18,18,18,18,0,0,0,0,0,0,0,0,18,0,0,0,18,18,0,18,18,0,0,0,0,0,0,0,0,18,0,0,18,18,0,0,18,18,0,0,0,0,0,0,0,0,18,0,18,18,0,18,18,0,0,0,0,0,0,0,0,0,0,18,18,18,18,18,0,0,0,0,0,0,0,0,0,0,0,18,18,18,18,18,0,0,0,0,0,0,0,0,0,0,18,0,18,18,0,18,18,0,0,0,0,0,0,0,0,18,0,0,18,18,0,0,18,18,0,0,0,0,0,0,18,0,0,0,18,18,0,18,18,0,0,0,0,0,0,0,0,0,0,0,18,18,18,18,0,0,0,0,0,0,0,0,0,0,0,0,18,18,18,0,0,0,0,0,0,0,0,0,0,0,0,0,18,18,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 };
static const uint8_t BADGE_ICON_BT_OFF[256] = { 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,7,7,0,0,0,0,0,0,0,0,0,0,0,0,0,0,7,7,7,0,0,0,12,0,0,0,0,0,0,0,0,0,7,7,7,7,0,12,0,0,0,0,0,0,7,0,0,0,7,7,0,7,12,0,0,0,0,0,0,0,0,7,0,0,7,7,0,12,0,7,0,0,0,0,0,0,0,0,7,0,7,7,12,0,7,0,0,0,0,0,0,0,0,0,0,7,7,12,7,7,0,0,0,0,0,0,0,0,0,0,0,7,12,7,7,7,0,0,0,0,0,0,0,0,0,0,7,12,7,7,0,7,7,0,0,0,0,0,0,0,0,12,0,0,7,7,0,0,7,7,0,0,0,0,0,0,12,0,0,0,7,7,0,7,7,0,0,0,0,0,0,12,0,0,0,0,7,7,7,7,0,0,0,0,0,0,0,0,0,0,0,0,7,7,7,0,0,0,0,0,0,0,0,0,0,0,0,0,7,7,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 };
static const uint8_t BADGE_ICON_BOWL[256] = { 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,16,0,0,16,0,0,0,0,0,0,0,0,0,0,16,16,17,16,16,17,16,16,0,0,0,0,0,0,0,16,17,16,16,17,16,16,17,16,16,0,0,0,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,0,2,5,5,5,5,5,5,5,5,5,5,5,5,2,0,0,0,2,1,1,1,1,1,1,1,1,1,1,2,0,0,0,0,2,1,1,1,1,1,1,1,1,1,2,2,0,0,0,0,0,2,1,1,1,1,1,1,1,1,2,0,0,0,0,0,0,0,2,2,2,2,2,2,2,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 };
static const uint8_t BADGE_ICON_WATER[256] = { 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,8,0,0,0,0,0,0,0,0,0,0,0,0,0,0,8,8,8,0,0,0,0,0,0,0,0,0,0,0,0,8,8,5,8,8,0,0,0,0,0,0,0,0,0,0,0,8,5,8,8,8,0,0,0,0,0,0,0,0,0,0,0,8,8,8,8,8,0,0,0,0,0,0,0,0,0,0,0,0,8,8,8,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,6,6,6,6,6,6,6,6,6,6,6,6,6,6,0,0,7,8,8,8,8,8,8,8,8,8,8,8,8,7,0,0,0,7,8,5,8,8,8,8,8,8,8,8,7,0,0,0,0,7,8,8,8,8,8,8,8,8,8,8,7,0,0,0,0,0,7,8,8,8,8,8,8,8,8,7,0,0,0,0,0,0,0,7,7,7,7,7,7,7,7,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 };
static const uint8_t BADGE_ICON_FEATHER[256] = { 0,0,0,0,0,0,0,0,0,0,0,10,10,0,0,0,0,0,0,0,0,0,0,0,0,0,10,10,10,10,0,0,0,0,0,0,0,0,0,0,0,10,10,5,10,10,10,0,0,0,0,0,0,0,0,0,10,10,5,10,10,10,10,0,0,0,0,0,0,0,0,10,10,5,10,10,10,10,0,0,0,0,0,0,0,0,10,10,5,10,10,10,10,0,0,0,0,0,0,0,0,10,10,5,10,10,10,10,0,0,0,0,0,0,0,0,0,10,5,10,10,10,10,0,0,0,0,0,0,0,0,0,10,10,10,10,10,0,0,0,0,0,0,0,0,0,0,16,0,10,10,10,0,0,0,0,0,0,0,0,0,0,16,0,0,0,0,0,0,0,0,0,0,0,0,0,0,16,0,0,0,0,0,0,0,0,0,0,0,0,0,0,16,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 };
static const uint8_t BADGE_ICON_MOON[256] = { 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,3,3,3,3,0,0,0,0,0,0,0,0,0,0,3,3,3,3,0,0,0,0,0,0,0,5,0,0,0,3,3,3,3,0,0,0,0,0,0,0,5,5,5,0,0,3,3,3,0,0,0,0,0,0,0,0,0,5,0,0,3,3,3,3,0,0,0,0,0,0,0,0,0,0,0,0,3,3,3,3,0,0,0,0,0,0,0,0,0,0,0,0,3,3,3,3,0,0,0,0,0,0,5,0,0,0,0,0,3,3,3,3,3,0,0,0,0,0,0,0,0,0,0,0,3,3,3,3,3,0,0,0,0,0,0,0,0,0,3,0,0,3,3,3,3,3,0,0,0,0,0,0,3,3,0,0,0,3,3,3,3,3,3,3,3,3,3,3,3,0,0,0,0,0,3,3,3,3,3,3,3,3,3,3,0,0,0,0,0,0,0,0,3,3,3,3,3,3,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 };
static const uint8_t BADGE_ICON_HEART[256] = { 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,10,10,10,0,0,0,0,10,10,10,0,0,0,0,0,10,10,10,10,10,0,0,10,10,10,10,10,0,0,0,10,5,5,10,10,10,10,10,10,10,10,10,10,10,0,0,10,5,10,10,10,10,10,10,10,10,10,10,10,10,0,0,10,10,10,10,10,10,10,10,10,10,10,10,10,10,0,0,10,10,10,10,10,10,10,10,10,10,10,10,10,10,0,0,0,10,10,10,10,10,10,10,10,10,10,10,10,0,0,0,0,0,10,10,10,10,10,10,10,10,10,10,0,0,0,0,0,0,0,10,10,10,10,10,10,10,10,0,0,0,0,0,0,0,0,0,10,10,10,10,10,10,0,0,0,0,0,0,0,0,0,0,0,10,10,10,10,0,0,0,0,0,0,0,0,0,0,0,0,0,10,10,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 };
static const uint8_t BADGE_ICON_COIN[256] = { 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,4,4,4,4,4,4,0,0,0,0,0,0,0,0,4,4,3,3,3,3,3,3,4,4,0,0,0,0,0,4,3,3,3,3,3,3,3,3,3,3,4,0,0,0,0,4,3,5,3,3,3,3,3,3,3,3,4,0,0,0,4,3,5,3,3,3,3,3,3,3,3,3,3,4,0,0,4,3,3,3,3,4,4,4,4,3,3,3,3,4,0,0,4,3,3,3,3,4,3,3,3,3,3,3,3,4,0,0,4,3,3,3,3,4,3,3,3,3,3,3,3,4,0,0,4,3,3,3,3,4,4,4,4,3,3,3,3,4,0,0,4,3,3,3,3,3,3,3,3,3,3,3,3,4,0,0,0,4,3,3,3,3,3,3,3,3,3,3,4,0,0,0,0,4,3,3,3,3,3,3,3,3,3,3,4,0,0,0,0,0,4,4,3,3,3,3,3,3,4,4,0,0,0,0,0,0,0,0,4,4,4,4,4,4,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 };
static const uint8_t BADGE_ICON_GEAR[256] = { 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,6,6,0,0,0,0,0,0,0,0,0,0,6,6,0,0,6,6,0,0,6,6,0,0,0,0,0,0,6,6,6,6,6,6,6,6,6,0,0,0,0,0,0,0,0,6,6,6,6,6,6,6,6,0,0,0,0,0,0,6,6,6,7,7,7,7,7,6,6,6,0,0,0,0,0,6,6,7,7,0,0,0,7,7,6,6,0,0,0,6,6,6,6,6,7,0,0,0,7,6,6,6,6,6,6,6,6,6,6,6,7,0,0,0,7,6,6,6,6,6,6,0,0,6,6,7,7,0,0,0,7,7,6,6,0,0,0,0,0,6,6,6,7,7,7,7,7,6,6,6,0,0,0,0,0,0,0,6,6,6,6,6,6,6,6,0,0,0,0,0,0,0,6,6,6,6,6,6,6,6,6,0,0,0,0,0,0,0,6,6,0,0,6,6,0,0,6,6,0,0,0,0,0,0,0,0,0,0,6,6,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 };
static const uint8_t BADGE_ICON_MIC[256] = { 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,5,5,5,5,0,0,0,0,0,0,0,0,0,0,0,5,5,5,5,5,5,0,0,0,0,0,0,0,0,0,0,5,5,5,5,5,5,0,0,0,0,0,0,0,0,0,0,5,5,5,5,5,5,0,0,0,0,0,0,0,0,0,0,5,5,5,5,5,5,0,0,0,0,0,0,0,5,0,0,5,5,5,5,5,5,0,0,5,0,0,0,0,5,0,0,5,5,5,5,5,5,0,0,5,0,0,0,0,5,5,0,5,5,5,5,5,5,0,5,5,0,0,0,0,0,5,5,0,5,5,5,5,0,5,5,0,0,0,0,0,0,0,5,5,0,0,0,0,5,5,0,0,0,0,0,0,0,0,0,0,5,5,5,5,0,0,0,0,0,0,0,0,0,0,0,0,0,5,5,0,0,0,0,0,0,0,0,0,0,0,0,0,0,5,5,0,0,0,0,0,0,0,0,0,0,0,0,5,5,5,5,5,5,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 };
static const uint8_t BADGE_ICON_PAW[256] = { 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,1,1,0,0,0,0,0,0,0,1,1,1,1,0,0,1,1,1,1,0,0,0,0,0,0,1,1,1,1,0,0,1,1,1,1,0,0,0,1,1,0,0,1,1,0,0,0,0,1,1,0,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,0,0,0,1,1,1,1,0,0,0,1,1,1,0,1,0,0,0,1,1,1,1,1,1,0,0,0,1,0,0,0,0,0,1,1,1,1,1,1,1,1,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,1,1,0,0,0,0,0,0,1,1,1,1,1,1,1,1,1,1,0,0,0,0,0,0,1,1,1,1,1,1,1,1,1,1,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,1,1,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 };
static const uint8_t BADGE_ICON_GIFT[256] = { 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,12,12,0,0,0,0,12,12,0,0,0,0,0,0,0,12,0,0,12,0,0,12,0,0,12,0,0,0,0,0,0,12,0,0,0,12,12,0,0,0,12,0,0,0,0,0,0,0,12,12,12,12,12,12,12,12,0,0,0,0,0,1,1,1,1,1,1,12,12,1,1,1,1,1,1,0,0,1,1,1,1,1,1,12,12,1,1,1,1,1,1,0,0,2,2,2,2,2,2,12,12,2,2,2,2,2,2,0,0,0,1,1,1,1,1,1,12,12,1,1,1,1,0,0,0,0,1,1,1,1,1,1,12,12,1,1,1,1,0,0,0,0,1,1,1,1,1,1,12,12,1,1,1,1,0,0,0,0,1,1,1,1,1,1,12,12,1,1,1,1,0,0,0,0,1,1,1,1,1,1,12,12,1,1,1,1,0,0,0,0,2,2,2,2,2,2,12,12,2,2,2,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 };
static const uint8_t BADGE_ICON_TAP[256] = { 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,6,6,6,6,6,0,0,0,0,6,6,6,6,6,0,6,7,18,18,18,7,6,0,0,6,7,10,10,10,7,6,6,18,18,18,18,18,6,0,0,6,10,10,10,10,10,6,6,18,18,5,18,18,6,0,0,6,10,10,5,10,10,6,6,18,18,18,18,18,6,0,0,6,10,10,10,10,10,6,6,7,18,18,18,7,6,0,0,6,7,10,10,10,7,6,0,6,6,6,6,6,0,0,0,0,6,6,6,6,6,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,3,0,0,0,0,0,0,0,0,3,0,0,0,0,0,0,0,3,0,0,3,3,0,0,3,0,0,0,0,0,0,0,0,0,3,0,3,3,0,3,0,0,0,0,0,0,0,0,0,0,0,3,3,3,3,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 };
static const uint8_t BADGE_ICON_OFFICE[256] = { 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,7,7,7,7,7,7,7,7,7,7,0,0,0,0,0,0,7,8,8,7,8,8,7,8,8,7,0,0,0,0,0,0,7,7,7,7,7,7,7,7,7,7,0,0,0,0,0,0,7,8,8,7,8,8,7,8,8,7,0,0,0,0,0,0,7,7,7,7,7,7,7,7,7,7,0,0,0,0,0,0,7,8,8,7,8,8,7,8,8,7,0,0,0,0,0,0,7,7,7,7,7,7,7,7,7,7,0,0,0,0,0,0,7,8,8,7,16,16,7,8,8,7,0,0,0,0,0,0,7,7,7,7,16,16,7,7,7,7,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,14,0,10,0,14,0,3,0,14,0,10,0,14,0,0,14,15,14,15,14,15,14,15,14,15,14,15,14,15,14,0,0,15,15,15,15,15,15,15,15,15,15,15,15,15,15,0,0,0,16,16,16,16,16,16,16,16,16,16,16,16,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 };
static const uint8_t BADGE_ICON_CAFE[256] = { 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,5,0,0,5,0,0,0,0,0,0,0,0,0,0,0,0,0,5,0,0,5,0,0,0,0,0,0,0,0,0,0,0,5,0,0,5,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,5,5,5,5,5,5,5,5,5,5,5,5,0,0,0,0,5,16,16,16,16,16,16,16,16,16,16,5,5,5,0,0,5,16,16,16,16,16,16,16,16,16,16,5,0,5,0,0,5,5,5,5,5,5,5,5,5,5,5,5,0,5,0,0,5,5,5,5,5,5,5,5,5,5,5,5,5,0,0,0,0,5,5,5,5,5,5,5,5,5,5,0,0,0,0,0,0,0,5,5,5,5,5,5,5,5,0,0,0,0,0,0,6,6,6,6,6,6,6,6,6,6,6,6,0,0,0,0,0,6,6,6,6,6,6,6,6,6,6,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 };
static const uint8_t BADGE_ICON_FLOWER[256] = { 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,10,10,0,0,0,0,0,0,0,0,0,0,0,0,0,10,10,10,10,0,0,0,0,0,0,0,0,0,0,0,10,10,0,0,10,10,0,0,0,0,0,0,0,0,0,0,10,0,3,3,0,10,0,0,0,0,0,0,0,0,0,0,10,10,0,0,10,10,0,0,0,0,0,0,0,0,0,0,0,10,10,10,10,0,0,0,0,0,0,0,0,0,0,0,0,0,14,10,0,0,0,20,0,0,0,0,0,0,0,0,0,0,14,0,0,0,20,20,20,0,0,0,0,0,0,14,14,0,14,0,0,0,0,20,0,0,0,0,0,0,0,0,14,14,14,0,0,0,0,14,0,0,0,0,0,0,0,0,0,0,14,0,0,14,14,14,0,0,0,0,0,0,0,0,0,0,14,0,0,0,0,14,0,0,0,0,0,0,15,15,15,15,15,15,15,15,15,15,15,15,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 };
static const uint8_t BADGE_ICON_SPIRAL[256] = { 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,1,0,0,0,0,0,1,0,0,1,1,1,1,1,1,0,0,1,0,0,0,1,0,0,1,0,0,0,0,0,0,1,0,0,1,0,0,1,0,1,0,0,1,1,1,1,0,0,1,0,1,0,0,1,0,1,0,1,0,0,0,0,1,0,1,0,1,0,0,1,0,1,0,1,0,0,1,0,1,0,1,0,1,0,0,1,0,1,0,1,0,0,1,0,1,0,1,0,1,0,0,1,0,1,0,0,1,1,0,0,1,0,1,0,1,0,0,1,0,0,1,0,0,0,0,1,0,0,1,0,1,0,0,0,1,0,0,1,1,1,1,0,0,1,0,0,1,0,0,0,0,1,0,0,0,0,0,0,1,0,0,0,1,0,0,0,0,0,1,1,1,1,1,1,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 };
static const uint8_t BADGE_ICON_QUESTION[256] = { 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,0,0,0,0,0,0,0,1,1,1,0,0,0,0,1,1,1,0,0,0,0,0,0,1,1,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 };
static const uint8_t BADGE_ICON_BANG[256] = { 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,3,0,0,0,0,1,1,0,0,0,0,3,0,0,0,0,0,3,0,0,0,1,1,0,0,0,3,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,3,0,0,0,0,0,1,1,0,0,0,0,0,3,0,0,0,3,0,0,0,0,1,1,0,0,0,0,3,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 };
static const uint8_t BADGE_ICON_SOAP[256] = { 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,5,5,0,0,0,0,0,0,0,0,0,0,0,0,0,5,0,0,5,0,0,0,0,0,0,0,5,5,0,0,0,5,0,0,5,0,0,0,0,0,0,5,0,0,5,0,0,0,5,5,0,0,0,0,0,0,0,5,0,0,5,0,0,0,0,0,0,0,0,0,0,0,0,0,5,5,0,0,5,5,0,0,0,0,0,0,0,0,0,0,0,0,0,5,0,0,5,0,0,0,0,0,0,0,0,0,0,0,0,5,0,0,5,0,0,0,0,0,0,0,8,8,8,8,8,8,5,5,8,8,8,8,0,0,0,8,8,8,8,8,8,8,8,8,8,8,8,8,8,0,0,8,5,5,8,8,8,8,8,8,8,8,8,8,8,0,0,8,8,8,8,8,8,8,8,8,8,8,8,8,8,0,0,9,9,9,9,9,9,9,9,9,9,9,9,9,9,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 };
static const uint8_t BADGE_ICON_HEALTH[256] = { 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,12,12,12,12,0,0,0,0,0,0,0,0,0,0,0,0,12,12,12,12,0,0,0,0,0,0,0,0,0,0,0,0,12,12,12,12,0,0,0,0,0,0,0,0,0,0,0,0,12,12,12,12,0,0,0,0,0,0,0,0,12,12,12,12,12,12,12,12,12,12,12,12,0,0,0,0,12,12,12,12,12,12,12,12,12,12,12,12,0,0,0,0,12,12,12,12,12,12,12,12,12,12,12,12,0,0,0,0,12,12,12,12,12,12,12,12,12,12,12,12,0,0,0,0,0,0,0,0,12,12,12,12,0,0,0,0,0,0,0,0,0,0,0,0,12,12,12,12,0,0,0,0,0,0,0,0,0,0,0,0,12,12,12,12,0,0,0,0,0,0,0,0,0,0,0,0,12,12,12,12,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 };
static const uint8_t BADGE_ICON_BAT_LOW[256] = { 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,6,6,6,6,6,6,6,6,6,6,6,6,6,6,0,0,6,0,0,0,0,0,0,0,0,0,0,0,0,6,0,0,6,0,12,12,0,0,0,0,0,0,0,0,0,6,6,0,6,0,12,12,0,0,0,0,0,0,0,0,0,6,6,0,6,0,12,12,0,0,0,0,0,0,0,0,0,6,6,0,6,0,12,12,0,0,0,0,0,0,0,0,0,6,6,0,6,0,0,0,0,0,0,0,0,0,0,0,0,6,0,0,6,6,6,6,6,6,6,6,6,6,6,6,6,6,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 };
static const uint8_t BADGE_ICON_BOLT[256] = { 0,0,0,0,0,0,0,0,14,14,0,0,0,0,0,0,0,0,0,0,0,0,0,14,14,0,0,0,0,0,0,0,0,0,0,0,0,0,14,14,0,0,0,0,0,0,0,0,0,0,0,0,0,14,14,0,0,0,0,0,0,0,0,0,0,0,0,0,14,14,14,14,14,14,0,0,0,0,0,0,0,0,0,0,0,0,0,14,14,0,0,0,0,0,0,0,0,0,0,0,0,0,14,14,0,0,0,0,0,0,0,0,0,0,0,0,0,14,14,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 };
static const uint8_t BADGE_ICON_HAND_TAP[256] = { 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,3,0,0,3,0,0,0,0,0,0,0,0,0,0,0,0,0,3,0,3,0,3,0,0,0,0,0,0,0,0,0,3,0,0,0,0,0,0,0,0,0,3,0,0,0,0,0,0,0,5,5,0,0,0,0,0,0,0,0,0,0,0,0,0,5,5,5,5,0,0,0,0,0,0,0,0,0,0,0,0,5,5,5,5,0,0,0,0,0,0,0,0,0,0,0,0,5,5,5,5,5,5,0,0,0,0,0,0,0,0,0,0,5,5,5,5,5,5,5,5,0,0,0,0,0,0,5,5,5,5,5,5,5,5,5,5,5,0,0,0,0,0,5,5,5,5,5,5,5,5,5,5,5,0,0,0,0,0,5,5,5,5,5,5,5,5,5,5,5,0,0,0,0,0,0,5,5,5,5,5,5,5,5,5,0,0,0,0,0,0,0,0,5,5,5,5,5,5,5,0,0,0,0,0,0,0,0,0,5,5,5,5,5,5,5,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 };
static const uint8_t BADGE_ICON_SWIPE_UP[256] = { 0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,1,1,0,1,1,0,1,1,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,5,5,0,0,0,0,0,0,0,0,0,0,0,0,0,5,5,5,5,0,0,0,0,0,0,0,0,0,0,0,0,5,5,5,5,0,0,0,0,0,0,0,0,0,0,0,0,5,5,5,5,5,5,0,0,0,0,0,0,0,0,0,0,5,5,5,5,5,5,5,5,0,0,0,0,0,0,5,5,5,5,5,5,5,5,5,5,5,0,0,0,0,0,5,5,5,5,5,5,5,5,5,5,5,0,0,0,0,0,0,5,5,5,5,5,5,5,5,5,0,0,0,0,0,0,0,0,5,5,5,5,5,5,5,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 };
static const uint8_t BADGE_ICON_SWIPE_DOWN[256] = { 0,0,0,0,0,0,5,5,0,0,0,0,0,0,0,0,0,0,0,0,0,5,5,5,5,0,0,0,0,0,0,0,0,0,0,0,0,5,5,5,5,0,0,0,0,0,0,0,0,0,0,0,0,5,5,5,5,5,5,0,0,0,0,0,0,0,0,0,0,5,5,5,5,5,5,5,5,0,0,0,0,0,0,5,5,5,5,5,5,5,5,5,5,5,0,0,0,0,0,5,5,5,5,5,5,5,5,5,5,5,0,0,0,0,0,0,5,5,5,5,5,5,5,5,5,0,0,0,0,0,0,0,0,5,5,5,5,5,5,5,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,1,1,0,1,1,0,1,1,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0 };
static const uint8_t BADGE_ICON_HOLD[256] = { 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,5,5,0,0,0,0,0,1,0,0,0,0,1,0,0,5,5,5,5,0,0,0,0,1,0,0,0,0,1,0,0,5,5,5,5,0,0,0,0,1,0,0,0,0,1,0,0,5,5,5,5,5,5,0,0,1,0,0,0,0,1,0,0,5,5,5,5,5,5,5,5,1,0,0,0,0,1,5,5,5,5,5,5,5,5,5,5,5,0,0,0,0,0,5,5,5,5,5,5,5,5,5,5,5,0,0,0,0,0,5,5,5,5,5,5,5,5,5,5,5,0,0,0,0,0,0,5,5,5,5,5,5,5,5,5,0,0,0,0,0,0,0,0,5,5,5,5,5,5,5,0,0,0,0,0,0,0,0,0,5,5,5,5,5,5,5,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 };
static const uint8_t BADGE_ICON_SWIPE_LR[256] = { 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,1,0,0,0,1,1,0,0,0,5,5,0,0,0,0,0,1,1,0,1,1,1,1,0,5,5,5,5,0,0,0,1,1,1,1,0,1,1,0,0,5,5,5,5,0,0,0,0,1,1,0,0,0,1,0,0,5,5,5,5,5,5,0,0,1,0,0,0,0,0,0,0,5,5,5,5,5,5,5,5,0,0,0,0,0,0,5,5,5,5,5,5,5,5,5,5,5,0,0,0,0,0,5,5,5,5,5,5,5,5,5,5,5,0,0,0,0,0,5,5,5,5,5,5,5,5,5,5,5,0,0,0,0,0,0,5,5,5,5,5,5,5,5,5,0,0,0,0,0,0,0,0,5,5,5,5,5,5,5,0,0,0,0,0,0,0,0,0,5,5,5,5,5,5,5,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 };
