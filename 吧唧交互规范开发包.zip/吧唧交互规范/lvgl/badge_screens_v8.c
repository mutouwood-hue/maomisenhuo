/* badge_screens_v8.c —— 由「吧唧渲染参考.html（交互规范）」自动生成（LVGL v8），版本 0.3.0
 * 每个画面一个 build 函数；坐标、颜色、字体全部来自规范，照抄即可。
 * 3D 小猫不是 LVGL 控件画的：由 3D 引擎（移植自 ref.js）画在最底层，参数见 badge_ui_spec.h 的 UI_<画面>_CAT_*。
 * 屏幕背景必须纯黑、不透明度 100%，不要用 LVGL 默认主题的蓝色。
 * 动态文字（{time} 等）在 build 里先填示例值，运行时用 lv_label_set_text 更新。
 * 内存：画面对象都建在 LVGL 堆上；不要在 build 函数或回调里放大数组（M1 上板教训：8KB 栈数组让开机即重启，见文档 12.1）。事件缓冲用 static。 */
#include "lvgl.h"
#include "badge_ui_spec.h"

#if LVGL_VERSION_MAJOR != 8
#error "badge_screens_v8.c 只能用 LVGL v8；M1 固件用的是 v9，请改用 badge_screens_v9.c"
#endif
/* 注意：M1 固件锁定 LVGL 9.5.0，本文件只作参考，不要编进 M1 固件 */

LV_FONT_DECLARE(badge_f16);
LV_FONT_DECLARE(badge_f20);
LV_FONT_DECLARE(badge_f24);
LV_FONT_DECLARE(badge_n40);
extern lv_obj_t *badge_cat_layer_create(lv_obj_t *parent, int dist, int ox, int oy, int dim_pct); /* 固件实现：3D 小猫图层 */
extern const void *badge_icon(const char *name); /* 固件实现：按名字返回图标图片（icons/*.png 转换后） */

static lv_obj_t *mk_scr(void){ lv_obj_t *s = lv_obj_create(NULL); lv_obj_set_style_bg_color(s, lv_color_hex(0x000000), 0); lv_obj_set_style_bg_opa(s, LV_OPA_COVER, 0); lv_obj_set_style_border_width(s, 0, 0); lv_obj_set_style_pad_all(s, 0, 0); lv_obj_clear_flag(s, LV_OBJ_FLAG_SCROLLABLE); return s; }
static lv_obj_t *mk_label(lv_obj_t *p, const lv_font_t *f, lv_color_t c, const char *txt, lv_align_t a, int dx, int dy){ lv_obj_t *l = lv_label_create(p); lv_obj_set_style_text_font(l, f, 0); lv_obj_set_style_text_color(l, c, 0); lv_label_set_text(l, txt); lv_obj_align(l, a, dx, dy); return l; }
static lv_obj_t *mk_icon(lv_obj_t *p, const char *name, int scale, int dx, int dy){ lv_obj_t *i = lv_img_create(p); lv_img_set_src(i, badge_icon(name)); lv_img_set_zoom(i, 256 * scale); lv_obj_align(i, LV_ALIGN_CENTER, dx, dy); return i; } /* 图标原图 16×16，最近邻放大 */

/* ===== main_a：主表盘 A · 只有小猫 ===== */
/* 开机配对后的默认画面。中间是 3D 小猫，上方时间与状态，下方 5 段状态弧。 */
/* 进入：开机、从其他画面返回、待机唤醒 */
lv_obj_t *badge_build_main_a(void){
  lv_obj_t *scr = mk_scr();
  badge_cat_layer_create(scr, UI_MAIN_A_CAT_DIST, UI_MAIN_A_CAT_OX, UI_MAIN_A_CAT_OY, UI_MAIN_A_CAT_DIM_PCT); /* 3D 小猫在最底层 */
  lv_obj_t *o_time = mk_label(scr, &badge_n40, lv_color_hex(0xFFF4E0), "09:41", LV_ALIGN_CENTER, 0, -163); /* 动态：{time} */
  lv_obj_t *o_ico_bt = mk_icon(scr, "bt", 1, -37, -121); /* 仅当 phone 时显示 */
  lv_obj_t *o_ico_bt_off = mk_icon(scr, "bt_off", 1, -37, -121); /* 仅当 !phone 时显示 */
  /* 电池图标 22×12，中心 (226,112)：外框 2px BC_SUB，右侧电极 2×6；内部按电量填充（<20% BC_WARN，充电 BC_OK）——用 lv_obj 两层矩形或 canvas 绘制 */
  lv_obj_t *o_lbl_bat = mk_label(scr, &badge_f16, lv_color_hex(0xB9A88F), "82%", LV_ALIGN_LEFT_MID, 244, -121); /* 动态：{bat}% */
  lv_obj_t *o_arc_food = lv_arc_create(scr); lv_obj_set_size(o_arc_food, 436, 436); lv_obj_align(o_arc_food, LV_ALIGN_CENTER, 0, 0); lv_arc_set_rotation(o_arc_food, 0); lv_arc_set_bg_angles(o_arc_food, 119, 133); lv_arc_set_range(o_arc_food, 0, 100); lv_arc_set_value(o_arc_food, 65);
  lv_obj_set_style_arc_width(o_arc_food, 8, LV_PART_MAIN); lv_obj_set_style_arc_width(o_arc_food, 8, LV_PART_INDICATOR); lv_obj_set_style_arc_color(o_arc_food, lv_color_hex(0x4A3E33), LV_PART_MAIN); lv_obj_set_style_arc_color(o_arc_food, lv_color_hex(0xF0BF73), LV_PART_INDICATOR); lv_obj_set_style_arc_rounded(o_arc_food, false, 0); lv_obj_remove_style(o_arc_food, NULL, LV_PART_KNOB); lv_obj_clear_flag(o_arc_food, LV_OBJ_FLAG_CLICKABLE); lv_arc_set_mode(o_arc_food, LV_ARC_MODE_REVERSE); /* 状态：food */
  lv_obj_t *o_arc_mood = lv_arc_create(scr); lv_obj_set_size(o_arc_mood, 436, 436); lv_obj_align(o_arc_mood, LV_ALIGN_CENTER, 0, 0); lv_arc_set_rotation(o_arc_mood, 0); lv_arc_set_bg_angles(o_arc_mood, 101, 115); lv_arc_set_range(o_arc_mood, 0, 100); lv_arc_set_value(o_arc_mood, 65);
  lv_obj_set_style_arc_width(o_arc_mood, 8, LV_PART_MAIN); lv_obj_set_style_arc_width(o_arc_mood, 8, LV_PART_INDICATOR); lv_obj_set_style_arc_color(o_arc_mood, lv_color_hex(0x4A3E33), LV_PART_MAIN); lv_obj_set_style_arc_color(o_arc_mood, lv_color_hex(0xF29AA8), LV_PART_INDICATOR); lv_obj_set_style_arc_rounded(o_arc_mood, false, 0); lv_obj_remove_style(o_arc_mood, NULL, LV_PART_KNOB); lv_obj_clear_flag(o_arc_mood, LV_OBJ_FLAG_CLICKABLE); lv_arc_set_mode(o_arc_mood, LV_ARC_MODE_REVERSE); /* 状态：mood */
  lv_obj_t *o_arc_clean = lv_arc_create(scr); lv_obj_set_size(o_arc_clean, 436, 436); lv_obj_align(o_arc_clean, LV_ALIGN_CENTER, 0, 0); lv_arc_set_rotation(o_arc_clean, 0); lv_arc_set_bg_angles(o_arc_clean, 83, 97); lv_arc_set_range(o_arc_clean, 0, 100); lv_arc_set_value(o_arc_clean, 65);
  lv_obj_set_style_arc_width(o_arc_clean, 8, LV_PART_MAIN); lv_obj_set_style_arc_width(o_arc_clean, 8, LV_PART_INDICATOR); lv_obj_set_style_arc_color(o_arc_clean, lv_color_hex(0x4A3E33), LV_PART_MAIN); lv_obj_set_style_arc_color(o_arc_clean, lv_color_hex(0x8FC7E0), LV_PART_INDICATOR); lv_obj_set_style_arc_rounded(o_arc_clean, false, 0); lv_obj_remove_style(o_arc_clean, NULL, LV_PART_KNOB); lv_obj_clear_flag(o_arc_clean, LV_OBJ_FLAG_CLICKABLE); lv_arc_set_mode(o_arc_clean, LV_ARC_MODE_REVERSE); /* 状态：clean */
  lv_obj_t *o_arc_energy = lv_arc_create(scr); lv_obj_set_size(o_arc_energy, 436, 436); lv_obj_align(o_arc_energy, LV_ALIGN_CENTER, 0, 0); lv_arc_set_rotation(o_arc_energy, 0); lv_arc_set_bg_angles(o_arc_energy, 65, 79); lv_arc_set_range(o_arc_energy, 0, 100); lv_arc_set_value(o_arc_energy, 65);
  lv_obj_set_style_arc_width(o_arc_energy, 8, LV_PART_MAIN); lv_obj_set_style_arc_width(o_arc_energy, 8, LV_PART_INDICATOR); lv_obj_set_style_arc_color(o_arc_energy, lv_color_hex(0x4A3E33), LV_PART_MAIN); lv_obj_set_style_arc_color(o_arc_energy, lv_color_hex(0xA8D88E), LV_PART_INDICATOR); lv_obj_set_style_arc_rounded(o_arc_energy, false, 0); lv_obj_remove_style(o_arc_energy, NULL, LV_PART_KNOB); lv_obj_clear_flag(o_arc_energy, LV_OBJ_FLAG_CLICKABLE); lv_arc_set_mode(o_arc_energy, LV_ARC_MODE_REVERSE); /* 状态：energy */
  lv_obj_t *o_arc_health = lv_arc_create(scr); lv_obj_set_size(o_arc_health, 436, 436); lv_obj_align(o_arc_health, LV_ALIGN_CENTER, 0, 0); lv_arc_set_rotation(o_arc_health, 0); lv_arc_set_bg_angles(o_arc_health, 47, 61); lv_arc_set_range(o_arc_health, 0, 100); lv_arc_set_value(o_arc_health, 65);
  lv_obj_set_style_arc_width(o_arc_health, 8, LV_PART_MAIN); lv_obj_set_style_arc_width(o_arc_health, 8, LV_PART_INDICATOR); lv_obj_set_style_arc_color(o_arc_health, lv_color_hex(0x4A3E33), LV_PART_MAIN); lv_obj_set_style_arc_color(o_arc_health, lv_color_hex(0xFF8A8A), LV_PART_INDICATOR); lv_obj_set_style_arc_rounded(o_arc_health, false, 0); lv_obj_remove_style(o_arc_health, NULL, LV_PART_KNOB); lv_obj_clear_flag(o_arc_health, LV_OBJ_FLAG_CLICKABLE); lv_arc_set_mode(o_arc_health, LV_ARC_MODE_REVERSE); /* 状态：health */
  /* alert（alert）：自绘元素，参数见 badge_ui_spec.h 与规范页「当前画面」 */
  /* 触摸热区 hit_cat：圆心 (233,262) 半径 110 → pet（在屏幕的 LV_EVENT_CLICKED 里按坐标判断） */
  return scr;
}

/* ===== main_b：主表盘 B · 24 小时时间环 ===== */
/* 外圈是主人的一天，内圈是小猫的一天，白点为现在；与 App「今日生活」同一份数据。 */
/* 进入：主表盘左右滑 */
lv_obj_t *badge_build_main_b(void){
  lv_obj_t *scr = mk_scr();
  badge_cat_layer_create(scr, UI_MAIN_B_CAT_DIST, UI_MAIN_B_CAT_OX, UI_MAIN_B_CAT_OY, UI_MAIN_B_CAT_DIM_PCT); /* 3D 小猫在最底层 */
  /* ring（dayring）：自绘元素，参数见 badge_ui_spec.h 与规范页「当前画面」 */
  lv_obj_t *o_ico_bt = mk_icon(scr, "bt", 1, -37, -173); /* 仅当 phone 时显示 */
  lv_obj_t *o_ico_bt_off = mk_icon(scr, "bt_off", 1, -37, -173); /* 仅当 !phone 时显示 */
  /* 电池图标 22×12，中心 (226,60)：外框 2px BC_SUB，右侧电极 2×6；内部按电量填充（<20% BC_WARN，充电 BC_OK）——用 lv_obj 两层矩形或 canvas 绘制 */
  lv_obj_t *o_lbl_bat = mk_label(scr, &badge_f16, lv_color_hex(0xB9A88F), "82%", LV_ALIGN_LEFT_MID, 244, -173); /* 动态：{bat}% */
  lv_obj_t *o_time = mk_label(scr, &badge_n40, lv_color_hex(0xFFF4E0), "09:41", LV_ALIGN_CENTER, 0, 165); /* 动态：{time} */
  /* alert（alert）：自绘元素，参数见 badge_ui_spec.h 与规范页「当前画面」 */
  /* 触摸热区 hit_cat：圆心 (233,245) 半径 110 → pet（在屏幕的 LV_EVENT_CLICKED 里按坐标判断） */
  return scr;
}

/* ===== main_c：主表盘 C · 时间环 + 心动 ===== */
/* 在 B 的基础上，把今天的心动时刻画成小爱心。 */
/* 进入：主表盘左右滑 */
lv_obj_t *badge_build_main_c(void){
  lv_obj_t *scr = mk_scr();
  badge_cat_layer_create(scr, UI_MAIN_C_CAT_DIST, UI_MAIN_C_CAT_OX, UI_MAIN_C_CAT_OY, UI_MAIN_C_CAT_DIM_PCT); /* 3D 小猫在最底层 */
  /* ring（dayring）：自绘元素，参数见 badge_ui_spec.h 与规范页「当前画面」 */
  lv_obj_t *o_ico_bt = mk_icon(scr, "bt", 1, -37, -173); /* 仅当 phone 时显示 */
  lv_obj_t *o_ico_bt_off = mk_icon(scr, "bt_off", 1, -37, -173); /* 仅当 !phone 时显示 */
  /* 电池图标 22×12，中心 (226,60)：外框 2px BC_SUB，右侧电极 2×6；内部按电量填充（<20% BC_WARN，充电 BC_OK）——用 lv_obj 两层矩形或 canvas 绘制 */
  lv_obj_t *o_lbl_bat = mk_label(scr, &badge_f16, lv_color_hex(0xB9A88F), "82%", LV_ALIGN_LEFT_MID, 244, -173); /* 动态：{bat}% */
  lv_obj_t *o_time = mk_label(scr, &badge_n40, lv_color_hex(0xFFF4E0), "09:41", LV_ALIGN_CENTER, 0, 165); /* 动态：{time} */
  /* alert（alert）：自绘元素，参数见 badge_ui_spec.h 与规范页「当前画面」 */
  /* 触摸热区 hit_cat：圆心 (233,245) 半径 110 → pet（在屏幕的 LV_EVENT_CLICKED 里按坐标判断） */
  return scr;
}

/* ===== aod：待机常显 ===== */
/* 只画一帧，亮度 35%，每分钟重画时间。 */
/* 进入：陪伴态 30 秒无操作；退出：抬起手腕 / 触摸 / 唤醒词 → 回到主表盘（互动态） */
lv_obj_t *badge_build_aod(void){
  lv_obj_t *scr = mk_scr();
  badge_cat_layer_create(scr, UI_AOD_CAT_DIST, UI_AOD_CAT_OX, UI_AOD_CAT_OY, UI_AOD_CAT_DIM_PCT); /* 3D 小猫在最底层 */
  lv_obj_t *o_time = mk_label(scr, &badge_n40, lv_color_hex(0xB9A88F), "09:41", LV_ALIGN_CENTER, 0, 165); /* 动态：{time} */
  /* 触摸热区 hit_wake：圆心 (233,233) 半径 233 → wake（在屏幕的 LV_EVENT_CLICKED 里按坐标判断） */
  return scr;
}

/* ===== care_menu：照料轮盘 ===== */
/* 吧唧上只放 4 种能在小屏上亲手完成的照料；洗澡、诊所、换装、出门留在 App。不能做时按钮变灰并写原因。 */
/* 进入：主表盘上滑；点头顶提醒；命令词；退出：下滑返回主表盘 */
lv_obj_t *badge_build_care_menu(void){
  lv_obj_t *scr = mk_scr();
  badge_cat_layer_create(scr, UI_CARE_MENU_CAT_DIST, UI_CARE_MENU_CAT_OX, UI_CARE_MENU_CAT_OY, UI_CARE_MENU_CAT_DIM_PCT); /* 3D 小猫在最底层 */
  lv_obj_t *o_title = mk_label(scr, &badge_f24, lv_color_hex(0xFFF4E0), "照料", LV_ALIGN_CENTER, 0, -177);
  lv_obj_t *o_sub = mk_label(scr, &badge_f16, lv_color_hex(0xB9A88F), "喵币 30 · 下滑返回", LV_ALIGN_CENTER, 0, -145); /* 动态：喵币 {coins} · 下滑返回 */
  lv_obj_t *o_btn_feed = lv_btn_create(scr); lv_obj_set_size(o_btn_feed, 72, 72); lv_obj_set_style_radius(o_btn_feed, LV_RADIUS_CIRCLE, 0); lv_obj_set_style_bg_color(o_btn_feed, lv_color_hex(0x241D17), 0); lv_obj_set_style_shadow_width(o_btn_feed, 0, 0); lv_obj_align(o_btn_feed, LV_ALIGN_CENTER, -128, 89);
  mk_icon(o_btn_feed, "bowl", 3, 0, 0); /* 点击：care:feed */
  lv_obj_t *o_lbl_feed = mk_label(scr, &badge_f16, lv_color_hex(0xFFF4E0), "喂食", LV_ALIGN_CENTER, -128, 141); /* 动态：{careLabel:feed} */
  lv_obj_t *o_btn_water = lv_btn_create(scr); lv_obj_set_size(o_btn_water, 72, 72); lv_obj_set_style_radius(o_btn_water, LV_RADIUS_CIRCLE, 0); lv_obj_set_style_bg_color(o_btn_water, lv_color_hex(0x241D17), 0); lv_obj_set_style_shadow_width(o_btn_water, 0, 0); lv_obj_align(o_btn_water, LV_ALIGN_CENTER, -43, 119);
  mk_icon(o_btn_water, "water", 3, 0, 0); /* 点击：care:water */
  lv_obj_t *o_lbl_water = mk_label(scr, &badge_f16, lv_color_hex(0xFFF4E0), "喝水", LV_ALIGN_CENTER, -43, 171); /* 动态：{careLabel:water} */
  lv_obj_t *o_btn_play = lv_btn_create(scr); lv_obj_set_size(o_btn_play, 72, 72); lv_obj_set_style_radius(o_btn_play, LV_RADIUS_CIRCLE, 0); lv_obj_set_style_bg_color(o_btn_play, lv_color_hex(0x241D17), 0); lv_obj_set_style_shadow_width(o_btn_play, 0, 0); lv_obj_align(o_btn_play, LV_ALIGN_CENTER, 43, 119);
  mk_icon(o_btn_play, "feather", 3, 0, 0); /* 点击：care:play */
  lv_obj_t *o_lbl_play = mk_label(scr, &badge_f16, lv_color_hex(0xFFF4E0), "逗猫", LV_ALIGN_CENTER, 43, 171); /* 动态：{careLabel:play} */
  lv_obj_t *o_btn_sleep = lv_btn_create(scr); lv_obj_set_size(o_btn_sleep, 72, 72); lv_obj_set_style_radius(o_btn_sleep, LV_RADIUS_CIRCLE, 0); lv_obj_set_style_bg_color(o_btn_sleep, lv_color_hex(0x241D17), 0); lv_obj_set_style_shadow_width(o_btn_sleep, 0, 0); lv_obj_align(o_btn_sleep, LV_ALIGN_CENTER, 128, 89);
  mk_icon(o_btn_sleep, "moon", 3, 0, 0); /* 点击：care:sleep */
  lv_obj_t *o_lbl_sleep = mk_label(scr, &badge_f16, lv_color_hex(0xFFF4E0), "睡觉", LV_ALIGN_CENTER, 128, 141); /* 动态：{careLabel:sleep} */
  return scr;
}

/* ===== care_feed：喂食中 ===== */
/* 点碗 3 次，每次一口（挥爪动画）。3 口完成后结算，返回主表盘并提示数值。 */
/* 进入：照料轮盘点「喂食」；命令词「吃饭啦」；退出：完成自动返回；下滑 = 先休息（不扣钱、不加成长） */
lv_obj_t *badge_build_care_feed(void){
  lv_obj_t *scr = mk_scr();
  badge_cat_layer_create(scr, UI_CARE_FEED_CAT_DIST, UI_CARE_FEED_CAT_OX, UI_CARE_FEED_CAT_OY, UI_CARE_FEED_CAT_DIM_PCT); /* 3D 小猫在最底层 */
  /* prog（segs）：自绘元素，参数见 badge_ui_spec.h 与规范页「当前画面」 */
  lv_obj_t *o_title = mk_label(scr, &badge_f24, lv_color_hex(0xFFF4E0), "喂食 0/3", LV_ALIGN_CENTER, 0, -171); /* 动态：喂食 {step}/3 */
  lv_obj_t *o_hint = mk_label(scr, &badge_f16, lv_color_hex(0xB9A88F), "点碗喂一口 · 下滑先休息", LV_ALIGN_CENTER, 0, -139);
  lv_obj_t *o_btn_bowl = lv_btn_create(scr); lv_obj_set_size(o_btn_bowl, 80, 80); lv_obj_set_style_radius(o_btn_bowl, LV_RADIUS_CIRCLE, 0); lv_obj_set_style_bg_color(o_btn_bowl, lv_color_hex(0x241D17), 0); lv_obj_set_style_shadow_width(o_btn_bowl, 0, 0); lv_obj_set_style_border_color(o_btn_bowl, lv_color_hex(0xF0A35E), 0); lv_obj_set_style_border_width(o_btn_bowl, 3, 0); lv_obj_align(o_btn_bowl, LV_ALIGN_CENTER, 0, 143);
  mk_icon(o_btn_bowl, "bowl", 3, 0, 0); /* 点击：bite */
  return scr;
}

/* ===== care_water：喝水中 ===== */
/* 点水碗 3 次。 */
/* 进入：照料轮盘点「喝水」；命令词「喝水啦」；退出：同喂食 */
lv_obj_t *badge_build_care_water(void){
  lv_obj_t *scr = mk_scr();
  badge_cat_layer_create(scr, UI_CARE_WATER_CAT_DIST, UI_CARE_WATER_CAT_OX, UI_CARE_WATER_CAT_OY, UI_CARE_WATER_CAT_DIM_PCT); /* 3D 小猫在最底层 */
  /* prog（segs）：自绘元素，参数见 badge_ui_spec.h 与规范页「当前画面」 */
  lv_obj_t *o_title = mk_label(scr, &badge_f24, lv_color_hex(0xFFF4E0), "喝水 0/3", LV_ALIGN_CENTER, 0, -171); /* 动态：喝水 {step}/3 */
  lv_obj_t *o_hint = mk_label(scr, &badge_f16, lv_color_hex(0xB9A88F), "点水碗喝一口 · 下滑先休息", LV_ALIGN_CENTER, 0, -139);
  lv_obj_t *o_btn_bowl = lv_btn_create(scr); lv_obj_set_size(o_btn_bowl, 80, 80); lv_obj_set_style_radius(o_btn_bowl, LV_RADIUS_CIRCLE, 0); lv_obj_set_style_bg_color(o_btn_bowl, lv_color_hex(0x241D17), 0); lv_obj_set_style_shadow_width(o_btn_bowl, 0, 0); lv_obj_set_style_border_color(o_btn_bowl, lv_color_hex(0x8FC7E0), 0); lv_obj_set_style_border_width(o_btn_bowl, 3, 0); lv_obj_align(o_btn_bowl, LV_ALIGN_CENTER, 0, 143);
  mk_icon(o_btn_bowl, "water", 3, 0, 0); /* 点击：bite */
  return scr;
}

/* ===== care_play：逗猫中 ===== */
/* 手指在屏幕上移动，羽毛跟着手指，小猫的头跟着看；快速划动（>900 像素/秒）小猫扑一下。扑满 5 次完成；25 秒没完成算取消。 */
/* 进入：照料轮盘点「逗猫」；命令词「陪我玩」；退出：完成自动返回；下滑起手 = 先休息 */
lv_obj_t *badge_build_care_play(void){
  lv_obj_t *scr = mk_scr();
  badge_cat_layer_create(scr, UI_CARE_PLAY_CAT_DIST, UI_CARE_PLAY_CAT_OX, UI_CARE_PLAY_CAT_OY, UI_CARE_PLAY_CAT_DIM_PCT); /* 3D 小猫在最底层 */
  /* prog（segs）：自绘元素，参数见 badge_ui_spec.h 与规范页「当前画面」 */
  lv_obj_t *o_title = mk_label(scr, &badge_f24, lv_color_hex(0xFFF4E0), "逗猫 0/5", LV_ALIGN_CENTER, 0, -171); /* 动态：逗猫 {step}/5 */
  lv_obj_t *o_hint = mk_label(scr, &badge_f16, lv_color_hex(0xB9A88F), "快速划动，逗它扑", LV_ALIGN_CENTER, 0, -139);
  /* feather（feather）：自绘元素，参数见 badge_ui_spec.h 与规范页「当前画面」 */
  return scr;
}

/* ===== care_sleep：哄睡 ===== */
/* 按住月亮 1.5 秒「关灯」，小猫睡着（画面压暗到 25%），演示 6 秒后醒来结算。 */
/* 进入：照料轮盘点「睡觉」；命令词「去睡觉」；退出：完成自动返回；下滑 = 先休息 */
lv_obj_t *badge_build_care_sleep(void){
  lv_obj_t *scr = mk_scr();
  badge_cat_layer_create(scr, UI_CARE_SLEEP_CAT_DIST, UI_CARE_SLEEP_CAT_OX, UI_CARE_SLEEP_CAT_OY, UI_CARE_SLEEP_CAT_DIM_PCT); /* 3D 小猫在最底层 */
  lv_obj_t *o_title = mk_label(scr, &badge_f24, lv_color_hex(0xFFF4E0), "睡觉", LV_ALIGN_CENTER, 0, -171);
  lv_obj_t *o_hint = mk_label(scr, &badge_f16, lv_color_hex(0xB9A88F), "按住月亮 1.5 秒关灯", LV_ALIGN_CENTER, 0, -139);
  lv_obj_t *o_btn_moon = lv_btn_create(scr); lv_obj_set_size(o_btn_moon, 80, 80); lv_obj_set_style_radius(o_btn_moon, LV_RADIUS_CIRCLE, 0); lv_obj_set_style_bg_color(o_btn_moon, lv_color_hex(0x241D17), 0); lv_obj_set_style_shadow_width(o_btn_moon, 0, 0); lv_obj_align(o_btn_moon, LV_ALIGN_CENTER, 0, 143);
  mk_icon(o_btn_moon, "moon", 3, 0, 0); /* 点击：hold（按住 1.5 秒） */
  return scr;
}

/* ===== sleeping：睡着了 ===== */
/* 屏幕压暗，飘出 Zzz。 */
/* 进入：哄睡按住完成；退出：演示 6 秒后自动醒来 */
lv_obj_t *badge_build_sleeping(void){
  lv_obj_t *scr = mk_scr();
  badge_cat_layer_create(scr, UI_SLEEPING_CAT_DIST, UI_SLEEPING_CAT_OX, UI_SLEEPING_CAT_OY, UI_SLEEPING_CAT_DIM_PCT); /* 3D 小猫在最底层 */
  lv_obj_t *o_hint = mk_label(scr, &badge_f16, lv_color_hex(0xB9A88F), "嘘…小橘睡着了", LV_ALIGN_CENTER, 0, -139); /* 动态：{sleepNow} */
  /* zzz（zzz）：自绘元素，参数见 badge_ui_spec.h 与规范页「当前画面」 */
  return scr;
}

/* ===== status：状态 ===== */
/* 五项状态 + 成长 + 喵币 + 设备状态。点某一项直接去对应照料。 */
/* 进入：主表盘下滑；命令词「看看状态」；退出：上滑返回主表盘 */
lv_obj_t *badge_build_status(void){
  lv_obj_t *scr = mk_scr();
  lv_obj_t *o_name = mk_label(scr, &badge_f24, lv_color_hex(0xFFF4E0), "小橘", LV_ALIGN_CENTER, 0, -171); /* 动态：{name} */
  lv_obj_t *o_stage = mk_label(scr, &badge_f16, lv_color_hex(0xB9A88F), "少年猫 · 成长 86/160", LV_ALIGN_CENTER, 0, -139); /* 动态：{stage} · 成长 {growth}/{nextGrowth} */
  lv_obj_t *o_lbl_food = mk_label(scr, &badge_f16, lv_color_hex(0xB9A88F), "饱腹", LV_ALIGN_LEFT_MID, 90, -97);
  lv_obj_t *o_bar_food = lv_bar_create(scr); lv_obj_set_size(o_bar_food, 190, 10); lv_obj_align(o_bar_food, LV_ALIGN_TOP_LEFT, 140, 131); lv_bar_set_range(o_bar_food, 0, 100); lv_bar_set_value(o_bar_food, 65, LV_ANIM_OFF);
  lv_obj_set_style_bg_color(o_bar_food, lv_color_hex(0x4A3E33), LV_PART_MAIN); lv_obj_set_style_bg_color(o_bar_food, lv_color_hex(0xF0BF73), LV_PART_INDICATOR); lv_obj_set_style_radius(o_bar_food, 5, 0); /* 低于 30 时指示条改用 BC_WARN */
  lv_obj_t *o_val_food = mk_label(scr, &badge_f16, lv_color_hex(0xFFF4E0), "65", LV_ALIGN_RIGHT_MID, -90, -97); /* 动态：{food} */
  /* 触摸热区 hit_food：中心 (233,136) 300×34 → stat:food（在屏幕的 LV_EVENT_CLICKED 里按坐标判断） */
  lv_obj_t *o_lbl_mood = mk_label(scr, &badge_f16, lv_color_hex(0xB9A88F), "心情", LV_ALIGN_LEFT_MID, 90, -61);
  lv_obj_t *o_bar_mood = lv_bar_create(scr); lv_obj_set_size(o_bar_mood, 190, 10); lv_obj_align(o_bar_mood, LV_ALIGN_TOP_LEFT, 140, 167); lv_bar_set_range(o_bar_mood, 0, 100); lv_bar_set_value(o_bar_mood, 65, LV_ANIM_OFF);
  lv_obj_set_style_bg_color(o_bar_mood, lv_color_hex(0x4A3E33), LV_PART_MAIN); lv_obj_set_style_bg_color(o_bar_mood, lv_color_hex(0xF29AA8), LV_PART_INDICATOR); lv_obj_set_style_radius(o_bar_mood, 5, 0); /* 低于 30 时指示条改用 BC_WARN */
  lv_obj_t *o_val_mood = mk_label(scr, &badge_f16, lv_color_hex(0xFFF4E0), "65", LV_ALIGN_RIGHT_MID, -90, -61); /* 动态：{mood} */
  /* 触摸热区 hit_mood：中心 (233,172) 300×34 → stat:mood（在屏幕的 LV_EVENT_CLICKED 里按坐标判断） */
  lv_obj_t *o_lbl_clean = mk_label(scr, &badge_f16, lv_color_hex(0xB9A88F), "清洁", LV_ALIGN_LEFT_MID, 90, -25);
  lv_obj_t *o_bar_clean = lv_bar_create(scr); lv_obj_set_size(o_bar_clean, 190, 10); lv_obj_align(o_bar_clean, LV_ALIGN_TOP_LEFT, 140, 203); lv_bar_set_range(o_bar_clean, 0, 100); lv_bar_set_value(o_bar_clean, 65, LV_ANIM_OFF);
  lv_obj_set_style_bg_color(o_bar_clean, lv_color_hex(0x4A3E33), LV_PART_MAIN); lv_obj_set_style_bg_color(o_bar_clean, lv_color_hex(0x8FC7E0), LV_PART_INDICATOR); lv_obj_set_style_radius(o_bar_clean, 5, 0); /* 低于 30 时指示条改用 BC_WARN */
  lv_obj_t *o_val_clean = mk_label(scr, &badge_f16, lv_color_hex(0xFFF4E0), "65", LV_ALIGN_RIGHT_MID, -90, -25); /* 动态：{clean} */
  /* 触摸热区 hit_clean：中心 (233,208) 300×34 → stat:clean（在屏幕的 LV_EVENT_CLICKED 里按坐标判断） */
  lv_obj_t *o_lbl_energy = mk_label(scr, &badge_f16, lv_color_hex(0xB9A88F), "精力", LV_ALIGN_LEFT_MID, 90, 11);
  lv_obj_t *o_bar_energy = lv_bar_create(scr); lv_obj_set_size(o_bar_energy, 190, 10); lv_obj_align(o_bar_energy, LV_ALIGN_TOP_LEFT, 140, 239); lv_bar_set_range(o_bar_energy, 0, 100); lv_bar_set_value(o_bar_energy, 65, LV_ANIM_OFF);
  lv_obj_set_style_bg_color(o_bar_energy, lv_color_hex(0x4A3E33), LV_PART_MAIN); lv_obj_set_style_bg_color(o_bar_energy, lv_color_hex(0xA8D88E), LV_PART_INDICATOR); lv_obj_set_style_radius(o_bar_energy, 5, 0); /* 低于 30 时指示条改用 BC_WARN */
  lv_obj_t *o_val_energy = mk_label(scr, &badge_f16, lv_color_hex(0xFFF4E0), "65", LV_ALIGN_RIGHT_MID, -90, 11); /* 动态：{energy} */
  /* 触摸热区 hit_energy：中心 (233,244) 300×34 → stat:energy（在屏幕的 LV_EVENT_CLICKED 里按坐标判断） */
  lv_obj_t *o_lbl_health = mk_label(scr, &badge_f16, lv_color_hex(0xB9A88F), "健康", LV_ALIGN_LEFT_MID, 90, 47);
  lv_obj_t *o_bar_health = lv_bar_create(scr); lv_obj_set_size(o_bar_health, 190, 10); lv_obj_align(o_bar_health, LV_ALIGN_TOP_LEFT, 140, 275); lv_bar_set_range(o_bar_health, 0, 100); lv_bar_set_value(o_bar_health, 65, LV_ANIM_OFF);
  lv_obj_set_style_bg_color(o_bar_health, lv_color_hex(0x4A3E33), LV_PART_MAIN); lv_obj_set_style_bg_color(o_bar_health, lv_color_hex(0xFF8A8A), LV_PART_INDICATOR); lv_obj_set_style_radius(o_bar_health, 5, 0); /* 低于 30 时指示条改用 BC_WARN */
  lv_obj_t *o_val_health = mk_label(scr, &badge_f16, lv_color_hex(0xFFF4E0), "65", LV_ALIGN_RIGHT_MID, -90, 47); /* 动态：{health} */
  /* 触摸热区 hit_health：中心 (233,280) 300×34 → stat:health（在屏幕的 LV_EVENT_CLICKED 里按坐标判断） */
  lv_obj_t *o_ico_coin = mk_icon(scr, "coin", 1.5, -27, 89);
  lv_obj_t *o_coins = mk_label(scr, &badge_f20, lv_color_hex(0xF6C85F), "30", LV_ALIGN_LEFT_MID, 222, 89); /* 动态：{coins} */
  lv_obj_t *o_dev = mk_label(scr, &badge_f16, lv_color_hex(0xB9A88F), "电量 82% · 手机已连接", LV_ALIGN_CENTER, 0, 121); /* 动态：电量 {bat}% · {phoneText} */
  lv_obj_t *o_sync = mk_label(scr, &badge_f16, lv_color_hex(0x6E6253), "已同步", LV_ALIGN_CENTER, 0, 147); /* 动态：{syncText} */
  lv_obj_t *o_btn_gear = lv_btn_create(scr); lv_obj_set_size(o_btn_gear, 48, 48); lv_obj_set_style_radius(o_btn_gear, LV_RADIUS_CIRCLE, 0); lv_obj_set_style_bg_color(o_btn_gear, lv_color_hex(0x241D17), 0); lv_obj_set_style_shadow_width(o_btn_gear, 0, 0); lv_obj_align(o_btn_gear, LV_ALIGN_CENTER, 0, 181);
  mk_icon(o_btn_gear, "gear", 2, 0, 0); /* 点击：settings */
  return scr;
}

/* ===== settings：设置 ===== */
/* 吧唧上只放 4 个最常用的开关，其余在 App 里改。 */
/* 进入：状态页点齿轮；退出：右滑返回状态页 */
lv_obj_t *badge_build_settings(void){
  lv_obj_t *scr = mk_scr();
  lv_obj_t *o_title = mk_label(scr, &badge_f24, lv_color_hex(0xFFF4E0), "设置", LV_ALIGN_CENTER, 0, -171);
  lv_obj_t *o_lbl_bright = mk_label(scr, &badge_f20, lv_color_hex(0xFFF4E0), "亮度", LV_ALIGN_LEFT_MID, 86, -107);
  lv_obj_t *o_val_bright = mk_label(scr, &badge_f20, lv_color_hex(0xF0A35E), "中", LV_ALIGN_RIGHT_MID, -86, -107); /* 动态：{brightText} */
  /* 触摸热区 hit_bright：中心 (233,126) 310×48 → set:bright（在屏幕的 LV_EVENT_CLICKED 里按坐标判断） */
  lv_obj_t *o_lbl_wake = mk_label(scr, &badge_f20, lv_color_hex(0xFFF4E0), "唤醒词「小橘小橘」", LV_ALIGN_LEFT_MID, 86, -55);
  lv_obj_t *o_tg_wake = lv_switch_create(scr); lv_obj_set_size(o_tg_wake, 52, 28); lv_obj_align(o_tg_wake, LV_ALIGN_RIGHT_MID, -86, -55); lv_obj_set_style_bg_color(o_tg_wake, lv_color_hex(0x4A3E33), LV_PART_MAIN); lv_obj_set_style_bg_color(o_tg_wake, lv_color_hex(0xF0A35E), LV_PART_INDICATOR | LV_STATE_CHECKED); /* 设置：wake */
  /* 触摸热区 hit_wake：中心 (233,178) 310×48 → set:wake（在屏幕的 LV_EVENT_CLICKED 里按坐标判断） */
  lv_obj_t *o_lbl_discover = mk_label(scr, &badge_f20, lv_color_hex(0xFFF4E0), "附近可被发现", LV_ALIGN_LEFT_MID, 86, -3);
  lv_obj_t *o_tg_discover = lv_switch_create(scr); lv_obj_set_size(o_tg_discover, 52, 28); lv_obj_align(o_tg_discover, LV_ALIGN_RIGHT_MID, -86, -3); lv_obj_set_style_bg_color(o_tg_discover, lv_color_hex(0x4A3E33), LV_PART_MAIN); lv_obj_set_style_bg_color(o_tg_discover, lv_color_hex(0xF0A35E), LV_PART_INDICATOR | LV_STATE_CHECKED); /* 设置：discover */
  /* 触摸热区 hit_discover：中心 (233,230) 310×48 → set:discover（在屏幕的 LV_EVENT_CLICKED 里按坐标判断） */
  lv_obj_t *o_lbl_aod = mk_label(scr, &badge_f20, lv_color_hex(0xFFF4E0), "息屏常显", LV_ALIGN_LEFT_MID, 86, 49);
  lv_obj_t *o_tg_aod = lv_switch_create(scr); lv_obj_set_size(o_tg_aod, 52, 28); lv_obj_align(o_tg_aod, LV_ALIGN_RIGHT_MID, -86, 49); lv_obj_set_style_bg_color(o_tg_aod, lv_color_hex(0x4A3E33), LV_PART_MAIN); lv_obj_set_style_bg_color(o_tg_aod, lv_color_hex(0xF0A35E), LV_PART_INDICATOR | LV_STATE_CHECKED); /* 设置：aod */
  /* 触摸热区 hit_aod：中心 (233,282) 310×48 → set:aod（在屏幕的 LV_EVENT_CLICKED 里按坐标判断） */
  lv_obj_t *o_foot = mk_label(scr, &badge_f16, lv_color_hex(0x6E6253), "右滑返回 · 固件 0.3.0", LV_ALIGN_CENTER, 0, 113); /* 动态：右滑返回 · 固件 {ver} */
  /* 触摸热区 hit_ver：中心 (233,346) 200×40 → ver（长按 3 秒，用 LV_EVENT_LONG_PRESSED 计时）（在屏幕的 LV_EVENT_CLICKED 里按坐标判断） */
  return scr;
}

/* ===== touch_test：触摸自检（开发用） ===== */
/* 确认触摸方向（第十二章 12.6 未验证项）。屏幕上 5 个靶点（左上、右上、右下、左下、中心），手指点哪个，哪个变绿，并显示换算后的坐标。5 个都对 = 方向正确；点左上却是右下变绿 = 镜像设置反了（板级支持包 touch_flags 应为 不交换轴、X/Y 都镜像）。坐标出现 466 = 镜像越界，要钳到 465。 */
/* 进入：设置页长按底部「固件 版本」3 秒；退出：5 个靶点都点中后 1 秒自动回到设置；右滑返回 */
lv_obj_t *badge_build_touch_test(void){
  lv_obj_t *scr = mk_scr();
  lv_obj_t *o_title = mk_label(scr, &badge_f24, lv_color_hex(0xFFF4E0), "触摸自检", LV_ALIGN_CENTER, 0, -169);
  lv_obj_t *o_tt_1 = lv_btn_create(scr); lv_obj_set_size(o_tt_1, 52, 52); lv_obj_set_style_radius(o_tt_1, 26, 0); lv_obj_set_style_bg_color(o_tt_1, lv_color_hex(0x241D17), 0); lv_obj_set_style_shadow_width(o_tt_1, 0, 0); lv_obj_align(o_tt_1, LV_ALIGN_CENTER, -120, -120);
  mk_label(o_tt_1, &badge_f20, lv_color_hex(0xFFF4E0), "1", LV_ALIGN_CENTER, 0, 0); /* 点击：tt:1 */
  lv_obj_t *o_tt_2 = lv_btn_create(scr); lv_obj_set_size(o_tt_2, 52, 52); lv_obj_set_style_radius(o_tt_2, 26, 0); lv_obj_set_style_bg_color(o_tt_2, lv_color_hex(0x241D17), 0); lv_obj_set_style_shadow_width(o_tt_2, 0, 0); lv_obj_align(o_tt_2, LV_ALIGN_CENTER, 120, -120);
  mk_label(o_tt_2, &badge_f20, lv_color_hex(0xFFF4E0), "2", LV_ALIGN_CENTER, 0, 0); /* 点击：tt:2 */
  lv_obj_t *o_tt_3 = lv_btn_create(scr); lv_obj_set_size(o_tt_3, 52, 52); lv_obj_set_style_radius(o_tt_3, 26, 0); lv_obj_set_style_bg_color(o_tt_3, lv_color_hex(0x241D17), 0); lv_obj_set_style_shadow_width(o_tt_3, 0, 0); lv_obj_align(o_tt_3, LV_ALIGN_CENTER, 120, 120);
  mk_label(o_tt_3, &badge_f20, lv_color_hex(0xFFF4E0), "3", LV_ALIGN_CENTER, 0, 0); /* 点击：tt:3 */
  lv_obj_t *o_tt_4 = lv_btn_create(scr); lv_obj_set_size(o_tt_4, 52, 52); lv_obj_set_style_radius(o_tt_4, 26, 0); lv_obj_set_style_bg_color(o_tt_4, lv_color_hex(0x241D17), 0); lv_obj_set_style_shadow_width(o_tt_4, 0, 0); lv_obj_align(o_tt_4, LV_ALIGN_CENTER, -120, 120);
  mk_label(o_tt_4, &badge_f20, lv_color_hex(0xFFF4E0), "4", LV_ALIGN_CENTER, 0, 0); /* 点击：tt:4 */
  lv_obj_t *o_tt_5 = lv_btn_create(scr); lv_obj_set_size(o_tt_5, 52, 52); lv_obj_set_style_radius(o_tt_5, 26, 0); lv_obj_set_style_bg_color(o_tt_5, lv_color_hex(0x241D17), 0); lv_obj_set_style_shadow_width(o_tt_5, 0, 0); lv_obj_align(o_tt_5, LV_ALIGN_CENTER, 0, 0);
  mk_label(o_tt_5, &badge_f20, lv_color_hex(0xFFF4E0), "5", LV_ALIGN_CENTER, 0, 0); /* 点击：tt:5 */
  lv_obj_t *o_xy = mk_label(scr, &badge_f16, lv_color_hex(0xB9A88F), "{ttXY}", LV_ALIGN_CENTER, 0, -57); /* 动态：{ttXY} */
  lv_obj_t *o_res = mk_label(scr, &badge_f16, lv_color_hex(0xFFF4E0), "{ttText}", LV_ALIGN_CENTER, 0, 59); /* 动态：{ttText} */
  lv_obj_t *o_foot = mk_label(scr, &badge_f16, lv_color_hex(0x6E6253), "右滑返回", LV_ALIGN_CENTER, 0, 177);
  return scr;
}

/* ===== voice：按住说话 / 唤醒后在听 ===== */
/* 按住屏幕任意位置 600 毫秒进入；或说唤醒词「小橘小橘」进入（不用按，8 秒内说完）。松手或静音 1.2 秒结束 → 「想一想…」→ 小猫做动作 + 气泡回应，回到主表盘。 */
/* 进入：主表盘长按；唤醒词；退出：松手 / 静音 1.2 秒 / 8 秒上限 */
lv_obj_t *badge_build_voice(void){
  lv_obj_t *scr = mk_scr();
  badge_cat_layer_create(scr, UI_VOICE_CAT_DIST, UI_VOICE_CAT_OX, UI_VOICE_CAT_OY, UI_VOICE_CAT_DIM_PCT); /* 3D 小猫在最底层 */
  /* wave（wave）：自绘元素，参数见 badge_ui_spec.h 与规范页「当前画面」 */
  lv_obj_t *o_btn_mic = lv_btn_create(scr); lv_obj_set_size(o_btn_mic, 68, 68); lv_obj_set_style_radius(o_btn_mic, LV_RADIUS_CIRCLE, 0); lv_obj_set_style_bg_color(o_btn_mic, lv_color_hex(0xF0A35E), 0); lv_obj_set_style_shadow_width(o_btn_mic, 0, 0); lv_obj_align(o_btn_mic, LV_ALIGN_CENTER, 0, 135);
  mk_icon(o_btn_mic, "mic", 2.5, 0, 0); /* 点击： */
  lv_obj_t *o_state = mk_label(scr, &badge_f20, lv_color_hex(0xFFF4E0), "在听…", LV_ALIGN_CENTER, 0, 189); /* 动态：{voiceState} */
  return scr;
}

/* ===== meet：遇见：附近有小猫 ===== */
/* 两台吧唧 3 米内互相发现。震动 80-80-80 毫秒；对方的小猫出现在屏幕上（用对方的花色和服饰渲染）。 */
/* 进入：BLE 判定遇见（需双方开启可被发现）；退出：打招呼 → 碰一碰确认（没有 NFC 时扫码确认）；忽略 / 30 秒无操作 → 返回 */
lv_obj_t *badge_build_meet(void){
  lv_obj_t *scr = mk_scr();
  badge_cat_layer_create(scr, UI_MEET_CAT_DIST, UI_MEET_CAT_OX, UI_MEET_CAT_OY, UI_MEET_CAT_DIM_PCT); /* 3D 小猫在最底层 */
  lv_obj_t *o_title = mk_label(scr, &badge_f20, lv_color_hex(0xFFF4E0), "附近有一只小猫", LV_ALIGN_CENTER, 0, -163);
  lv_obj_t *o_peer = mk_label(scr, &badge_f24, lv_color_hex(0xFFF4E0), "奶茶", LV_ALIGN_CENTER, 0, 89); /* 动态：{peer} */
  lv_obj_t *o_peer_sub = mk_label(scr, &badge_f16, lv_color_hex(0xB9A88F), "布偶猫 · 3 米内", LV_ALIGN_CENTER, 0, 115); /* 动态：{peerBreed} · 3 米内 */
  lv_obj_t *o_btn_hi = lv_btn_create(scr); lv_obj_set_size(o_btn_hi, 112, 44); lv_obj_set_style_radius(o_btn_hi, 22, 0); lv_obj_set_style_bg_color(o_btn_hi, lv_color_hex(0xF0A35E), 0); lv_obj_set_style_shadow_width(o_btn_hi, 0, 0); lv_obj_align(o_btn_hi, LV_ALIGN_CENTER, -61, 153);
  mk_label(o_btn_hi, &badge_f20, lv_color_hex(0x000000), "打招呼", LV_ALIGN_CENTER, 0, 0); /* 点击：meet_hi */
  lv_obj_t *o_btn_skip = lv_btn_create(scr); lv_obj_set_size(o_btn_skip, 112, 44); lv_obj_set_style_radius(o_btn_skip, 22, 0); lv_obj_set_style_bg_color(o_btn_skip, lv_color_hex(0x241D17), 0); lv_obj_set_style_shadow_width(o_btn_skip, 0, 0); lv_obj_align(o_btn_skip, LV_ALIGN_CENTER, 61, 153);
  mk_label(o_btn_skip, &badge_f20, lv_color_hex(0xFFF4E0), "忽略", LV_ALIGN_CENTER, 0, 0); /* 点击：meet_skip */
  return scr;
}

/* ===== meet_tap：遇见：碰一碰确认 ===== */
/* 扫到 ≠ 遇见。必须碰一碰（NFC）或在 App 扫码，双方确认后才成为朋友。需外接 NFC；M1 板未加装时用「扫码确认」画面代替。 */
/* 进入：遇见画面点「打招呼」（已装 NFC）；退出：确认成功 → 成为朋友；取消 / 20 秒超时 → 返回 */
lv_obj_t *badge_build_meet_tap(void){
  lv_obj_t *scr = mk_scr();
  lv_obj_t *o_title = mk_label(scr, &badge_f24, lv_color_hex(0xFFF4E0), "碰一碰确认", LV_ALIGN_CENTER, 0, -163);
  lv_obj_t *o_ico = mk_icon(scr, "tap", 6, 0, -37);
  lv_obj_t *o_hint = mk_label(scr, &badge_f20, lv_color_hex(0xFFF4E0), "把两个吧唧轻轻碰一下", LV_ALIGN_CENTER, 0, 59);
  lv_obj_t *o_hint2 = mk_label(scr, &badge_f16, lv_color_hex(0xB9A88F), "或在 App 里扫码", LV_ALIGN_CENTER, 0, 89);
  lv_obj_t *o_btn_cancel = lv_btn_create(scr); lv_obj_set_size(o_btn_cancel, 112, 44); lv_obj_set_style_radius(o_btn_cancel, 22, 0); lv_obj_set_style_bg_color(o_btn_cancel, lv_color_hex(0x241D17), 0); lv_obj_set_style_shadow_width(o_btn_cancel, 0, 0); lv_obj_align(o_btn_cancel, LV_ALIGN_CENTER, 0, 151);
  mk_label(o_btn_cancel, &badge_f20, lv_color_hex(0xFFF4E0), "取消", LV_ALIGN_CENTER, 0, 0); /* 点击：meet_cancel */
  return scr;
}

/* ===== meet_scan：遇见：扫码确认（没有 NFC 时） ===== */
/* 初版的遇见确认就用这个画面（M1 板没有 NFC，NFC 不进初版）。吧唧显示自己的二维码（内容：设备短编号 + 一次性口令，20 秒内有效），对方用 App 扫一扫，云端校验后双方吧唧同时进入「成为朋友」。二维码白底黑块，四周留白 6 像素，显示期间亮度临时调到最高方便扫。 */
/* 进入：遇见画面点「打招呼」（没装 NFC）；退出：对方扫码成功 → 成为朋友；取消 / 20 秒超时 → 返回 */
lv_obj_t *badge_build_meet_scan(void){
  lv_obj_t *scr = mk_scr();
  lv_obj_t *o_title = mk_label(scr, &badge_f24, lv_color_hex(0xFFF4E0), "扫码确认", LV_ALIGN_CENTER, 0, -169);
  lv_obj_t *o_qr = lv_qrcode_create(scr, 144, lv_color_hex(0x000000), lv_color_hex(0xFFFFFF));
  lv_obj_set_style_border_color(o_qr, lv_color_hex(0xFFFFFF), 0); lv_obj_set_style_border_width(o_qr, 6, 0); lv_obj_align(o_qr, LV_ALIGN_CENTER, 0, -45); /* 需 LV_USE_QRCODE 1；运行时 lv_qrcode_update(o_qr, data, len)，内容 = 设备短编号 + 一次性口令 */
  lv_obj_t *o_hint = mk_label(scr, &badge_f20, lv_color_hex(0xFFF4E0), "让奶茶的主人用 App 扫一扫", LV_ALIGN_CENTER, 0, 67); /* 动态：让{peer}的主人用 App 扫一扫 */
  lv_obj_t *o_hint2 = mk_label(scr, &badge_f16, lv_color_hex(0xB9A88F), "20 秒内有效", LV_ALIGN_CENTER, 0, 97);
  lv_obj_t *o_btn_cancel = lv_btn_create(scr); lv_obj_set_size(o_btn_cancel, 112, 44); lv_obj_set_style_radius(o_btn_cancel, 22, 0); lv_obj_set_style_bg_color(o_btn_cancel, lv_color_hex(0x241D17), 0); lv_obj_set_style_shadow_width(o_btn_cancel, 0, 0); lv_obj_align(o_btn_cancel, LV_ALIGN_CENTER, 0, 151);
  mk_label(o_btn_cancel, &badge_f20, lv_color_hex(0xFFF4E0), "取消", LV_ALIGN_CENTER, 0, 0); /* 点击：meet_cancel */
  return scr;
}

/* ===== meet_done：遇见：成为朋友 ===== */
/* 确认成功，云端校验后结算礼物（离线时先显示，联网补传）。4 秒后自动返回。 */
/* 进入：碰一碰成功 / 对方扫码成功；退出：4 秒自动返回 / 点任意处 */
lv_obj_t *badge_build_meet_done(void){
  lv_obj_t *scr = mk_scr();
  lv_obj_t *o_ico = mk_icon(scr, "gift", 6, 0, -47);
  lv_obj_t *o_title = mk_label(scr, &badge_f24, lv_color_hex(0xFFF4E0), "成为朋友啦", LV_ALIGN_CENTER, 0, 53);
  lv_obj_t *o_gift = mk_label(scr, &badge_f20, lv_color_hex(0xF0A35E), "奶茶送你：小鱼干 ×1", LV_ALIGN_CENTER, 0, 87); /* 动态：{meetGift} */
  /* hearts（hearts）：自绘元素，参数见 badge_ui_spec.h 与规范页「当前画面」 */
  /* 触摸热区 hit_any：圆心 (233,233) 半径 233 → home（在屏幕的 LV_EVENT_CLICKED 里按坐标判断） */
  return scr;
}

/* ===== away：生活同步：小猫在外面 ===== */
/* 主人在公司 / 常去地点时，小猫也「出门」了：不显示 3D 小猫，显示它在哪、在干什么。可以叫它回家 30 分钟。 */
/* 进入：App 同步主人状态为工作 / 在常去地点（需开启生活同步）；退出：叫它回家；主人到家后自动回来 */
lv_obj_t *badge_build_away(void){
  lv_obj_t *scr = mk_scr();
  lv_obj_t *o_time = mk_label(scr, &badge_f24, lv_color_hex(0xFFF4E0), "09:41", LV_ALIGN_CENTER, 0, -169); /* 动态：{time} */
  lv_obj_t *o_place = mk_icon(scr, "office", 6, 0, -51); /* 动态图标 {placeIcon} */
  lv_obj_t *o_where = mk_label(scr, &badge_f20, lv_color_hex(0xFFF4E0), "小橘在公司楼下花坛", LV_ALIGN_CENTER, 0, 47); /* 动态：{placeText} */
  lv_obj_t *o_doing = mk_label(scr, &badge_f16, lv_color_hex(0xB9A88F), "晒太阳，等你下班", LV_ALIGN_CENTER, 0, 77); /* 动态：{placeSub} */
  lv_obj_t *o_btn_home = lv_btn_create(scr); lv_obj_set_size(o_btn_home, 150, 46); lv_obj_set_style_radius(o_btn_home, 23, 0); lv_obj_set_style_bg_color(o_btn_home, lv_color_hex(0xF0A35E), 0); lv_obj_set_style_shadow_width(o_btn_home, 0, 0); lv_obj_align(o_btn_home, LV_ALIGN_CENTER, 0, 143);
  mk_label(o_btn_home, &badge_f20, lv_color_hex(0x000000), "叫它回家", LV_ALIGN_CENTER, 0, 0); /* 点击：call_home */
  return scr;
}

/* ===== lowbat：电量不足 ===== */
/* 电量低于 5%：停止 3D 和语音，只保留蓝牙；插电后回到桌面充电态。 */
/* 进入：电量 < 5%；退出：插电 */
lv_obj_t *badge_build_lowbat(void){
  lv_obj_t *scr = mk_scr();
  lv_obj_t *o_ico = mk_icon(scr, "bat_low", 5, 0, -37);
  lv_obj_t *o_title = mk_label(scr, &badge_f24, lv_color_hex(0xFF6B6B), "电量不足", LV_ALIGN_CENTER, 0, 53);
  lv_obj_t *o_sub = mk_label(scr, &badge_f16, lv_color_hex(0xB9A88F), "请充电，小橘先睡啦", LV_ALIGN_CENTER, 0, 87); /* 动态：请充电，{name}先睡啦 */
  return scr;
}

/* ===== boot：开机 ===== */
/* 开机 1.5 秒；未配对进入配对，已配对进入主表盘。 */
/* 进入：长按电源键开机；退出：1.5 秒后自动 */
lv_obj_t *badge_build_boot(void){
  lv_obj_t *scr = mk_scr();
  lv_obj_t *o_logo = mk_icon(scr, "paw", 6, 0, -45);
  lv_obj_t *o_title = mk_label(scr, &badge_f24, lv_color_hex(0xFFF4E0), "暖爪小镇", LV_ALIGN_CENTER, 0, 49);
  lv_obj_t *o_sub = mk_label(scr, &badge_f16, lv_color_hex(0xB9A88F), "正在醒来…", LV_ALIGN_CENTER, 0, 81);
  return scr;
}

/* ===== pair：配对 ===== */
/* 首次使用：在 App「我的吧唧 → 添加」输入屏幕上的 6 位码完成配对（BLE 配对 + 一机一密绑定）。 */
/* 进入：未配对开机；退出：App 配对成功 → 引导 */
lv_obj_t *badge_build_pair(void){
  lv_obj_t *scr = mk_scr();
  lv_obj_t *o_title = mk_label(scr, &badge_f24, lv_color_hex(0xFFF4E0), "打开 App 配对", LV_ALIGN_CENTER, 0, -113);
  lv_obj_t *o_code = mk_label(scr, &badge_n40, lv_color_hex(0xF0A35E), "482 913", LV_ALIGN_CENTER, 0, -21); /* 动态：{pairCode} */
  lv_obj_t *o_hint = mk_label(scr, &badge_f16, lv_color_hex(0xB9A88F), "App → 我的吧唧 → 添加", LV_ALIGN_CENTER, 0, 43);
  /* dots（dots）：自绘元素，参数见 badge_ui_spec.h 与规范页「当前画面」 */
  return scr;
}

/* ===== guide：首次引导 ===== */
/* 配对成功后显示 5 页，点一下下一页；以后在 App 里可重看。 */
/* 进入：首次配对成功；退出：最后一页点击 → 主表盘 */
lv_obj_t *badge_build_guide(void){
  lv_obj_t *scr = mk_scr();
  lv_obj_t *o_ico = mk_icon(scr, "office", 6, 0, -49); /* 动态图标 {guideIcon} */
  lv_obj_t *o_title = mk_label(scr, &badge_f24, lv_color_hex(0xFFF4E0), "轻点小猫", LV_ALIGN_CENTER, 0, 47); /* 动态：{guideTitle} */
  lv_obj_t *o_sub = mk_label(scr, &badge_f16, lv_color_hex(0xB9A88F), "摸摸它，心情 +9", LV_ALIGN_CENTER, 0, 79); /* 动态：{guideSub} */
  /* dots（dots）：自绘元素，参数见 badge_ui_spec.h 与规范页「当前画面」 */
  /* 触摸热区 hit_any：圆心 (233,233) 半径 233 → guide_next（在屏幕的 LV_EVENT_CLICKED 里按坐标判断） */
  return scr;
}
