/*
 * SPDX-FileCopyrightText: 2025-2026 Espressif Systems (Shanghai) CO LTD
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*********************
 *      INCLUDES
 *********************/
#include <stdlib.h>
#include <stdbool.h>
#include <stdint.h>
#include <inttypes.h>
#include <string.h>
#include <sys/queue.h>
#include "sdkconfig.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/semphr.h"
#include "soc/soc_caps.h"
#include "esp_log.h"
#include "esp_check.h"
#include "esp_lcd_panel_io.h"
#include "esp_lcd_panel_ops.h"
#include "esp_cache.h"
#include "esp_private/esp_cache_private.h"
#include "esp_heap_caps.h"
#include "display_bridge.h"
#include "display_manager.h"
#include "lvgl_port_ppa.h"
#include "display_te_sync.h"
#include "lvgl_port_alignment.h"
#include "common/display_bridge_common.h"

#include "esp_timer.h"

#if SOC_MIPI_DSI_SUPPORTED
#include "esp_lcd_mipi_dsi.h"
#endif

#if SOC_LCDCAM_RGB_LCD_SUPPORTED
#include "esp_lcd_panel_rgb.h"
#endif

#define ESP_LV_ADAPTER_DUMMY_DRAW_EVT_COLOR_DONE  (1U << 0)
#define ESP_LV_ADAPTER_DUMMY_DRAW_EVT_FRAME_DONE  (1U << 1)

#if CONFIG_SOC_PPA_SUPPORTED
#include "driver/ppa.h"
#endif

#if SOC_DMA2D_SUPPORTED
#ifdef ESP_ASYNC_COLOR_CONVERT_AVAILABLE
#include "esp_async_color_convert.h"
#else
#include "esp_async_fbcpy.h"
#endif
#endif

/*********************
 *      DEFINES
 *********************/
/* Color depth constants */
#define COLOR_DEPTH_RGB565         (16)    /* 16-bit RGB565 color format */
#define COLOR_DEPTH_RGB888         (24)    /* 24-bit RGB888 color format */
#define COLOR_BYTES_RGB565         (2)     /* Bytes per pixel for RGB565 */
#define COLOR_BYTES_RGB888         (3)     /* Bytes per pixel for RGB888 */

#if SOC_DMA2D_SUPPORTED
#ifdef ESP_ASYNC_COLOR_CONVERT_AVAILABLE
#define DMA2D_PIXEL_FORMAT_FIELD(_color_bytes) \
    .src_color_format = ((_color_bytes) == COLOR_BYTES_RGB565 ? ESP_COLOR_FOURCC_RGB16 : ESP_COLOR_FOURCC_RGB24), \
    .dst_color_format = ((_color_bytes) == COLOR_BYTES_RGB565 ? ESP_COLOR_FOURCC_RGB16 : ESP_COLOR_FOURCC_RGB24)
#elif defined(ESP_COLOR_FOURCC_RGB16) && defined(ESP_COLOR_FOURCC_RGB24)
#define DMA2D_PIXEL_FORMAT_FIELD(_color_bytes) \
    .pixel_format_fourcc_id = ((_color_bytes) == COLOR_BYTES_RGB565 ? ESP_COLOR_FOURCC_RGB16 : ESP_COLOR_FOURCC_RGB24)
#else
#define DMA2D_PIXEL_FORMAT_FIELD(_color_bytes) \
    .pixel_format_unique_id = { \
        .color_type_id = ((_color_bytes) == COLOR_BYTES_RGB565) ? \
        COLOR_TYPE_ID(COLOR_SPACE_RGB, COLOR_PIXEL_RGB565) : \
        COLOR_TYPE_ID(COLOR_SPACE_RGB, COLOR_PIXEL_RGB888) \
    }
#endif
#endif

/* PPA transformation constants */
#define PPA_SCALE_FACTOR_NO_SCALE  (1.0f)  /* No scaling (1:1) */
#define PPA_SWAP_DISABLED          (0)     /* RGB/byte swap disabled */

/* Hardware alignment */
#define PPA_DEFAULT_ALIGNMENT      (128)   /* Default PPA alignment in bytes */

#define DISPLAY_BRIDGE_V8_DIFF_BUFFER_COUNT  (3U)
#define DISPLAY_BRIDGE_V8_DIFF_RECT_CAPACITY (LV_INV_BUF_SIZE)
#define DISPLAY_BRIDGE_V8_REPAIR_CAPACITY    (LV_INV_BUF_SIZE * 4U + 4U)

/*********************
 *      TYPEDEFS
 *********************/
#if LVGL_VERSION_MAJOR >= 9

/* Empty implementation for LVGL v9+ */

#else

typedef struct {
    uint32_t revision;
    uint16_t pending_count;
    bool valid;
    /* Regions where this framebuffer is behind the latest submitted frame. */
    lv_area_t pending[DISPLAY_BRIDGE_V8_DIFF_RECT_CAPACITY];
} display_bridge_v8_diff_buffer_t;

typedef struct {
    display_bridge_v8_diff_buffer_t buffers[DISPLAY_BRIDGE_V8_DIFF_BUFFER_COUNT];
    uint32_t revision;
} display_bridge_v8_diff_tracker_t;

typedef struct esp_lv_adapter_display_bridge_v8 {
    esp_lv_adapter_display_bridge_t base;
    esp_lv_adapter_display_runtime_config_t cfg;
    esp_lcd_panel_handle_t panel;
    esp_lcd_panel_io_handle_t panel_io;
    esp_lv_adapter_display_runtime_info_t runtime;
    esp_lv_adapter_display_dirty_region_t dirty;
    portMUX_TYPE double_sync_lock;
    void *disp_fb;
    void *pending_fb;
    void *draw_fb;
    uint32_t switch_seq;
    uint32_t double_wait_switch_seq;
    bool double_wait_active;
    bool frame_buf_submit_pending;
    SemaphoreHandle_t double_wait_sem;
    TaskHandle_t notify_task;
    TaskHandle_t dummy_draw_wait_task;
    uint32_t dummy_draw_wait_mask;
    bool dummy_draw;
    int block_size_small;
    int block_size_large;
    size_t cache_line_size;
    esp_lv_adapter_vsync_timing_t vsync_timing;   /*!< Standardized VSYNC timing context */
    bool idf_callbacks_registered;
    bool idf_callback_registration_enabled;

    /* --- Pipeline buffer management (owned by bridge, inited by display_bridge_pipeline_init_from_cfg) --- */
    esp_lv_adapter_display_pipeline_t pipeline;
    display_bridge_v8_diff_tracker_t diff_tracker;
} esp_lv_adapter_display_bridge_v8_t;

/* display_pipeline_buf is defined in adapter_internal.h */

#if CONFIG_SOC_PPA_SUPPORTED || CONFIG_SOC_DMA2D_SUPPORTED
typedef struct {
    size_t data_cache_line_size;
#if CONFIG_SOC_PPA_SUPPORTED
    ppa_client_handle_t ppa_handle;
#endif
    /* DMA2D resources live in the shared singleton (display_bridge_get_hw_resource) */
} display_bridge_v8_hw_resource_t;
#endif

#endif /* LVGL_VERSION_MAJOR >= 9 */

/**********************
 *  STATIC VARIABLES
 **********************/
static const char *TAG = "esp_lvgl:bridge_v8";

#if LVGL_VERSION_MAJOR < 9
#if CONFIG_SOC_PPA_SUPPORTED || CONFIG_SOC_DMA2D_SUPPORTED
static display_bridge_v8_hw_resource_t hw_resource = {0};
#endif
#endif

/**********************
 *  INLINE FUNCTIONS
 **********************/
#if LVGL_VERSION_MAJOR < 9

static inline uint16_t bridge_h_res(const esp_lv_adapter_display_bridge_v8_t *impl)
{
    return impl->runtime.hor_res;
}

static inline uint16_t bridge_v_res(const esp_lv_adapter_display_bridge_v8_t *impl)
{
    return impl->runtime.ver_res;
}

static inline esp_lv_adapter_rotation_t bridge_rotation(const esp_lv_adapter_display_bridge_v8_t *impl)
{
    return impl->runtime.rotation;
}

static inline uint8_t bridge_color_bytes(const esp_lv_adapter_display_bridge_v8_t *impl)
{
    return impl->runtime.color_bytes;
}

static uint8_t display_bridge_v8_diff_buffer_index(const esp_lv_adapter_display_bridge_v8_t *impl,
                                                   const void *buffer)
{
    uint8_t count = LV_MIN(impl->runtime.frame_buffer_count,
                           (uint8_t)DISPLAY_BRIDGE_V8_DIFF_BUFFER_COUNT);
    for (uint8_t index = 0; index < count; ++index) {
        if (impl->runtime.frame_buffers[index] == buffer) {
            return index;
        }
    }
    return UINT8_MAX;
}

static void display_bridge_v8_diff_reset_to(esp_lv_adapter_display_bridge_v8_t *impl,
                                            uint8_t current_index)
{
    memset(&impl->diff_tracker, 0, sizeof(impl->diff_tracker));
    if (current_index < DISPLAY_BRIDGE_V8_DIFF_BUFFER_COUNT) {
        impl->diff_tracker.buffers[current_index].valid = true;
    }
}

static void display_bridge_v8_diff_reset(esp_lv_adapter_display_bridge_v8_t *impl)
{
    display_bridge_v8_diff_reset_to(
        impl, display_bridge_v8_diff_buffer_index(impl, impl->disp_fb));
}

static bool display_bridge_v8_diff_rect_valid(const lv_area_t *rect)
{
    return rect->x2 >= rect->x1 && rect->y2 >= rect->y1;
}

static bool display_bridge_v8_diff_rects_touch_or_overlap(const lv_area_t *a,
                                                          const lv_area_t *b)
{
    bool x_overlap = a->x1 <= b->x2 && a->x2 >= b->x1;
    bool y_overlap = a->y1 <= b->y2 && a->y2 >= b->y1;
    bool x_adjacent = a->x2 + 1 == b->x1 || b->x2 + 1 == a->x1;
    bool y_adjacent = a->y2 + 1 == b->y1 || b->y2 + 1 == a->y1;
    return (x_overlap && y_overlap) || (x_adjacent && y_overlap) ||
           (y_adjacent && x_overlap);
}

static bool display_bridge_v8_diff_merge_one(lv_area_t *rects,
                                             uint16_t *count,
                                             uint16_t capacity,
                                             lv_area_t rect)
{
    uint16_t index = 0;
    while (index < *count) {
        if (!display_bridge_v8_diff_rects_touch_or_overlap(&rects[index], &rect)) {
            ++index;
            continue;
        }
        rect.x1 = LV_MIN(rect.x1, rects[index].x1);
        rect.y1 = LV_MIN(rect.y1, rects[index].y1);
        rect.x2 = LV_MAX(rect.x2, rects[index].x2);
        rect.y2 = LV_MAX(rect.y2, rects[index].y2);
        rects[index] = rects[--(*count)];
        index = 0;
    }
    if (*count >= capacity) {
        return false;
    }
    rects[(*count)++] = rect;
    return true;
}

static void display_bridge_v8_diff_area_to_physical(
    const esp_lv_adapter_display_bridge_v8_t *impl,
    const lv_area_t *logical,
    lv_area_t *physical)
{
    const esp_lv_adapter_rotation_t rotation = bridge_rotation(impl);
    if (rotation == ESP_LV_ADAPTER_ROTATE_0) {
        *physical = *logical;
        return;
    }

    int x1 = 0;
    int y1 = 0;
    int x2 = 0;
    int y2 = 0;
    display_coord_to_phy(logical->x1, logical->y1, &x1, &y1,
                         rotation, bridge_h_res(impl), bridge_v_res(impl));
    display_coord_to_phy(logical->x2, logical->y2, &x2, &y2,
                         rotation, bridge_h_res(impl), bridge_v_res(impl));

    physical->x1 = LV_MIN(x1, x2);
    physical->y1 = LV_MIN(y1, y2);
    physical->x2 = LV_MAX(x1, x2);
    physical->y2 = LV_MAX(y1, y2);
}

static bool display_bridge_v8_diff_capture_current(
    const esp_lv_adapter_display_bridge_v8_t *impl,
    const lv_disp_t *disp,
    lv_area_t *current,
    uint16_t *current_count,
    bool to_physical)
{
    *current_count = 0;
    const esp_lv_adapter_rotation_t rotation = bridge_rotation(impl);
    const bool rotated = to_physical && rotation != ESP_LV_ADAPTER_ROTATE_0;
    const bool swapped = rotation == ESP_LV_ADAPTER_ROTATE_90 ||
                         rotation == ESP_LV_ADAPTER_ROTATE_270;
    const int32_t logical_w = rotated && swapped ?
                              bridge_v_res(impl) : bridge_h_res(impl);
    const int32_t logical_h = rotated && swapped ?
                              bridge_h_res(impl) : bridge_v_res(impl);
    uint16_t count = LV_MIN(disp->inv_p, (uint16_t)LV_INV_BUF_SIZE);
    for (uint16_t index = 0; index < count; ++index) {
        if (disp->inv_area_joined[index]) {
            continue;
        }
        lv_area_t rect = disp->inv_areas[index];
        rect.x1 = LV_MAX(rect.x1, 0);
        rect.y1 = LV_MAX(rect.y1, 0);
        rect.x2 = LV_MIN(rect.x2, logical_w - 1);
        rect.y2 = LV_MIN(rect.y2, logical_h - 1);
        if (rotated) {
            display_bridge_v8_diff_area_to_physical(impl, &rect, &rect);
            rect.x1 = LV_MAX(rect.x1, 0);
            rect.y1 = LV_MAX(rect.y1, 0);
            rect.x2 = LV_MIN(rect.x2, (int32_t)bridge_h_res(impl) - 1);
            rect.y2 = LV_MIN(rect.y2, (int32_t)bridge_v_res(impl) - 1);
        }
        if (!display_bridge_v8_diff_rect_valid(&rect)) {
            continue;
        }
        if (*current_count >= DISPLAY_BRIDGE_V8_DIFF_RECT_CAPACITY) {
            *current_count = 0;
            return false;
        }
        current[(*current_count)++] = rect;
    }
    return *current_count != 0;
}

static bool display_bridge_v8_diff_append(lv_area_t *rects,
                                          uint16_t *count,
                                          uint16_t capacity,
                                          lv_area_t rect)
{
    if (!display_bridge_v8_diff_rect_valid(&rect)) {
        return true;
    }
    if (*count >= capacity) {
        return false;
    }
    rects[(*count)++] = rect;
    return true;
}

static bool display_bridge_v8_diff_subtract_one(lv_area_t source,
                                                lv_area_t cut,
                                                lv_area_t *out,
                                                uint16_t *out_count,
                                                uint16_t capacity)
{
    lv_area_t overlap = {
        .x1 = LV_MAX(source.x1, cut.x1),
        .y1 = LV_MAX(source.y1, cut.y1),
        .x2 = LV_MIN(source.x2, cut.x2),
        .y2 = LV_MIN(source.y2, cut.y2),
    };
    if (!display_bridge_v8_diff_rect_valid(&overlap)) {
        return display_bridge_v8_diff_append(out, out_count, capacity, source);
    }

    return display_bridge_v8_diff_append(out, out_count, capacity, (lv_area_t) {
        source.x1, source.y1, source.x2, overlap.y1 - 1
    }) &&
    display_bridge_v8_diff_append(out, out_count, capacity, (lv_area_t) {
        source.x1, overlap.y2 + 1, source.x2, source.y2
    }) &&
    display_bridge_v8_diff_append(out, out_count, capacity, (lv_area_t) {
        source.x1, overlap.y1, overlap.x1 - 1, overlap.y2
    }) &&
    display_bridge_v8_diff_append(out, out_count, capacity, (lv_area_t) {
        overlap.x2 + 1, overlap.y1, source.x2, overlap.y2
    });
}

static void display_bridge_v8_diff_coalesce_exact(lv_area_t *rects,
                                                  uint16_t *count)
{
    bool merged;
    do {
        merged = false;
        for (uint16_t first = 0; first < *count && !merged; ++first) {
            for (uint16_t second = first + 1; second < *count; ++second) {
                lv_area_t *a = &rects[first];
                const lv_area_t *b = &rects[second];
                bool same_x_span = a->x1 == b->x1 && a->x2 == b->x2;
                bool same_y_span = a->y1 == b->y1 && a->y2 == b->y2;
                bool y_connected = a->y1 <= b->y2 + 1 && b->y1 <= a->y2 + 1;
                bool x_connected = a->x1 <= b->x2 + 1 && b->x1 <= a->x2 + 1;
                bool a_contains_b = a->x1 <= b->x1 && a->y1 <= b->y1 &&
                                    a->x2 >= b->x2 && a->y2 >= b->y2;
                bool b_contains_a = b->x1 <= a->x1 && b->y1 <= a->y1 &&
                                    b->x2 >= a->x2 && b->y2 >= a->y2;

                if ((!same_x_span || !y_connected) &&
                        (!same_y_span || !x_connected) &&
                        !a_contains_b && !b_contains_a) {
                    continue;
                }
                a->x1 = LV_MIN(a->x1, b->x1);
                a->y1 = LV_MIN(a->y1, b->y1);
                a->x2 = LV_MAX(a->x2, b->x2);
                a->y2 = LV_MAX(a->y2, b->y2);
                rects[second] = rects[--(*count)];
                merged = true;
                break;
            }
        }
    } while (merged);
}

static bool display_bridge_v8_diff_subtract(
    const lv_area_t *pending,
    uint16_t pending_count,
    const lv_area_t *current,
    uint16_t current_count,
    lv_area_t *repair,
    uint16_t *repair_count)
{
    if (pending_count > DISPLAY_BRIDGE_V8_REPAIR_CAPACITY) {
        return false;
    }
    if (pending_count != 0) {
        memcpy(repair, pending, pending_count * sizeof(*repair));
    }
    *repair_count = pending_count;
    for (uint16_t cut = 0; cut < current_count; ++cut) {
        uint16_t index = 0;
        while (index < *repair_count) {
            lv_area_t source = repair[index];
            lv_area_t overlap = {
                .x1 = LV_MAX(source.x1, current[cut].x1),
                .y1 = LV_MAX(source.y1, current[cut].y1),
                .x2 = LV_MIN(source.x2, current[cut].x2),
                .y2 = LV_MIN(source.y2, current[cut].y2),
            };
            if (!display_bridge_v8_diff_rect_valid(&overlap)) {
                ++index;
                continue;
            }

            repair[index] = repair[--(*repair_count)];
            if (!display_bridge_v8_diff_subtract_one(
                        source, current[cut], repair, repair_count,
                        DISPLAY_BRIDGE_V8_REPAIR_CAPACITY)) {
                *repair_count = 0;
                return false;
            }
        }
    }
    display_bridge_v8_diff_coalesce_exact(repair, repair_count);
    return true;
}

static void display_bridge_v8_diff_commit(
    esp_lv_adapter_display_bridge_v8_t *impl,
    uint8_t target_index,
    const lv_area_t *current,
    uint16_t current_count)
{
    if (impl->diff_tracker.revision == UINT32_MAX) {
        memset(&impl->diff_tracker, 0, sizeof(impl->diff_tracker));
    }
    uint32_t revision = ++impl->diff_tracker.revision;
    uint8_t count = LV_MIN(impl->runtime.frame_buffer_count,
                           (uint8_t)DISPLAY_BRIDGE_V8_DIFF_BUFFER_COUNT);
    for (uint8_t index = 0; index < count; ++index) {
        display_bridge_v8_diff_buffer_t *state =
            &impl->diff_tracker.buffers[index];
        if (index == target_index || !state->valid) {
            continue;
        }
        uint16_t pending_count = state->pending_count;
        for (uint16_t rect = 0; rect < current_count; ++rect) {
            if (!display_bridge_v8_diff_merge_one(
                        state->pending, &pending_count,
                        DISPLAY_BRIDGE_V8_DIFF_RECT_CAPACITY, current[rect])) {
                state->valid = false;
                state->pending_count = 0;
                break;
            }
        }
        if (state->valid) {
            state->pending_count = pending_count;
        }
    }
    impl->diff_tracker.buffers[target_index] =
    (display_bridge_v8_diff_buffer_t) {
        .revision = revision,
        .valid = true,
    };
}

#if CONFIG_SOC_PPA_SUPPORTED
static inline ppa_srm_color_mode_t display_bridge_v8_ppa_color_mode(uint8_t color_bytes)
{
    return (color_bytes == COLOR_BYTES_RGB888) ? PPA_SRM_COLOR_MODE_RGB888 : PPA_SRM_COLOR_MODE_RGB565;
}
#endif

static inline void display_bridge_v8_get_rotation_geometry(const esp_lv_adapter_display_bridge_v8_t *impl,
                                                           uint16_t *src_logical_w,
                                                           uint16_t *src_logical_h,
                                                           uint16_t *dst_physical_w,
                                                           uint16_t *dst_physical_h)
{
    const uint16_t phys_w = bridge_h_res(impl);
    const uint16_t phys_h = bridge_v_res(impl);
    const bool swapped = (bridge_rotation(impl) == ESP_LV_ADAPTER_ROTATE_90 ||
                          bridge_rotation(impl) == ESP_LV_ADAPTER_ROTATE_270);

    if (src_logical_w) {
        *src_logical_w = swapped ? phys_h : phys_w;
    }
    if (src_logical_h) {
        *src_logical_h = swapped ? phys_w : phys_h;
    }
    if (dst_physical_w) {
        *dst_physical_w = phys_w;
    }
    if (dst_physical_h) {
        *dst_physical_h = phys_h;
    }
}

static inline bool bridge_mode_uses_double_switch_wait(esp_lv_adapter_tear_avoid_mode_t mode)
{
    return mode == ESP_LV_ADAPTER_TEAR_AVOID_MODE_DOUBLE_DIRECT ||
           mode == ESP_LV_ADAPTER_TEAR_AVOID_MODE_DOUBLE_FULL;
}

static inline bool bridge_mode_uses_rotated_nonpartial_pipeline_release(const esp_lv_adapter_display_bridge_v8_t *impl)
{
    if (!impl) {
        return false;
    }

    if (bridge_rotation(impl) == ESP_LV_ADAPTER_ROTATE_0) {
        return false;
    }

    switch (impl->cfg.base.tear_avoid_mode) {
    case ESP_LV_ADAPTER_TEAR_AVOID_MODE_DOUBLE_DIRECT:
    case ESP_LV_ADAPTER_TEAR_AVOID_MODE_DOUBLE_FULL:
    case ESP_LV_ADAPTER_TEAR_AVOID_MODE_TRIPLE_FULL:
        return true;
    default:
        return false;
    }
}

static inline bool bridge_mode_needs_double_prime(esp_lv_adapter_tear_avoid_mode_t mode)
{
    return mode == ESP_LV_ADAPTER_TEAR_AVOID_MODE_DOUBLE_DIRECT;
}

static inline bool bridge_mode_uses_buf_switch_release(esp_lv_adapter_tear_avoid_mode_t mode)
{
    return bridge_mode_uses_double_switch_wait(mode) ||
           mode == ESP_LV_ADAPTER_TEAR_AVOID_MODE_TRIPLE_FULL ||
           mode == ESP_LV_ADAPTER_TEAR_AVOID_MODE_TRIPLE_PARTIAL ||
           mode == ESP_LV_ADAPTER_TEAR_AVOID_MODE_DOUBLE_PARTIAL;
}

static inline bool bridge_mode_needs_submit_gated_frame_complete(const esp_lv_adapter_display_bridge_v8_t *impl)
{
    if (!impl) {
        return false;
    }

    const esp_lv_adapter_tear_avoid_mode_t mode = impl->cfg.base.tear_avoid_mode;

    if (mode == ESP_LV_ADAPTER_TEAR_AVOID_MODE_TRIPLE_PARTIAL ||
            mode == ESP_LV_ADAPTER_TEAR_AVOID_MODE_DOUBLE_PARTIAL) {
        return false;
    }

    return impl->cfg.base.profile.interface == ESP_LV_ADAPTER_PANEL_IF_MIPI_DSI &&
           bridge_mode_uses_buf_switch_release(mode);
}

static inline void display_bridge_v8_mark_frame_buf_submit(esp_lv_adapter_display_bridge_v8_t *impl)
{
    if (!bridge_mode_needs_submit_gated_frame_complete(impl)) {
        return;
    }

    portENTER_CRITICAL(&impl->double_sync_lock);
    impl->frame_buf_submit_pending = true;
    portEXIT_CRITICAL(&impl->double_sync_lock);
}

static bool IRAM_ATTR display_bridge_v8_consume_frame_buf_submit_isr(esp_lv_adapter_display_bridge_v8_t *impl)
{
    if (!bridge_mode_needs_submit_gated_frame_complete(impl)) {
        return true;
    }

    bool submit_pending = false;
    portENTER_CRITICAL_ISR(&impl->double_sync_lock);
    submit_pending = impl->frame_buf_submit_pending;
    if (submit_pending) {
        impl->frame_buf_submit_pending = false;
    }
    portEXIT_CRITICAL_ISR(&impl->double_sync_lock);

    return submit_pending;
}

static esp_err_t display_bridge_v8_blit_full_frame(esp_lv_adapter_display_bridge_v8_t *impl,
                                                   void *frame_buffer,
                                                   bool record_flush_post)
{
    if (!impl || !impl->panel || !frame_buffer) {
        return ESP_ERR_INVALID_ARG;
    }

    if (record_flush_post) {
        display_bridge_vsync_record_flush_post(&impl->vsync_timing);
    }

    esp_err_t ret = display_lcd_blit_full(impl->panel, &impl->runtime, frame_buffer);
    if (ret == ESP_OK) {
        display_bridge_v8_mark_frame_buf_submit(impl);
    }

    return ret;
}

static TaskHandle_t display_bridge_v8_get_notify_task(esp_lv_adapter_display_bridge_v8_t *impl)
{
    if (!impl) {
        return NULL;
    }

    if (impl->notify_task) {
        return impl->notify_task;
    }

    esp_lv_adapter_context_t *ctx = esp_lv_adapter_get_context();
    return ctx ? ctx->task : NULL;
}

static esp_err_t display_bridge_v8_configure_double_wait_resource(esp_lv_adapter_display_bridge_v8_t *impl)
{
    if (!impl) {
        return ESP_ERR_INVALID_ARG;
    }

    const bool need_double_wait = bridge_mode_uses_double_switch_wait(impl->cfg.base.tear_avoid_mode);
    if (!need_double_wait) {
        if (impl->double_wait_sem) {
            vSemaphoreDeleteWithCaps(impl->double_wait_sem);
            impl->double_wait_sem = NULL;
        }
        return ESP_OK;
    }

    if (!impl->double_wait_sem) {
        impl->double_wait_sem = xSemaphoreCreateBinaryWithCaps(MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT);
        if (!impl->double_wait_sem) {
            return ESP_ERR_NO_MEM;
        }
    } else {
        (void)xSemaphoreTake(impl->double_wait_sem, 0);
    }

    return ESP_OK;
}

static void display_bridge_v8_prime_double_buffers(esp_lv_adapter_display_bridge_v8_t *impl)
{
    if (!impl) {
        return;
    }

    const esp_lv_adapter_tear_avoid_mode_t mode = impl->cfg.base.tear_avoid_mode;
    if (!bridge_mode_needs_double_prime(mode)) {
        return;
    }

    if (impl->runtime.rotation != ESP_LV_ADAPTER_ROTATE_0 ||
            impl->runtime.frame_buffer_count < 2 ||
            !impl->runtime.frame_buffers[0] ||
            !impl->runtime.frame_buffers[1] ||
            impl->runtime.frame_buffer_size == 0) {
        return;
    }

    memcpy(impl->runtime.frame_buffers[1], impl->runtime.frame_buffers[0], impl->runtime.frame_buffer_size);
    display_cache_msync_framebuffer(impl->runtime.frame_buffers[1], impl->runtime.frame_buffer_size);
}

static uint32_t display_bridge_v8_prepare_double_wait(esp_lv_adapter_display_bridge_v8_t *impl)
{
    if (!impl) {
        return 0;
    }

    if (impl->double_wait_sem) {
        (void)xSemaphoreTake(impl->double_wait_sem, 0);
    }

    uint32_t switch_seq = 0;
    portENTER_CRITICAL(&impl->double_sync_lock);
    impl->double_wait_active = false;
    switch_seq = impl->switch_seq;
    portEXIT_CRITICAL(&impl->double_sync_lock);

    return switch_seq;
}

static bool display_bridge_v8_arm_double_wait_after_submit(esp_lv_adapter_display_bridge_v8_t *impl,
                                                           uint32_t submitted_switch_seq)
{
    if (!impl) {
        return false;
    }

    bool need_wait = false;

    portENTER_CRITICAL(&impl->double_sync_lock);
    if (impl->switch_seq == submitted_switch_seq) {
        impl->double_wait_switch_seq = submitted_switch_seq;
        impl->double_wait_active = true;
        need_wait = true;
    } else {
        impl->double_wait_active = false;
    }
    portEXIT_CRITICAL(&impl->double_sync_lock);

    return need_wait;
}

static void display_bridge_v8_wait_double_ready(esp_lv_adapter_display_bridge_v8_t *impl)
{
    if (!impl || !impl->double_wait_sem) {
        return;
    }

    while (true) {
        bool done = false;

        portENTER_CRITICAL(&impl->double_sync_lock);
        done = !impl->double_wait_active;
        portEXIT_CRITICAL(&impl->double_sync_lock);

        if (done) {
            return;
        }

        (void)xSemaphoreTake(impl->double_wait_sem, portMAX_DELAY);
    }
}

static bool IRAM_ATTR display_bridge_v8_complete_double_wait_isr(esp_lv_adapter_display_bridge_v8_t *impl)
{
    if (!impl) {
        return false;
    }

    bool notify = false;

    portENTER_CRITICAL_ISR(&impl->double_sync_lock);
    if (impl->double_wait_active && impl->switch_seq > impl->double_wait_switch_seq) {
        impl->double_wait_active = false;
        notify = true;
    }
    portEXIT_CRITICAL_ISR(&impl->double_sync_lock);

    return notify;
}

static esp_err_t display_bridge_v8_submit_double_buffer(esp_lv_adapter_display_bridge_v8_t *impl,
                                                        void *frame_buffer)
{
    if (!impl || !impl->panel || !frame_buffer) {
        return ESP_ERR_INVALID_ARG;
    }

    uint32_t submitted_switch_seq = display_bridge_v8_prepare_double_wait(impl);
    esp_err_t ret = display_bridge_v8_blit_full_frame(impl, frame_buffer, true);
    if (ret != ESP_OK) {
        return ret;
    }

    /* If the switch already happened before we armed the wait, skip blocking. */
    if (display_bridge_v8_arm_double_wait_after_submit(impl, submitted_switch_seq)) {
        display_bridge_v8_wait_double_ready(impl);
    }
    return ESP_OK;
}

static size_t display_bridge_v8_i1_stride_bytes(uint16_t hor_res)
{
    uint16_t aligned = (hor_res + 7U) & ~7U;
    return (size_t)aligned / 8U;
}

static bool display_bridge_v8_prepare_mono(esp_lv_adapter_display_bridge_v8_t *impl,
                                           lv_disp_drv_t *drv,
                                           const lv_area_t *area,
                                           uint8_t **color_map)
{
    if (!impl || !drv || !area || !color_map || !*color_map) {
        return false;
    }

    if (impl->cfg.base.profile.mono_layout == ESP_LV_ADAPTER_MONO_LAYOUT_NONE) {
        return true;
    }

    if (LV_COLOR_DEPTH != 1) {
        ESP_LOGE(TAG, "Monochrome requires LV_COLOR_DEPTH=1");
        return false;
    }

    const esp_lv_adapter_rotation_t rotation = impl->cfg.base.profile.rotation;
    uint16_t phy_w = impl->cfg.base.profile.hor_res;
    uint16_t phy_h = impl->cfg.base.profile.ver_res;
    uint16_t log_w = (rotation == ESP_LV_ADAPTER_ROTATE_90 || rotation == ESP_LV_ADAPTER_ROTATE_270) ? phy_h : phy_w;
    size_t dst_stride = display_bridge_v8_i1_stride_bytes(phy_w);

    if (impl->cfg.base.profile.mono_layout == ESP_LV_ADAPTER_MONO_LAYOUT_HTILED) {
        if ((area->x1 % 8) != 0 || ((area->x2 + 1) % 8) != 0) {
            ESP_LOGW(TAG, "I1 htiled area not byte-aligned (x1=%d x2=%d)", area->x1, area->x2);
        }
        if (impl->cfg.base.profile.rotation == ESP_LV_ADAPTER_ROTATE_0) {
            *color_map += 8;
            return true;
        }
        if (!impl->cfg.mono_buf) {
            ESP_LOGE(TAG, "Monochrome HTILED buffer missing");
            return false;
        }
    } else {
        if (!impl->cfg.mono_buf) {
            ESP_LOGE(TAG, "Monochrome VTILED buffer missing");
            return false;
        }
    }

    size_t buf_size = (size_t)phy_w * phy_h / 8;
    memset(impl->cfg.mono_buf, 0x00, buf_size);

    /* V8 uses 1 byte per pixel (different from V9's packed I1 format) */
    uint8_t *src = *color_map;
    size_t src_stride_px = log_w;

    for (int y = area->y1; y <= area->y2; y++) {
        for (int x = area->x1; x <= area->x2; x++) {
            bool pixel = src[y * src_stride_px + x] != 0;
            int px, py;
            display_coord_to_phy(x, y, &px, &py, rotation, phy_w, phy_h);

            size_t offset;
            if (impl->cfg.base.profile.mono_layout == ESP_LV_ADAPTER_MONO_LAYOUT_HTILED) {
                offset = dst_stride * (size_t)py + (size_t)(px >> 3);
                if (offset < buf_size) {
                    uint8_t mask = (uint8_t)(1U << (7 - (px & 7)));
                    if (pixel) {
                        impl->cfg.mono_buf[offset] |= mask;
                    } else {
                        impl->cfg.mono_buf[offset] &= ~mask;
                    }
                }
            } else {
                offset = (size_t)phy_w * (size_t)(py >> 3) + (size_t)px;
                if (offset < buf_size) {
                    uint8_t mask = (uint8_t)(1U << (py & 7));
                    if (pixel) {
                        impl->cfg.mono_buf[offset] &= ~mask;
                    } else {
                        impl->cfg.mono_buf[offset] |= mask;
                    }
                }
            }
        }
    }
    *color_map = impl->cfg.mono_buf;
    return true;
}

#endif /* LVGL_VERSION_MAJOR < 9 */

/**********************
 *  FORWARD DECLARATIONS
 **********************/
#if LVGL_VERSION_MAJOR < 9

/* Lifecycle management */
static void display_bridge_v8_destroy(esp_lv_adapter_display_bridge_t *bridge);
static esp_err_t display_bridge_v8_update_panel(esp_lv_adapter_display_bridge_t *bridge,
                                                const esp_lv_adapter_display_runtime_config_t *cfg);

static void display_bridge_v8_set_area_rounder(esp_lv_adapter_display_bridge_t *bridge,
                                               void (*rounder_cb)(lv_area_t *, void *),
                                               void *user_data);
static void display_bridge_v8_set_draw_bitmap_callbacks(esp_lv_adapter_display_bridge_t *bridge,
                                                        const esp_lv_adapter_draw_bitmap_callbacks_t *cbs,
                                                        void *user_ctx);

/* Core callbacks */
static void display_bridge_v8_flush_entry(esp_lv_adapter_display_bridge_t *bridge,
                                          void *disp_ref,
                                          const lv_area_t *area,
                                          uint8_t *color_map);
static void display_bridge_v8_set_dummy_draw(esp_lv_adapter_display_bridge_t *bridge, bool enable);
static void display_bridge_v8_set_dummy_draw_callbacks(esp_lv_adapter_display_bridge_t *bridge,
                                                       const esp_lv_adapter_dummy_draw_callbacks_t *cbs,
                                                       void *user_ctx);
static esp_err_t display_bridge_v8_dummy_draw_blit(esp_lv_adapter_display_bridge_t *bridge,
                                                   int x_start,
                                                   int y_start,
                                                   int x_end,
                                                   int y_end,
                                                   const void *frame_buffer,
                                                   bool wait);
static void *display_bridge_v8_dummy_draw_get_free_buf(esp_lv_adapter_display_bridge_t *bridge);
static esp_err_t display_bridge_v8_dummy_draw_flush_buf(esp_lv_adapter_display_bridge_t *bridge,
                                                        void *frame_buffer);

/* VSync handling */
static bool display_bridge_v8_handle_vsync(esp_lv_adapter_display_bridge_v8_t *impl);
static bool display_bridge_v8_handle_frame_buf_complete(esp_lv_adapter_display_bridge_v8_t *impl);
static void display_bridge_v8_register_vsync(esp_lv_adapter_display_bridge_v8_t *impl);
static void display_bridge_v8_unregister_vsync(esp_lv_adapter_display_bridge_v8_t *impl);
static void display_bridge_v8_wait_for_buf_switch(esp_lv_adapter_display_bridge_v8_t *impl);
static bool display_bridge_v8_has_pending_submit(esp_lv_adapter_display_bridge_v8_t *impl);
static inline void display_bridge_v8_signal_dummy_draw_event(esp_lv_adapter_display_bridge_v8_t *impl,
                                                             uint32_t event_bit,
                                                             BaseType_t *need_yield);

#if CONFIG_SOC_MIPI_DSI_SUPPORTED
static bool display_bridge_v8_on_mipi_color_trans_done(esp_lcd_panel_handle_t panel,
                                                       esp_lcd_dpi_panel_event_data_t *event_data,
                                                       void *user_ctx);
static bool display_bridge_v8_on_mipi_frame_buf_complete(esp_lcd_panel_handle_t panel,
                                                         esp_lcd_dpi_panel_event_data_t *event_data,
                                                         void *user_ctx);
#endif

#if CONFIG_SOC_LCD_RGB_SUPPORTED
static bool display_bridge_v8_on_rgb_color_trans_done(esp_lcd_panel_handle_t panel,
                                                      const esp_lcd_rgb_panel_event_data_t *event_data,
                                                      void *user_ctx);
static bool display_bridge_v8_on_rgb_frame_complete(esp_lcd_panel_handle_t panel,
                                                    const esp_lcd_rgb_panel_event_data_t *event_data,
                                                    void *user_ctx);
#endif

static bool display_bridge_v8_on_io_color_trans_done(esp_lcd_panel_io_handle_t panel_io,
                                                     esp_lcd_panel_io_event_data_t *edata,
                                                     void *user_ctx);

/* Flush implementations */
static void display_bridge_v8_flush_default(esp_lv_adapter_display_bridge_v8_t *impl,
                                            lv_disp_drv_t *drv,
                                            const lv_area_t *area,
                                            uint8_t *color_map);
static void display_bridge_v8_flush_gpio_te(esp_lv_adapter_display_bridge_v8_t *impl,
                                            lv_disp_drv_t *drv,
                                            const lv_area_t *area,
                                            uint8_t *color_map);

static void display_bridge_v8_flush_double_full(esp_lv_adapter_display_bridge_v8_t *impl,
                                                lv_disp_drv_t *drv,
                                                const lv_area_t *area,
                                                uint8_t *color_map);

static void display_bridge_v8_flush_triple_full(esp_lv_adapter_display_bridge_v8_t *impl,
                                                lv_disp_drv_t *drv,
                                                const lv_area_t *area,
                                                uint8_t *color_map);

static void display_bridge_v8_flush_double_direct(esp_lv_adapter_display_bridge_v8_t *impl,
                                                  lv_disp_drv_t *drv,
                                                  const lv_area_t *area,
                                                  uint8_t *color_map);

static void display_bridge_v8_flush_triple_diff(esp_lv_adapter_display_bridge_v8_t *impl,
                                                lv_disp_drv_t *drv,
                                                const lv_area_t *area,
                                                uint8_t *color_map);

static void display_bridge_v8_flush_direct_rotate(esp_lv_adapter_display_bridge_v8_t *impl,
                                                  lv_disp_drv_t *drv,
                                                  const lv_area_t *area,
                                                  uint8_t *color_map);

static void display_bridge_v8_flush_full_rotate(esp_lv_adapter_display_bridge_v8_t *impl,
                                                lv_disp_drv_t *drv,
                                                const lv_area_t *area,
                                                uint8_t *color_map);

static void display_bridge_v8_flush_partial_rotate(esp_lv_adapter_display_bridge_v8_t *impl,
                                                   lv_disp_drv_t *drv,
                                                   const lv_area_t *area,
                                                   uint8_t *color_map);

static void rotate_copy_strided_region(const void *src,
                                       void *dst_fb,
                                       uint16_t lv_x_start,
                                       uint16_t lv_y_start,
                                       uint16_t lv_x_end,
                                       uint16_t lv_y_end,
                                       uint16_t src_stride_px,
                                       esp_lv_adapter_display_bridge_v8_t *impl);

static void rotate_copy_region(esp_lv_adapter_display_bridge_v8_t *impl,
                               const void *from,
                               void *to,
                               uint16_t x_start,
                               uint16_t y_start,
                               uint16_t x_end,
                               uint16_t y_end,
                               uint16_t src_logical_w,
                               uint16_t src_logical_h,
                               uint16_t dst_physical_w,
                               uint16_t dst_physical_h,
                               esp_lv_adapter_rotation_t rotation,
                               uint8_t color_bytes);

/* Helper functions */
static void copy_unrendered_area_from_front_to_back(lv_disp_t *disp_refr,
                                                    esp_lv_adapter_display_bridge_v8_t *impl);

static void copy_diff_repair_from_front_to_back(
    esp_lv_adapter_display_bridge_v8_t *impl,
    const lv_area_t *repair,
    uint16_t repair_count);

static bool display_bridge_v8_prepare_partial_back_buffer(
    esp_lv_adapter_display_bridge_v8_t *impl,
    lv_disp_t *disp_refr,
    bool dirty_to_physical,
    lv_area_t *current,
    uint16_t *current_count,
    uint8_t *target_index,
    bool *reset_tracker);

static void flush_dirty_save(esp_lv_adapter_display_dirty_region_t *dirty_area);

static void flush_dirty_copy(esp_lv_adapter_display_bridge_v8_t *impl,
                             void *dst,
                             void *src,
                             esp_lv_adapter_display_dirty_region_t *dirty_area);

#endif /* LVGL_VERSION_MAJOR < 9 */

/**********************
 *   PUBLIC API
 **********************/

/**
 * @brief Create LVGL v8 display bridge
 */
esp_lv_adapter_display_bridge_t *esp_lv_adapter_display_bridge_v8_create(const esp_lv_adapter_display_runtime_config_t *cfg)
{
#if LVGL_VERSION_MAJOR >= 9
    ESP_LOGE(TAG, "LVGL v8 bridge requires LVGL_VERSION_MAJOR < 9");
    (void)cfg;
    return NULL;
#else
    esp_lv_adapter_display_bridge_v8_t *impl = calloc(1, sizeof(*impl));
    if (!impl) {
        ESP_LOGE(TAG, "alloc bridge failed");
        return NULL;
    }

#if CONFIG_SOC_DMA2D_SUPPORTED || CONFIG_SOC_PPA_SUPPORTED
    static bool hw_resource_initialized = false;
    if (!hw_resource_initialized) {
        ESP_LOGI(TAG, "Initializing hardware resources (v8)");

        ESP_ERROR_CHECK(esp_cache_get_alignment(MALLOC_CAP_SPIRAM, &hw_resource.data_cache_line_size));
        if (hw_resource.data_cache_line_size == 0) {
            hw_resource.data_cache_line_size = PPA_DEFAULT_ALIGNMENT;
        }

        hw_resource_initialized = true;
        ESP_LOGI(TAG, "Hardware resources initialized (v8)");
    }
#endif

#if CONFIG_SOC_DMA2D_SUPPORTED
    ESP_RETURN_ON_FALSE(display_bridge_get_hw_resource() != NULL, NULL, TAG, "Acquire DMA2D resource failed");
#endif

#if CONFIG_SOC_PPA_SUPPORTED
    if (hw_resource.ppa_handle == NULL) {
        ppa_client_config_t ppa_srm_config = {
            .oper_type = PPA_OPERATION_SRM,
            .max_pending_trans_num = LVGL_PORT_PPA_MAX_PENDING_TRANS,
        };
        ESP_ERROR_CHECK(ppa_register_client(&ppa_srm_config, &hw_resource.ppa_handle));
    }
#endif

    impl->base.flush = display_bridge_v8_flush_entry;
    impl->base.destroy = display_bridge_v8_destroy;
    impl->base.set_dummy_draw = display_bridge_v8_set_dummy_draw;
    impl->base.set_dummy_draw_callbacks = display_bridge_v8_set_dummy_draw_callbacks;
    impl->base.dummy_draw_blit = display_bridge_v8_dummy_draw_blit;
    impl->base.dummy_draw_get_free_buf = display_bridge_v8_dummy_draw_get_free_buf;
    impl->base.dummy_draw_flush_buf = display_bridge_v8_dummy_draw_flush_buf;
    impl->base.update_panel = display_bridge_v8_update_panel;
    impl->base.set_area_rounder = display_bridge_v8_set_area_rounder;
    impl->base.set_draw_bitmap_callbacks = display_bridge_v8_set_draw_bitmap_callbacks;
    impl->cfg = *cfg;
    impl->panel = cfg->base.panel;
    impl->dummy_draw = cfg->dummy_draw_enabled;
    impl->double_sync_lock = (portMUX_TYPE)portMUX_INITIALIZER_UNLOCKED;
    impl->double_wait_sem = NULL;
    impl->frame_buf_submit_pending = false;
    if (display_bridge_v8_configure_double_wait_resource(impl) != ESP_OK) {
        free(impl);
        return NULL;
    }
    impl->notify_task = NULL;
    impl->dummy_draw_wait_task = NULL;
    impl->dummy_draw_wait_mask = 0;
    impl->idf_callback_registration_enabled = cfg->idf_callback_registration_enabled;
    impl->cache_line_size = display_bridge_get_cache_line_size();
    display_bridge_get_block_sizes(&impl->block_size_small, &impl->block_size_large);
    if (impl->block_size_small <= 0) {
        impl->block_size_small = ESP_LV_ADAPTER_BRIDGE_BLOCK_SIZE_SMALL_DEFAULT;
    }
    if (impl->block_size_large <= 0) {
        impl->block_size_large = impl->block_size_small * 8;
    }
    if (impl->block_size_large < impl->block_size_small) {
        impl->block_size_large = impl->block_size_small;
    }

    /* Use common function for runtime info initialization */
    if (display_bridge_init_runtime_info(&impl->runtime, cfg) != ESP_OK) {
        if (impl->double_wait_sem) {
            vSemaphoreDeleteWithCaps(impl->double_wait_sem);
        }
        free(impl);
        return NULL;
    }

    /* Configure VSYNC jitter shield: Specifically for MIPI DSI and RGB panels
       in double-buffered modes to prevent visual artifacts due to race conditions. */
    const bool is_mipi = (cfg->base.profile.interface == ESP_LV_ADAPTER_PANEL_IF_MIPI_DSI);
    const bool is_double_flush = (cfg->base.tear_avoid_mode == ESP_LV_ADAPTER_TEAR_AVOID_MODE_DOUBLE_FULL ||
                                  cfg->base.tear_avoid_mode == ESP_LV_ADAPTER_TEAR_AVOID_MODE_DOUBLE_DIRECT ||
                                  cfg->base.tear_avoid_mode == ESP_LV_ADAPTER_TEAR_AVOID_MODE_DOUBLE_PARTIAL);
    if (is_mipi && is_double_flush) {
        display_bridge_vsync_config_jitter_shield(&impl->vsync_timing, 1000);
    }

    /* Create and init pipeline in bridge (disp_fb/draw_fb written via out params) */
    int pipeline_ret = display_bridge_pipeline_init_from_cfg(&impl->pipeline, &impl->cfg,
                                                             &impl->disp_fb, &impl->draw_fb);
    if (pipeline_ret == -1) {
        ESP_LOGE(TAG, "pipeline init failed");
        if (impl->double_wait_sem) {
            vSemaphoreDeleteWithCaps(impl->double_wait_sem);
        }
        free(impl);
        return NULL;
    }

    display_dirty_region_reset(&impl->dirty);
    display_bridge_v8_diff_reset(impl);
    display_bridge_v8_prime_double_buffers(impl);

    if (impl->cfg.base.profile.interface == ESP_LV_ADAPTER_PANEL_IF_OTHER &&
            impl->runtime.rotation != ESP_LV_ADAPTER_ROTATE_0 &&
            impl->cfg.base.profile.mono_layout == ESP_LV_ADAPTER_MONO_LAYOUT_NONE) {
        ESP_LOGW(TAG, "rotation=%d configured on panel interface OTHER; adapter will not apply"
                 " rotation. Configure the LCD panel orientation during panel initialization.",
                 impl->runtime.rotation);
    }

    if (impl->cfg.base.profile.interface == ESP_LV_ADAPTER_PANEL_IF_OTHER && !impl->cfg.base.panel_io) {
        ESP_LOGE(TAG, "panel_io handle required for interface OTHER");
        if (impl->pipeline.elems) {
            free(impl->pipeline.elems);
        }
        if (impl->double_wait_sem) {
            vSemaphoreDeleteWithCaps(impl->double_wait_sem);
        }
        free(impl);
        return NULL;
    }

    display_bridge_v8_register_vsync(impl);

    return &impl->base;
#endif
}

#if LVGL_VERSION_MAJOR < 9

/**
 * @brief Destroy LVGL v8 display bridge
 *
 * Cleanup function for v8 bridge implementation. Delegates to common destroy
 * function as the cleanup logic is identical across v8 and v9.
 *
 * @param[in] bridge Pointer to the display bridge to destroy
 */
static void display_bridge_v8_destroy(esp_lv_adapter_display_bridge_t *bridge)
{
    if (bridge) {
        esp_lv_adapter_display_bridge_v8_t *impl = (esp_lv_adapter_display_bridge_v8_t *)bridge;
        /* Clear VSync callbacks and free pipeline (owned by bridge) */
        display_bridge_v8_unregister_vsync(impl);
        if (impl->pipeline.elems) {
            free(impl->pipeline.elems);
            impl->pipeline.elems = NULL;
            impl->pipeline.elem_count = 0;
        }
        if (impl->double_wait_sem) {
            vSemaphoreDeleteWithCaps(impl->double_wait_sem);
            impl->double_wait_sem = NULL;
        }
    }
    /* Use unified destroy implementation for v8/v9 compatibility */
    display_bridge_common_destroy(bridge);
}

/**
 * @brief Update panel handle and configuration for rebind
 */
static esp_err_t display_bridge_v8_update_panel(esp_lv_adapter_display_bridge_t *bridge,
                                                const esp_lv_adapter_display_runtime_config_t *cfg)
{
    ESP_RETURN_ON_FALSE(bridge && cfg, ESP_ERR_INVALID_ARG, TAG, "Invalid arguments");

    esp_lv_adapter_display_bridge_v8_t *impl = (esp_lv_adapter_display_bridge_v8_t *)bridge;

    /* Unregister old VSYNC callbacks before updating panel */
    display_bridge_v8_unregister_vsync(impl);

    /* Free old pipeline (owned by bridge) */
    if (impl->pipeline.elems) {
        free(impl->pipeline.elems);
        impl->pipeline.elems = NULL;
        impl->pipeline.elem_count = 0;
    }
    STAILQ_INIT(&impl->pipeline.busy_list);
    STAILQ_INIT(&impl->pipeline.empty_list);

    /* Update panel handle */
    impl->panel = cfg->base.panel;

    /* Update configuration */
    impl->cfg = *cfg;
    impl->double_sync_lock = (portMUX_TYPE)portMUX_INITIALIZER_UNLOCKED;
    impl->pending_fb = NULL;
    impl->switch_seq = 0;
    impl->double_wait_switch_seq = 0;
    impl->double_wait_active = false;
    impl->frame_buf_submit_pending = false;
    if (display_bridge_v8_configure_double_wait_resource(impl) != ESP_OK) {
        return ESP_ERR_NO_MEM;
    }

    ESP_RETURN_ON_ERROR(display_bridge_init_runtime_info(&impl->runtime, cfg), TAG,
                        "runtime info initialization failed");

    /* Configure VSYNC jitter shield */
    const bool is_mipi = (cfg->base.profile.interface == ESP_LV_ADAPTER_PANEL_IF_MIPI_DSI);
    const bool is_double_flush = (cfg->base.tear_avoid_mode == ESP_LV_ADAPTER_TEAR_AVOID_MODE_DOUBLE_FULL ||
                                  cfg->base.tear_avoid_mode == ESP_LV_ADAPTER_TEAR_AVOID_MODE_DOUBLE_DIRECT ||
                                  cfg->base.tear_avoid_mode == ESP_LV_ADAPTER_TEAR_AVOID_MODE_DOUBLE_PARTIAL);
    if (is_mipi && is_double_flush) {
        display_bridge_vsync_config_jitter_shield(&impl->vsync_timing, 1000);
    } else {
        display_bridge_vsync_config_jitter_shield(&impl->vsync_timing, 0);
    }

    /* Re-init pipeline (same as create path, disp_fb/draw_fb via out params) */
    int pipeline_ret = display_bridge_pipeline_init_from_cfg(&impl->pipeline, &impl->cfg,
                                                             &impl->disp_fb, &impl->draw_fb);
    if (pipeline_ret == -1) {
        ESP_LOGE(TAG, "pipeline re-init failed (update_panel)");
        return ESP_ERR_NO_MEM;
    }

    /* Reset dirty region tracking */
    display_dirty_region_reset(&impl->dirty);
    display_bridge_v8_diff_reset(impl);
    display_bridge_v8_prime_double_buffers(impl);

    /* Re-register VSYNC callbacks for new panel */
    if (cfg->base.panel) {
        display_bridge_v8_register_vsync(impl);
    }

    return ESP_OK;
}

/**********************
 *   CORE CALLBACKS
 **********************/

/**
 * @brief Main flush entry point
 */
static void display_bridge_v8_flush_entry(esp_lv_adapter_display_bridge_t *bridge,
                                          void *disp_ref,
                                          const lv_area_t *area,
                                          uint8_t *color_map)
{
    esp_lv_adapter_display_bridge_v8_t *impl = (esp_lv_adapter_display_bridge_v8_t *)bridge;
    lv_disp_drv_t *drv = (lv_disp_drv_t *)disp_ref;
    if (!impl || !area || !drv) {
        if (drv) {
            display_manager_flush_ready(drv);
        }
        return;
    }

    /* Safety check: panel detached for sleep management */
    if (!impl->panel) {
        ESP_LOGD(TAG, "Panel detached, skipping flush");
        display_manager_flush_ready(drv);
        return;
    }

    if (impl->dummy_draw) {
        display_manager_flush_ready(drv);
        return;
    }

    if (!display_bridge_v8_prepare_mono(impl, drv, area, &color_map)) {
        display_manager_flush_ready(drv);
        return;
    }

    const bool mono_rotated = (impl->cfg.base.profile.mono_layout != ESP_LV_ADAPTER_MONO_LAYOUT_NONE &&
                               impl->cfg.base.profile.rotation != ESP_LV_ADAPTER_ROTATE_0);
    lv_area_t phy_area;
    const lv_area_t *flush_area = area;

    if (mono_rotated) {
        uint16_t pw = impl->cfg.base.profile.hor_res;
        uint16_t ph = impl->cfg.base.profile.ver_res;
        int x1, y1, x2, y2;

        switch (impl->cfg.base.profile.rotation) {
        case ESP_LV_ADAPTER_ROTATE_90:
            x1 = pw - 1 - area->y2;
            x2 = pw - 1 - area->y1;
            y1 = area->x1;
            y2 = area->x2;
            break;
        case ESP_LV_ADAPTER_ROTATE_180:
            x1 = pw - 1 - area->x2;
            x2 = pw - 1 - area->x1;
            y1 = ph - 1 - area->y2;
            y2 = ph - 1 - area->y1;
            break;
        case ESP_LV_ADAPTER_ROTATE_270:
            x1 = area->y1;
            x2 = area->y2;
            y1 = ph - 1 - area->x2;
            y2 = ph - 1 - area->x1;
            break;
        default:
            x1 = y1 = x2 = y2 = 0;
            break;
        }

        if (impl->cfg.base.profile.mono_layout == ESP_LV_ADAPTER_MONO_LAYOUT_VTILED) {
            y1 &= ~7;
            y2 |= 7;
        }

        phy_area.x1 = x1;
        phy_area.y1 = y1;
        phy_area.x2 = x2;
        phy_area.y2 = y2;
        flush_area = &phy_area;
    }

    const esp_lv_adapter_rotation_t rotation = bridge_rotation(impl);
    const esp_lv_adapter_tear_avoid_mode_t tear_avoid_mode = impl->cfg.base.tear_avoid_mode;
    const bool need_rotate = (rotation != ESP_LV_ADAPTER_ROTATE_0) &&
                             (impl->cfg.base.profile.interface != ESP_LV_ADAPTER_PANEL_IF_OTHER);

    if (need_rotate) {
        switch (tear_avoid_mode) {
        case ESP_LV_ADAPTER_TEAR_AVOID_MODE_TRIPLE_PARTIAL:
        case ESP_LV_ADAPTER_TEAR_AVOID_MODE_DOUBLE_PARTIAL:
            display_bridge_v8_flush_partial_rotate(impl, drv, flush_area, color_map);
            break;
        case ESP_LV_ADAPTER_TEAR_AVOID_MODE_TRIPLE_FULL:
        case ESP_LV_ADAPTER_TEAR_AVOID_MODE_DOUBLE_FULL:
            display_bridge_v8_flush_full_rotate(impl, drv, flush_area, color_map);
            break;
        case ESP_LV_ADAPTER_TEAR_AVOID_MODE_DOUBLE_DIRECT:
            display_bridge_v8_flush_direct_rotate(impl, drv, flush_area, color_map);
            break;
        default:
            ESP_LOGE(TAG, "Unsupported tear mode: %d", tear_avoid_mode);
            display_manager_flush_ready(drv);
            break;
        }
        return;
    }

    switch (tear_avoid_mode) {
    case ESP_LV_ADAPTER_TEAR_AVOID_MODE_DOUBLE_FULL:
        display_bridge_v8_flush_double_full(impl, drv, flush_area, color_map);
        break;
    case ESP_LV_ADAPTER_TEAR_AVOID_MODE_TRIPLE_FULL:
        display_bridge_v8_flush_triple_full(impl, drv, flush_area, color_map);
        break;
    case ESP_LV_ADAPTER_TEAR_AVOID_MODE_DOUBLE_DIRECT:
        display_bridge_v8_flush_double_direct(impl, drv, flush_area, color_map);
        break;
    case ESP_LV_ADAPTER_TEAR_AVOID_MODE_TRIPLE_PARTIAL:
    case ESP_LV_ADAPTER_TEAR_AVOID_MODE_DOUBLE_PARTIAL:
        display_bridge_v8_flush_triple_diff(impl, drv, flush_area, color_map);
        break;
    case ESP_LV_ADAPTER_TEAR_AVOID_MODE_TE_SYNC:
        display_bridge_v8_flush_gpio_te(impl, drv, flush_area, color_map);
        break;
    default:
        display_bridge_v8_flush_default(impl, drv, flush_area, color_map);
        break;
    }
}

/**
 * @brief Set dummy draw mode
 */
static void display_bridge_v8_set_dummy_draw(esp_lv_adapter_display_bridge_t *bridge, bool enable)
{
    esp_lv_adapter_display_bridge_v8_t *impl = (esp_lv_adapter_display_bridge_v8_t *)bridge;
    if (!impl) {
        return;
    }

    const bool was_enabled = impl->dummy_draw;
    impl->dummy_draw = enable;
    if (!enable) {
        impl->dummy_draw_wait_task = NULL;
        impl->dummy_draw_wait_mask = 0;

        /* On real disable, align buf_act to the free buffer; skip the setup call. */
        lv_disp_t *disp = impl->cfg.lv_disp;
        lv_disp_drv_t *drv = disp ? disp->driver : NULL;
        lv_disp_draw_buf_t *draw_buf = drv ? drv->draw_buf : NULL;
        if (was_enabled && draw_buf &&
                impl->runtime.rotation == ESP_LV_ADAPTER_ROTATE_0 &&
                (impl->cfg.base.tear_avoid_mode == ESP_LV_ADAPTER_TEAR_AVOID_MODE_DOUBLE_FULL ||
                 impl->cfg.base.tear_avoid_mode == ESP_LV_ADAPTER_TEAR_AVOID_MODE_TRIPLE_FULL ||
                 impl->cfg.base.tear_avoid_mode == ESP_LV_ADAPTER_TEAR_AVOID_MODE_DOUBLE_DIRECT)) {
            lv_color_t *target = NULL;

            if (draw_buf->buf1 == (lv_color_t *)impl->draw_fb) {
                target = draw_buf->buf1;
            } else if (draw_buf->buf2 == (lv_color_t *)impl->draw_fb) {
                target = draw_buf->buf2;
            } else if (draw_buf->buf1 == (lv_color_t *)impl->disp_fb && draw_buf->buf2) {
                draw_buf->buf2 = (lv_color_t *)impl->draw_fb;
                target = draw_buf->buf2;
            } else if (draw_buf->buf2 == (lv_color_t *)impl->disp_fb && draw_buf->buf1) {
                draw_buf->buf1 = (lv_color_t *)impl->draw_fb;
                target = draw_buf->buf1;
            } else if (draw_buf->buf2) {
                draw_buf->buf2 = (lv_color_t *)impl->draw_fb;
                target = draw_buf->buf2;
            } else if (draw_buf->buf1) {
                draw_buf->buf1 = (lv_color_t *)impl->draw_fb;
                target = draw_buf->buf1;
            }

            if (target) {
                draw_buf->buf_act = target;
            }
        }
    }
}

/**
 * @brief Update dummy draw callbacks
 */
static void display_bridge_v8_set_dummy_draw_callbacks(esp_lv_adapter_display_bridge_t *bridge,
                                                       const esp_lv_adapter_dummy_draw_callbacks_t *cbs,
                                                       void *user_ctx)
{
    esp_lv_adapter_display_bridge_v8_t *impl = (esp_lv_adapter_display_bridge_v8_t *)bridge;
    if (!impl) {
        return;
    }

    if (cbs) {
        impl->cfg.dummy_draw_cbs = *cbs;
        impl->cfg.dummy_draw_user_ctx = user_ctx;
    } else {
        memset(&impl->cfg.dummy_draw_cbs, 0, sizeof(impl->cfg.dummy_draw_cbs));
        impl->cfg.dummy_draw_user_ctx = NULL;
    }
}

static esp_err_t display_bridge_v8_dummy_draw_blit(esp_lv_adapter_display_bridge_t *bridge,
                                                   int x_start,
                                                   int y_start,
                                                   int x_end,
                                                   int y_end,
                                                   const void *frame_buffer,
                                                   bool wait)
{
    esp_lv_adapter_display_bridge_v8_t *impl = (esp_lv_adapter_display_bridge_v8_t *)bridge;
    if (!impl || !frame_buffer || !impl->panel) {
        return ESP_ERR_INVALID_ARG;
    }

    if (x_start < 0 || y_start < 0 || x_end <= x_start || y_end <= y_start) {
        return ESP_ERR_INVALID_ARG;
    }

    uint32_t wait_mask = wait ? ESP_LV_ADAPTER_DUMMY_DRAW_EVT_COLOR_DONE : 0;

    if (!impl->dummy_draw) {
        return ESP_ERR_INVALID_STATE;
    }

    if (wait_mask != 0) {
        if (impl->dummy_draw_wait_task) {
            return ESP_ERR_INVALID_STATE;
        }
        impl->dummy_draw_wait_task = xTaskGetCurrentTaskHandle();
        impl->dummy_draw_wait_mask = wait_mask;
    } else {
        impl->dummy_draw_wait_task = NULL;
        impl->dummy_draw_wait_mask = 0;
    }

    esp_err_t ret;
    if (impl->cfg.draw_bitmap_cbs.custom_draw_bitmap) {
        ret = impl->cfg.draw_bitmap_cbs.custom_draw_bitmap(impl->cfg.lv_disp, impl->panel,
                                                           x_start, y_start, x_end, y_end,
                                                           frame_buffer, impl->cfg.draw_bitmap_user_ctx);
    } else {
        ret = display_lcd_blit_area(impl->panel, x_start, y_start, x_end, y_end, frame_buffer);
    }
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "Blit area failed: %s", esp_err_to_name(ret));
        impl->dummy_draw_wait_task = NULL;
        impl->dummy_draw_wait_mask = 0;
        return ret;
    }

    if (wait_mask == 0) {
        return ESP_OK;
    }

    uint32_t pending = wait_mask;
    while (pending != 0) {
        uint32_t events = 0;
        (void)xTaskNotifyWait(0, wait_mask, &events, portMAX_DELAY);
        pending &= ~events;
    }

    impl->dummy_draw_wait_task = NULL;
    impl->dummy_draw_wait_mask = 0;
    return ESP_OK;
}

static void *display_bridge_v8_dummy_draw_get_free_buf(esp_lv_adapter_display_bridge_t *bridge)
{
    esp_lv_adapter_display_bridge_v8_t *impl = (esp_lv_adapter_display_bridge_v8_t *)bridge;
    if (!impl || !impl->dummy_draw) {
        return NULL;
    }
    if (!bridge_mode_uses_buf_switch_release(impl->cfg.base.tear_avoid_mode)) {
        return NULL;
    }
    return impl->draw_fb;
}

/* Strategy 1: two-buffer DOUBLE_FULL / DOUBLE_DIRECT, wait for the panel switch. */
static esp_err_t display_bridge_v8_dummy_publish_double_wait(esp_lv_adapter_display_bridge_v8_t *impl,
                                                             void *frame_buffer)
{
    esp_err_t ret = display_bridge_v8_submit_double_buffer(impl, frame_buffer);
    if (ret != ESP_OK) {
        return ret;
    }
    void *old_disp = impl->disp_fb;
    impl->disp_fb = frame_buffer;
    impl->draw_fb = old_disp;
    return ESP_OK;
}

/* Strategy 2: TRIPLE_FULL, the ISR publishes pending_fb -> disp_fb on the switch. */
static esp_err_t display_bridge_v8_dummy_publish_triple_pending(esp_lv_adapter_display_bridge_v8_t *impl,
                                                                void *frame_buffer)
{
    TaskHandle_t prev_notify = impl->notify_task;
    impl->notify_task = xTaskGetCurrentTaskHandle();

    esp_err_t ret = display_bridge_v8_blit_full_frame(impl, frame_buffer, true);
    if (ret != ESP_OK) {
        impl->notify_task = prev_notify;
        return ret;
    }

    portENTER_CRITICAL(&impl->pipeline.lock);
    impl->pending_fb = frame_buffer;
    portEXIT_CRITICAL(&impl->pipeline.lock);

    display_bridge_pipeline_mark_buf_busy(&impl->pipeline, impl->disp_fb);

    struct display_pipeline_buf *next = display_bridge_pipeline_wait_free_buf(&impl->pipeline);
    impl->notify_task = prev_notify;

    if (!next) {
        return ESP_ERR_NOT_FOUND;
    }
    impl->draw_fb = next->buffer;
    return ESP_OK;
}

/* Strategy 3: generic pipeline for partial and rotated modes, ISR releases a buffer. */
static esp_err_t display_bridge_v8_dummy_publish_pipeline(esp_lv_adapter_display_bridge_v8_t *impl,
                                                          void *frame_buffer)
{
    TaskHandle_t prev_notify = impl->notify_task;
    impl->notify_task = xTaskGetCurrentTaskHandle();

    esp_err_t ret = display_bridge_v8_blit_full_frame(impl, frame_buffer, true);
    if (ret != ESP_OK) {
        impl->notify_task = prev_notify;
        return ret;
    }

    display_bridge_pipeline_mark_buf_busy(&impl->pipeline, impl->disp_fb);

    struct display_pipeline_buf *next = display_bridge_pipeline_wait_free_buf(&impl->pipeline);
    impl->notify_task = prev_notify;

    if (!next) {
        return ESP_ERR_NOT_FOUND;
    }
    impl->disp_fb = frame_buffer;
    impl->draw_fb = next->buffer;
    display_bridge_v8_diff_reset(impl);
    return ESP_OK;
}

static esp_err_t display_bridge_v8_dummy_draw_flush_buf(esp_lv_adapter_display_bridge_t *bridge,
                                                        void *frame_buffer)
{
    esp_lv_adapter_display_bridge_v8_t *impl = (esp_lv_adapter_display_bridge_v8_t *)bridge;
    if (!impl || !frame_buffer || !impl->panel || !impl->dummy_draw) {
        return ESP_ERR_INVALID_ARG;
    }

    const esp_lv_adapter_tear_avoid_mode_t mode = impl->cfg.base.tear_avoid_mode;
    if (!bridge_mode_uses_buf_switch_release(mode)) {
        return ESP_ERR_NOT_SUPPORTED;
    }

    if (impl->draw_fb != frame_buffer) {
        ESP_LOGW(TAG, "dummy draw fb mismatch (arg=%p, draw_fb=%p)", frame_buffer, impl->draw_fb);
        impl->draw_fb = frame_buffer;
    }

    const bool rotated = bridge_mode_uses_rotated_nonpartial_pipeline_release(impl);
    if (!rotated && bridge_mode_uses_double_switch_wait(mode)) {
        return display_bridge_v8_dummy_publish_double_wait(impl, frame_buffer);
    }
    if (!rotated && mode == ESP_LV_ADAPTER_TEAR_AVOID_MODE_TRIPLE_FULL) {
        return display_bridge_v8_dummy_publish_triple_pending(impl, frame_buffer);
    }
    return display_bridge_v8_dummy_publish_pipeline(impl, frame_buffer);
}

/**
 * @brief Wrapper callback for area rounding (LVGL v8)
 */
static void rounder_cb_wrapper(lv_disp_drv_t *drv, lv_area_t *area)
{
    /* user_data points to display_node, get bridge from node */
    esp_lv_adapter_display_node_t *node = (esp_lv_adapter_display_node_t *)drv->user_data;
    if (!node || !node->bridge) {
        return;
    }

    esp_lv_adapter_display_bridge_v8_t *impl = (esp_lv_adapter_display_bridge_v8_t *)node->bridge;
    const uint8_t color_bytes = bridge_color_bytes(impl);
    if (impl->cfg.rounder_cb) {
        impl->cfg.rounder_cb(area, impl->cfg.rounder_user_data);
    }
    /* Align area for encrypted external-RAM DMA. Checks source (draw_buf_primary)
     * and dest (draw_fb, stride-aligned only — unaligned stride falls back to CPU copy). */
    if (display_bridge_dma2d_buffer_needs_alignment(impl->cfg.draw_buf_primary) ||
            display_bridge_dma2d_x_rounding_sufficient(impl->draw_fb, drv->hor_res, color_bytes)) {
        display_bridge_align_area_for_enc_dma(area, drv->hor_res, color_bytes);
    }
}

/**
 * @brief Set area rounding callback
 */
static void display_bridge_v8_set_area_rounder(esp_lv_adapter_display_bridge_t *bridge,
                                               void (*rounder_cb)(lv_area_t *, void *),
                                               void *user_data)
{
    esp_lv_adapter_display_bridge_v8_t *impl = (esp_lv_adapter_display_bridge_v8_t *)bridge;
    if (!impl) {
        return;
    }

    impl->cfg.rounder_cb = rounder_cb;
    impl->cfg.rounder_user_data = user_data;

    lv_disp_drv_t *drv = impl->cfg.lv_disp ? impl->cfg.lv_disp->driver : NULL;
    if (drv) {
        /* draw_fb: require aligned stride; unaligned stride means rounding won't
         * enable DMA and the flush path already falls back to CPU copy. */
        const bool need_dma2d_rounder =
            display_bridge_dma2d_buffer_needs_alignment(impl->cfg.draw_buf_primary) ||
            display_bridge_dma2d_x_rounding_sufficient(impl->draw_fb,
                                                       bridge_h_res(impl),
                                                       bridge_color_bytes(impl));
        drv->rounder_cb = (rounder_cb || need_dma2d_rounder)
                          ? rounder_cb_wrapper : NULL;
    }
}

static void display_bridge_v8_set_draw_bitmap_callbacks(esp_lv_adapter_display_bridge_t *bridge,
                                                        const esp_lv_adapter_draw_bitmap_callbacks_t *cbs,
                                                        void *user_ctx)
{
    esp_lv_adapter_display_bridge_v8_t *impl = (esp_lv_adapter_display_bridge_v8_t *)bridge;
    if (!impl) {
        return;
    }

    if (cbs) {
        impl->cfg.draw_bitmap_cbs = *cbs;
        impl->cfg.draw_bitmap_user_ctx = user_ctx;
    } else {
        memset(&impl->cfg.draw_bitmap_cbs, 0, sizeof(impl->cfg.draw_bitmap_cbs));
        impl->cfg.draw_bitmap_user_ctx = NULL;
    }
}

/**********************
 *   DUMMY DRAW EVENTS
 **********************/

static inline void display_bridge_v8_signal_dummy_draw_event(esp_lv_adapter_display_bridge_v8_t *impl,
                                                             uint32_t event_bit,
                                                             BaseType_t *need_yield)
{
    if (!impl) {
        return;
    }
    if (!(impl->dummy_draw_wait_mask & event_bit)) {
        return;
    }
    TaskHandle_t task = impl->dummy_draw_wait_task;
    if (!task) {
        return;
    }
    xTaskNotifyFromISR(task, event_bit, eSetBits, need_yield);
}

static bool display_bridge_v8_has_pending_submit(esp_lv_adapter_display_bridge_v8_t *impl)
{
    if (!impl) {
        return false;
    }

    bool pending = false;
    portENTER_CRITICAL(&impl->pipeline.lock);
    pending = (impl->pending_fb != NULL);
    portEXIT_CRITICAL(&impl->pipeline.lock);
    return pending;
}

static void display_bridge_v8_wait_for_buf_switch(esp_lv_adapter_display_bridge_v8_t *impl)
{
    if (!impl) {
        return;
    }

    for (;;) {
        ulTaskNotifyValueClear(NULL, ULONG_MAX);
        if (!display_bridge_v8_has_pending_submit(impl)) {
            break;
        }
        ulTaskNotifyTake(pdTRUE, portMAX_DELAY);
    }
}

/**********************
 *   VSYNC HANDLING
 **********************/

/**
 * @brief VSync event handler (common logic)
 */
static bool IRAM_ATTR display_bridge_v8_handle_vsync(esp_lv_adapter_display_bridge_v8_t *impl)
{
    if (!impl) {
        return false;
    }
    BaseType_t need_yield = pdFALSE;

    if (impl->cfg.base.tear_avoid_mode == ESP_LV_ADAPTER_TEAR_AVOID_MODE_NONE) {
        lv_disp_t *disp = impl->cfg.lv_disp ? impl->cfg.lv_disp : lv_disp_get_default();
        if (disp) {
            display_manager_flush_ready(disp->driver);
        }
        return (need_yield == pdTRUE);
    }

    const esp_lv_adapter_tear_avoid_mode_t mode = impl->cfg.base.tear_avoid_mode;
    if (!bridge_mode_uses_buf_switch_release(mode)) {
        return (need_yield == pdTRUE);
    }

    if (display_bridge_vsync_on_isr(&impl->vsync_timing)) {
        return pdFALSE;
    }

    return (need_yield == pdTRUE);
}

/*
 * Shared frame-buffer-switch ISR handler. Its only callers are the MIPI DSI and
 * RGB frame-complete callbacks, both compiled out on SoCs that have neither
 * controller; mark it unused so such targets stay warning-clean (the linker
 * garbage-collects it). Keeping it interface-agnostic avoids wrapping pure logic
 * in panel-type macros.
 */
static bool IRAM_ATTR __attribute__((unused))
display_bridge_v8_handle_frame_buf_complete(esp_lv_adapter_display_bridge_v8_t *impl)
{
    if (!impl) {
        return false;
    }

    BaseType_t need_yield = pdFALSE;

    display_bridge_v8_signal_dummy_draw_event(impl, ESP_LV_ADAPTER_DUMMY_DRAW_EVT_FRAME_DONE, &need_yield);

    const esp_lv_adapter_tear_avoid_mode_t mode = impl->cfg.base.tear_avoid_mode;
    if (!bridge_mode_uses_buf_switch_release(mode)) {
        return (need_yield == pdTRUE);
    }

    bool switched = true;
    if (mode == ESP_LV_ADAPTER_TEAR_AVOID_MODE_TRIPLE_FULL &&
            !bridge_mode_uses_rotated_nonpartial_pipeline_release(impl)) {
        switched = false;
        portENTER_CRITICAL_ISR(&impl->pipeline.lock);
        if (impl->pending_fb) {
            impl->disp_fb = impl->pending_fb;
            impl->pending_fb = NULL;
            switched = true;
        }
        portEXIT_CRITICAL_ISR(&impl->pipeline.lock);
    }

    if (!switched) {
        return false;
    }

    if (!display_bridge_v8_consume_frame_buf_submit_isr(impl)) {
        return false;
    }

    impl->switch_seq++;

    if (bridge_mode_uses_rotated_nonpartial_pipeline_release(impl) ||
            mode == ESP_LV_ADAPTER_TEAR_AVOID_MODE_TRIPLE_FULL ||
            mode == ESP_LV_ADAPTER_TEAR_AVOID_MODE_TRIPLE_PARTIAL ||
            mode == ESP_LV_ADAPTER_TEAR_AVOID_MODE_DOUBLE_PARTIAL) {
        display_bridge_pipeline_release_buf_isr(&impl->pipeline);

        TaskHandle_t notify_task = display_bridge_v8_get_notify_task(impl);
        if (notify_task) {
            vTaskNotifyGiveFromISR(notify_task, &need_yield);
        }
    } else {
        bool double_ready = display_bridge_v8_complete_double_wait_isr(impl);
        if (double_ready && impl->double_wait_sem) {
            xSemaphoreGiveFromISR(impl->double_wait_sem, &need_yield);
        }
    }

    return (need_yield == pdTRUE);
}

#if CONFIG_SOC_MIPI_DSI_SUPPORTED
static bool IRAM_ATTR display_bridge_v8_on_mipi_color_trans_done(esp_lcd_panel_handle_t panel,
                                                                 esp_lcd_dpi_panel_event_data_t *event_data,
                                                                 void *user_ctx)
{
    (void)panel;
    (void)event_data;
    esp_lv_adapter_display_bridge_v8_t *impl = (esp_lv_adapter_display_bridge_v8_t *)user_ctx;

    /* Safety check: panel detached for sleep management */
    if (!impl || !impl->panel) {
        return false;
    }

    BaseType_t need_yield = pdFALSE;
    display_bridge_v8_signal_dummy_draw_event(impl, ESP_LV_ADAPTER_DUMMY_DRAW_EVT_COLOR_DONE, &need_yield);
    bool vsync = false;
    if (impl->cfg.base.tear_avoid_mode == ESP_LV_ADAPTER_TEAR_AVOID_MODE_NONE) {
        vsync = display_bridge_v8_handle_vsync(impl);
    }
    return vsync || (need_yield == pdTRUE);
}

static bool IRAM_ATTR display_bridge_v8_on_mipi_frame_buf_complete(esp_lcd_panel_handle_t panel,
                                                                   esp_lcd_dpi_panel_event_data_t *event_data,
                                                                   void *user_ctx)
{
    (void)panel;
    (void)event_data;
    esp_lv_adapter_display_bridge_v8_t *impl = (esp_lv_adapter_display_bridge_v8_t *)user_ctx;

    if (!impl || !impl->panel) {
        return false;
    }

    return display_bridge_v8_handle_frame_buf_complete(impl);
}
#endif

#if CONFIG_SOC_LCD_RGB_SUPPORTED
static bool IRAM_ATTR display_bridge_v8_on_rgb_color_trans_done(esp_lcd_panel_handle_t panel,
                                                                const esp_lcd_rgb_panel_event_data_t *event_data,
                                                                void *user_ctx)
{
    (void)panel;
    (void)event_data;
    esp_lv_adapter_display_bridge_v8_t *impl = (esp_lv_adapter_display_bridge_v8_t *)user_ctx;

    /* Safety check: panel detached for sleep management */
    if (!impl || !impl->panel) {
        return false;
    }

    BaseType_t need_yield = pdFALSE;
    display_bridge_v8_signal_dummy_draw_event(impl, ESP_LV_ADAPTER_DUMMY_DRAW_EVT_COLOR_DONE, &need_yield);
    bool vsync = false;
    if (impl->cfg.base.tear_avoid_mode == ESP_LV_ADAPTER_TEAR_AVOID_MODE_NONE) {
        vsync = display_bridge_v8_handle_vsync(impl);
    }
    return vsync || (need_yield == pdTRUE);
}

static bool IRAM_ATTR display_bridge_v8_on_rgb_frame_complete(esp_lcd_panel_handle_t panel,
                                                              const esp_lcd_rgb_panel_event_data_t *event_data,
                                                              void *user_ctx)
{
    (void)panel;
    (void)event_data;
    esp_lv_adapter_display_bridge_v8_t *impl = (esp_lv_adapter_display_bridge_v8_t *)user_ctx;

    /* Safety check: panel detached for sleep management */
    if (!impl || !impl->panel) {
        return false;
    }

    bool buf_switch = display_bridge_v8_handle_frame_buf_complete(impl);
    bool vsync = display_bridge_v8_handle_vsync(impl);
    return buf_switch || vsync;
}
#endif

static bool IRAM_ATTR display_bridge_v8_on_io_color_trans_done(esp_lcd_panel_io_handle_t panel_io,
                                                               esp_lcd_panel_io_event_data_t *edata,
                                                               void *user_ctx)
{
    (void)panel_io;
    (void)edata;
    esp_lv_adapter_display_bridge_v8_t *impl = (esp_lv_adapter_display_bridge_v8_t *)user_ctx;

    /* Safety check: panel detached for sleep management */
    if (!impl || !impl->panel) {
        return false;
    }

    BaseType_t need_yield = pdFALSE;
    display_bridge_v8_signal_dummy_draw_event(impl, ESP_LV_ADAPTER_DUMMY_DRAW_EVT_COLOR_DONE, &need_yield);
    if (impl->cfg.base.tear_avoid_mode == ESP_LV_ADAPTER_TEAR_AVOID_MODE_TE_SYNC) {
        TaskHandle_t notify_task = display_bridge_v8_get_notify_task(impl);
        if (notify_task) {
            vTaskNotifyGiveFromISR(notify_task, &need_yield);
        }
        return (need_yield == pdTRUE);
    }
    bool vsync = display_bridge_v8_handle_vsync(impl);
    return vsync || (need_yield == pdTRUE);
}

/**
 * @brief Register VSync callbacks based on panel interface type
 */
static void display_bridge_v8_register_vsync(esp_lv_adapter_display_bridge_v8_t *impl)
{
    if (!impl || !impl->panel) {
        return;
    }

    if (impl->idf_callbacks_registered || !impl->idf_callback_registration_enabled) {
        return;
    }

    bool registered = false;
    switch (impl->cfg.base.profile.interface) {
    case ESP_LV_ADAPTER_PANEL_IF_MIPI_DSI:
#if CONFIG_SOC_MIPI_DSI_SUPPORTED
    {
        const esp_lv_adapter_tear_avoid_mode_t mode = impl->cfg.base.tear_avoid_mode;
        esp_lcd_dpi_panel_event_callbacks_t cbs = {
            .on_color_trans_done = display_bridge_v8_on_mipi_color_trans_done,
#ifdef ESP_LCD_DPI_HAS_FRAME_BUF_COMPLETE_CB
            .on_frame_buf_complete = (bridge_mode_uses_buf_switch_release(mode) || impl->dummy_draw) ? display_bridge_v8_on_mipi_frame_buf_complete : NULL,
#else
            .on_refresh_done = (bridge_mode_uses_buf_switch_release(mode) || impl->dummy_draw) ? display_bridge_v8_on_mipi_frame_buf_complete : NULL,
#endif
        };

#ifndef ESP_LCD_DPI_HAS_FRAME_BUF_COMPLETE_CB
        ESP_LOGW(TAG, "on_frame_buf_complete unavailable; buffer-switch release and dummy-draw may not function on MIPI DSI");
#endif
        esp_err_t ret = esp_lcd_dpi_panel_register_event_callbacks(impl->panel, &cbs, impl);
        if (ret != ESP_OK) {
            ESP_LOGW(TAG, "register panel callbacks failed (%d)", ret);
        } else {
            registered = true;
        }
        break;
    }
#else
    break;
#endif
    case ESP_LV_ADAPTER_PANEL_IF_RGB:
#if CONFIG_SOC_LCD_RGB_SUPPORTED
    {
        esp_lcd_rgb_panel_event_callbacks_t cbs = {
            .on_color_trans_done = display_bridge_v8_on_rgb_color_trans_done,
            .on_frame_buf_complete = display_bridge_v8_on_rgb_frame_complete,
        };

        esp_err_t ret = esp_lcd_rgb_panel_register_event_callbacks(impl->panel, &cbs, impl);
        if (ret != ESP_OK) {
            ESP_LOGW(TAG, "register panel callbacks failed (%d)", ret);
        } else {
            registered = true;
        }
        break;
    }
#else
        /* no RGB support, fallthrough to IO registration */
#endif
    default: {
        esp_lcd_panel_io_handle_t panel_io = impl->cfg.base.panel_io;
        if (!panel_io) {
            ESP_LOGW(TAG, "panel_io handle missing, skip IO callbacks");
            break;
        }

        esp_lcd_panel_io_callbacks_t cbs = {
            .on_color_trans_done = display_bridge_v8_on_io_color_trans_done,
        };
        esp_err_t ret = esp_lcd_panel_io_register_event_callbacks(panel_io, &cbs, impl);
        if (ret != ESP_OK) {
            ESP_LOGW(TAG, "register panel IO callbacks failed (%d)", ret);
        } else {
            registered = true;
        }
        break;
    }
    }

    impl->idf_callbacks_registered = registered;
}

static void display_bridge_v8_unregister_vsync(esp_lv_adapter_display_bridge_v8_t *impl)
{
    if (!impl) {
        return;
    }

    if (!impl->idf_callbacks_registered) {
        return;
    }

    switch (impl->cfg.base.profile.interface) {
    case ESP_LV_ADAPTER_PANEL_IF_MIPI_DSI:
#if CONFIG_SOC_MIPI_DSI_SUPPORTED
    {
        if (!impl->panel) {
            break;
        }

        const esp_lcd_dpi_panel_event_callbacks_t cbs = {0};
        esp_err_t ret = esp_lcd_dpi_panel_register_event_callbacks(impl->panel, &cbs, NULL);
        if (ret != ESP_OK) {
            ESP_LOGW(TAG, "Failed to clear panel callbacks (%d)", ret);
        }
        break;
    }
#else
    break;
#endif
    case ESP_LV_ADAPTER_PANEL_IF_RGB:
#if CONFIG_SOC_LCD_RGB_SUPPORTED
    {
        if (!impl->panel) {
            break;
        }

        const esp_lcd_rgb_panel_event_callbacks_t cbs = {0};
        esp_err_t ret = esp_lcd_rgb_panel_register_event_callbacks(impl->panel, &cbs, NULL);
        if (ret != ESP_OK) {
            ESP_LOGW(TAG, "Failed to clear panel callbacks (%d)", ret);
        }
        break;
    }
#else
        /* no RGB support, fallthrough to IO unregistration */
#endif
    default: {
        esp_lcd_panel_io_handle_t panel_io = impl->cfg.base.panel_io;
        if (!panel_io) {
            break;
        }

        const esp_lcd_panel_io_callbacks_t cbs = {0};
        esp_err_t ret = esp_lcd_panel_io_register_event_callbacks(panel_io, &cbs, NULL);
        if (ret != ESP_OK) {
            ESP_LOGW(TAG, "Failed to clear panel IO callbacks (%d)", ret);
        }
        break;
    }
    }

    impl->idf_callbacks_registered = false;
}

/**********************
 *   FLUSH IMPLEMENTATIONS
 **********************/

/**
 * @brief Default flush (single buffer, no tear protection)
 */
static void display_bridge_v8_flush_default(esp_lv_adapter_display_bridge_v8_t *impl,
                                            lv_disp_drv_t *drv,
                                            const lv_area_t *area,
                                            uint8_t *color_map)
{
    esp_lcd_panel_handle_t panel_handle = impl->panel;
    const int offsetx1 = area->x1;
    const int offsetx2 = area->x2;
    const int offsety1 = area->y1;
    const int offsety2 = area->y2;

    if (impl->cfg.draw_bitmap_cbs.custom_draw_bitmap) {
        esp_err_t ret = impl->cfg.draw_bitmap_cbs.custom_draw_bitmap(impl->cfg.lv_disp, panel_handle,
                                                                     offsetx1, offsety1, offsetx2 + 1, offsety2 + 1,
                                                                     color_map, impl->cfg.draw_bitmap_user_ctx);
        if (ret != ESP_OK) {
            if (ret == ESP_ERR_NOT_ALLOWED) {
                ESP_LOGD(TAG, "Custom draw bitmap not allowed, skipping");
            } else {
                ESP_LOGE(TAG, "Custom draw bitmap failed: %s", esp_err_to_name(ret));
            }
            display_manager_flush_ready(drv);
        }
    } else {
        esp_err_t ret = esp_lcd_panel_draw_bitmap(panel_handle, offsetx1, offsety1, offsetx2 + 1, offsety2 + 1, color_map);
        if (ret != ESP_OK) {
            ESP_LOGE(TAG, "Draw bitmap failed: %s", esp_err_to_name(ret));
            /* Callback won't be triggered on failure, must notify LVGL immediately */
            display_manager_flush_ready(drv);
        }
    }
}

/**
 * @brief GPIO TE synchronized flush
 */
static void display_bridge_v8_flush_gpio_te(esp_lv_adapter_display_bridge_v8_t *impl,
                                            lv_disp_drv_t *drv,
                                            const lv_area_t *area,
                                            uint8_t *color_map)
{
    esp_lcd_panel_handle_t panel_handle = impl->panel;
    const int offsetx1 = area->x1;
    const int offsetx2 = area->x2;
    const int offsety1 = area->y1;
    const int offsety2 = area->y2;

    /* Prepare pixel data before waiting for TE to avoid window jitter */
    size_t flush_size = (size_t)lv_area_get_size(area) * bridge_color_bytes(impl);
#if CONFIG_SOC_PPA_SUPPORTED || CONFIG_SOC_DMA2D_SUPPORTED
    display_cache_msync_range(color_map, flush_size, hw_resource.data_cache_line_size);
#else
    display_cache_msync_range(color_map, flush_size, impl->cache_line_size);
#endif

    /* Notify TE sync to start a new frame */
    if (impl->cfg.te_ctx) {
        esp_lv_adapter_te_sync_begin_frame(impl->cfg.te_ctx, flush_size);
    }

    /* Wait for TE signal to avoid tearing */
    if (impl->cfg.te_ctx) {
        (void)esp_lv_adapter_te_sync_wait_for_vsync(impl->cfg.te_ctx);
    }

    if (impl->cfg.te_ctx) {
        esp_lv_adapter_te_sync_record_tx_start(impl->cfg.te_ctx);
    }

    /* Clear stale completion notifications before kicking off a new transfer. */
    ulTaskNotifyValueClear(NULL, ULONG_MAX);
    esp_err_t ret = esp_lcd_panel_draw_bitmap(panel_handle, offsetx1, offsety1, offsetx2 + 1, offsety2 + 1, color_map);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "Draw bitmap failed: %s", esp_err_to_name(ret));
        if (impl->cfg.te_ctx) {
            esp_lv_adapter_te_sync_record_tx_done(impl->cfg.te_ctx);
        }
        display_manager_flush_ready(drv);
        return;
    }

    /* Wait for transmission to complete */
    ulTaskNotifyTake(pdTRUE, portMAX_DELAY);
    if (impl->cfg.te_ctx) {
        esp_lv_adapter_te_sync_record_tx_done(impl->cfg.te_ctx);
    }

    display_manager_flush_ready(drv);
}

/**
 * @brief Double buffering with full-screen refresh
 */
static void display_bridge_v8_flush_double_full(esp_lv_adapter_display_bridge_v8_t *impl,
                                                lv_disp_drv_t *drv,
                                                const lv_area_t *area,
                                                uint8_t *color_map)
{
    (void)area;
    /* Action after last area refresh */
    if (drv->draw_buf->last_area) {
        esp_err_t ret = display_bridge_v8_submit_double_buffer(impl, color_map);
        if (ret != ESP_OK) {
            ESP_LOGE(TAG, "Blit failed: %s", esp_err_to_name(ret));
            display_manager_flush_ready(drv);
            return;
        }
    }

    display_manager_flush_ready(drv);
}

static void display_bridge_v8_flush_triple_full(esp_lv_adapter_display_bridge_v8_t *impl,
                                                lv_disp_drv_t *drv,
                                                const lv_area_t *area,
                                                uint8_t *color_map)
{
    (void)area;
    lv_disp_draw_buf_t *draw_buf = drv->draw_buf;

    display_bridge_v8_wait_for_buf_switch(impl);

    esp_err_t ret = display_bridge_v8_blit_full_frame(impl, color_map, false);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "Blit failed: %s", esp_err_to_name(ret));
    } else {
        display_bridge_pipeline_mark_buf_busy(&impl->pipeline, impl->disp_fb);
        portENTER_CRITICAL(&impl->pipeline.lock);
        impl->pending_fb = color_map;
        portEXIT_CRITICAL(&impl->pipeline.lock);

        struct display_pipeline_buf *next = display_bridge_pipeline_wait_free_buf(&impl->pipeline);
        if (!next) {
            display_manager_flush_ready(drv);
            return;
        }
        impl->draw_fb = next->buffer;

        if (draw_buf && draw_buf->buf2) {
            if (draw_buf->buf_act == draw_buf->buf1) {
                draw_buf->buf2 = (lv_color_t *)impl->draw_fb;
            } else {
                draw_buf->buf1 = (lv_color_t *)impl->draw_fb;
            }
        }
    }

    display_manager_flush_ready(drv);
}

/**
 * @brief Double buffering with direct mode
 */
static void display_bridge_v8_flush_double_direct(esp_lv_adapter_display_bridge_v8_t *impl,
                                                  lv_disp_drv_t *drv,
                                                  const lv_area_t *area,
                                                  uint8_t *color_map)
{
    (void)area;

    if (lv_disp_flush_is_last(drv)) {
        esp_err_t ret = display_bridge_v8_submit_double_buffer(impl, color_map);
        if (ret != ESP_OK) {
            ESP_LOGE(TAG, "Blit failed: %s", esp_err_to_name(ret));
            display_manager_flush_ready(drv);
            return;
        }
    }

    display_manager_flush_ready(drv);
}

/**
 * @brief Triple buffering with partial differential update
 */
static void display_bridge_v8_flush_triple_diff(esp_lv_adapter_display_bridge_v8_t *impl,
                                                lv_disp_drv_t *drv,
                                                const lv_area_t *area,
                                                uint8_t *color_map)
{
    uint8_t lvgl_color_format_bytes = bridge_color_bytes(impl);
    uint16_t lvgl_port_h_res = bridge_h_res(impl);
#if SOC_DMA2D_SUPPORTED
    uint16_t lvgl_port_v_res = bridge_v_res(impl);
#endif

#if SOC_DMA2D_SUPPORTED
    size_t rect_w = area->x2 - area->x1 + 1;
    size_t rect_h = area->y2 - area->y1 + 1;
    size_t src_stride_px = rect_w;
    size_t src_offset_x = 0;
    const bool can_use_dma2d =
        display_bridge_dma2d_window_is_compatible(color_map,
                                                  src_stride_px,
                                                  src_offset_x,
                                                  rect_w,
                                                  lvgl_color_format_bytes) &&
        display_bridge_dma2d_window_is_compatible(impl->draw_fb,
                                                  lvgl_port_h_res,
                                                  area->x1,
                                                  rect_w,
                                                  lvgl_color_format_bytes);

    if (can_use_dma2d) {
        size_t flush_size = src_stride_px * rect_h * lvgl_color_format_bytes;
        display_cache_msync_range(color_map, flush_size, hw_resource.data_cache_line_size);

#ifdef ESP_ASYNC_COLOR_CONVERT_AVAILABLE
        async_color_convert_request_t blit = {
            .src_buffer  = color_map,
            .dst_buffer  = impl->draw_fb,
            .src_stride  = src_stride_px,
            .src_height  = rect_h,
            .src_x       = src_offset_x,
            .src_y       = 0,
            .dst_stride  = lvgl_port_h_res,
            .dst_height  = lvgl_port_v_res,
            .dst_x       = area->x1,
            .dst_y       = area->y1,
            .copy_width  = rect_w,
            .copy_height = rect_h,
            DMA2D_PIXEL_FORMAT_FIELD(lvgl_color_format_bytes),
        };
#else
        esp_async_fbcpy_trans_desc_t blit = {
            .src_buffer        = color_map,
            .dst_buffer        = impl->draw_fb,
            .src_buffer_size_x = src_stride_px,
            .src_buffer_size_y = rect_h,
            .src_offset_x      = src_offset_x,
            .src_offset_y      = 0,
            .dst_buffer_size_x = lvgl_port_h_res,
            .dst_buffer_size_y = lvgl_port_v_res,
            .dst_offset_x      = area->x1,
            .dst_offset_y      = area->y1,
            .copy_size_x       = rect_w,
            .copy_size_y       = rect_h,
            DMA2D_PIXEL_FORMAT_FIELD(lvgl_color_format_bytes),
        };
#endif

        ESP_ERROR_CHECK(display_bridge_dma2d_copy_sync(&blit, portMAX_DELAY));
    } else {
#endif
        const int bytes_per_pixel = lvgl_color_format_bytes;
        const int bytes_per_line = lvgl_port_h_res * bytes_per_pixel;
        const int copy_bytes = (area->x2 - area->x1 + 1) * bytes_per_pixel;
        uint8_t *src = (uint8_t *)color_map;
        uint8_t *dst = (uint8_t *)impl->draw_fb + (area->y1 * lvgl_port_h_res + area->x1) * bytes_per_pixel;

        int num_rows = area->y2 - area->y1 + 1;
        bool is_full_width = (copy_bytes == bytes_per_line);

        if (is_full_width && num_rows > 4) {
            size_t total_bytes = (size_t)num_rows * bytes_per_line;
            memcpy(dst, src, total_bytes);
        } else if (num_rows > 16 && copy_bytes > 64) {
            const int batch_rows = 8;
            int full_batches = num_rows / batch_rows;
            int remaining_rows = num_rows % batch_rows;

            for (int batch = 0; batch < full_batches; batch++) {
                for (int r = 0; r < batch_rows; r++) {
                    memcpy(dst, src, copy_bytes);
                    dst += bytes_per_line;
                    src += copy_bytes;
                }
            }

            for (int r = 0; r < remaining_rows; r++) {
                memcpy(dst, src, copy_bytes);
                dst += bytes_per_line;
                src += copy_bytes;
            }
        } else if (copy_bytes == 2 && num_rows <= 8) {
            uint16_t *dst16 = (uint16_t *)dst;
            uint16_t *src16 = (uint16_t *)src;
            for (int y = 0; y < num_rows; y++) {
                *dst16 = *src16;
                dst16 += lvgl_port_h_res;
                src16++;
            }
        } else {
            for (int y = area->y1; y <= area->y2; y++) {
                memcpy(dst, src, copy_bytes);
                dst += bytes_per_line;
                src += copy_bytes;
            }
        }
#if SOC_DMA2D_SUPPORTED
    }
#endif

    if (lv_disp_flush_is_last(drv)) {
        lv_disp_t *disp_refr = _lv_refr_get_disp_refreshing();
        lv_area_t current[DISPLAY_BRIDGE_V8_DIFF_RECT_CAPACITY];
        uint16_t current_count = 0;
        uint8_t target_index = UINT8_MAX;
        bool reset_tracker = false;

        if (!display_bridge_v8_prepare_partial_back_buffer(
                    impl, disp_refr, false, current, &current_count,
                    &target_index, &reset_tracker)) {
            display_manager_flush_ready(drv);
            return;
        }

#if SOC_DMA2D_SUPPORTED
        display_cache_msync_framebuffer(impl->draw_fb, impl->runtime.frame_buffer_size);
        display_cache_msync_invalidate_framebuffer(impl->draw_fb, impl->runtime.frame_buffer_size);
#endif

        esp_err_t ret = display_bridge_v8_blit_full_frame(impl, impl->draw_fb, true);
        if (ret != ESP_OK) {
            ESP_LOGE(TAG, "Blit failed: %s", esp_err_to_name(ret));
        } else {
            display_bridge_pipeline_mark_buf_busy(&impl->pipeline, impl->disp_fb);

            struct display_pipeline_buf *next = display_bridge_pipeline_wait_free_buf(&impl->pipeline);
            if (!next) {
                display_manager_flush_ready(drv);
                return;
            }
            impl->disp_fb = impl->draw_fb;
            impl->draw_fb = next->buffer;
            if (reset_tracker) {
                display_bridge_v8_diff_reset(impl);
            } else {
                display_bridge_v8_diff_commit(
                    impl, target_index, current, current_count);
            }
        }
#if CONFIG_ESP_LVGL_ADAPTER_PARTIAL_AUX_IMG_CACHE
        lv_img_cache_invalidate_src(NULL);
#endif
    }

    display_manager_flush_ready(drv);
}

/**
 * @brief Direct mode flush with rotation support (double buffering)
 */
static void display_bridge_v8_flush_direct_rotate(esp_lv_adapter_display_bridge_v8_t *impl,
                                                  lv_disp_drv_t *drv,
                                                  const lv_area_t *area,
                                                  uint8_t *color_map)
{
    if (!lv_disp_flush_is_last(drv)) {
        display_manager_flush_ready(drv);
        return;
    }

    flush_dirty_save(&impl->dirty);
    flush_dirty_copy(impl, impl->draw_fb, color_map, &impl->dirty);

    esp_err_t ret = display_bridge_v8_blit_full_frame(impl, impl->draw_fb, false);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "Blit failed: %s", esp_err_to_name(ret));
        display_manager_flush_ready(drv);
        return;
    }

    display_bridge_pipeline_mark_buf_busy(&impl->pipeline, impl->disp_fb);

    struct display_pipeline_buf *next = display_bridge_pipeline_wait_free_buf(&impl->pipeline);
    if (!next) {
        display_manager_flush_ready(drv);
        return;
    }
    impl->disp_fb = impl->draw_fb;
    impl->draw_fb = next->buffer;
    flush_dirty_copy(impl, impl->draw_fb, color_map, &impl->dirty);

    display_manager_flush_ready(drv);
}

/**
 * @brief Full refresh with rotation
 */
static void display_bridge_v8_flush_full_rotate(esp_lv_adapter_display_bridge_v8_t *impl,
                                                lv_disp_drv_t *drv,
                                                const lv_area_t *area,
                                                uint8_t *color_map)
{
    uint16_t logical_w = 0;
    uint16_t logical_h = 0;
    uint16_t physical_w = 0;
    uint16_t physical_h = 0;
    display_bridge_v8_get_rotation_geometry(impl, &logical_w, &logical_h, &physical_w, &physical_h);

    const int offsetx1 = area->x1;
    const int offsetx2 = area->x2;
    const int offsety1 = area->y1;
    const int offsety2 = area->y2;

    uint8_t color_bytes = bridge_color_bytes(impl);

    rotate_copy_region(impl, color_map, impl->draw_fb,
                       offsetx1, offsety1, offsetx2, offsety2,
                       logical_w, logical_h, physical_w, physical_h,
                       bridge_rotation(impl), color_bytes);

    esp_err_t ret = display_bridge_v8_blit_full_frame(impl, impl->draw_fb, false);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "Blit failed: %s", esp_err_to_name(ret));
    } else {
        display_bridge_pipeline_mark_buf_busy(&impl->pipeline, impl->disp_fb);

        struct display_pipeline_buf *next = display_bridge_pipeline_wait_free_buf(&impl->pipeline);
        if (next) {
            impl->disp_fb = impl->draw_fb;
            impl->draw_fb = next->buffer;
        }
    }

    display_manager_flush_ready(drv);
}

/**
 * @brief Partial refresh with rotation
 */
static void display_bridge_v8_flush_partial_rotate(esp_lv_adapter_display_bridge_v8_t *impl,
                                                   lv_disp_drv_t *drv,
                                                   const lv_area_t *area,
                                                   uint8_t *color_map)
{
    size_t src_stride_px = area->x2 - area->x1 + 1;

    rotate_copy_strided_region(color_map,
                               impl->draw_fb,
                               area->x1, area->y1,
                               area->x2, area->y2,
                               src_stride_px,
                               impl);

    if (lv_disp_flush_is_last(drv)) {

        lv_disp_t *disp_refr = _lv_refr_get_disp_refreshing();
        lv_area_t current[DISPLAY_BRIDGE_V8_DIFF_RECT_CAPACITY];
        uint16_t current_count = 0;
        uint8_t target_index = UINT8_MAX;
        bool reset_tracker = false;

        if (!display_bridge_v8_prepare_partial_back_buffer(
                    impl, disp_refr, true, current, &current_count,
                    &target_index, &reset_tracker)) {
            display_manager_flush_ready(drv);
            return;
        }

#if CONFIG_SOC_PPA_SUPPORTED
        if (!hw_resource.ppa_handle) {
            display_cache_msync_framebuffer(impl->draw_fb, impl->runtime.frame_buffer_size);
        }
#else
        display_cache_msync_framebuffer(impl->draw_fb, impl->runtime.frame_buffer_size);
#endif
#if SOC_DMA2D_SUPPORTED || CONFIG_SOC_PPA_SUPPORTED
        display_cache_msync_invalidate_framebuffer(impl->draw_fb, impl->runtime.frame_buffer_size);
#endif

        esp_err_t ret = display_bridge_v8_blit_full_frame(impl, impl->draw_fb, true);
        if (ret != ESP_OK) {
            ESP_LOGE(TAG, "Blit failed: %s", esp_err_to_name(ret));
        } else {
            display_bridge_pipeline_mark_buf_busy(&impl->pipeline, impl->disp_fb);

            struct display_pipeline_buf *next = display_bridge_pipeline_wait_free_buf(&impl->pipeline);
            if (!next) {
                display_manager_flush_ready(drv);
                return;
            }
            impl->disp_fb = impl->draw_fb;
            impl->draw_fb = next->buffer;
            if (reset_tracker) {
                display_bridge_v8_diff_reset(impl);
            } else {
                display_bridge_v8_diff_commit(
                    impl, target_index, current, current_count);
            }
        }
#if CONFIG_ESP_LVGL_ADAPTER_PARTIAL_AUX_IMG_CACHE
        lv_img_cache_invalidate_src(NULL);
#endif
    }

    /* Notify LVGL that flush is complete */
    display_manager_flush_ready(drv);
}

/**********************
 *   ROTATION & COPY OPERATIONS
 **********************/

/**
 * @brief Rotate and copy region with stride support (uses PPA if available)
 */
static void IRAM_ATTR rotate_copy_strided_region(const void *src, void *dst_fb,
                                                 uint16_t lv_x_start, uint16_t lv_y_start,
                                                 uint16_t lv_x_end,   uint16_t lv_y_end,
                                                 uint16_t src_stride_px,
                                                 esp_lv_adapter_display_bridge_v8_t *impl)
{
    esp_lv_adapter_rotation_t rotation = bridge_rotation(impl);
    uint16_t hor_res = bridge_h_res(impl);
    uint16_t ver_res = bridge_v_res(impl);
    uint8_t color_bytes = bridge_color_bytes(impl);

#if CONFIG_SOC_PPA_SUPPORTED
    if (hw_resource.ppa_handle && (color_bytes == COLOR_BYTES_RGB565 || color_bytes == COLOR_BYTES_RGB888)) {
        const size_t rect_w = lv_x_end - lv_x_start + 1;
        const size_t rect_h = lv_y_end - lv_y_start + 1;

        int block_w_final    = rect_w;
        int block_h_final    = rect_h;
        int block_off_x_final = 0;
        int block_off_y_final = 0;

        ppa_srm_rotation_angle_t ppa_rotation;
        int x_offset = 0, y_offset = 0;

        switch (rotation) {
        case ESP_LV_ADAPTER_ROTATE_90:
            ppa_rotation = PPA_SRM_ROTATION_ANGLE_270;
            x_offset = hor_res - 1 - lv_y_end;
            y_offset = lv_x_start;
            break;
        case ESP_LV_ADAPTER_ROTATE_180:
            ppa_rotation = PPA_SRM_ROTATION_ANGLE_180;
            x_offset = hor_res - 1 - lv_x_end;
            y_offset = ver_res - 1 - lv_y_end;
            break;
        case ESP_LV_ADAPTER_ROTATE_270:
            ppa_rotation = PPA_SRM_ROTATION_ANGLE_90;
            x_offset = lv_y_start;
            y_offset = ver_res - 1 - lv_x_end;
            break;
        default:
            ppa_rotation = PPA_SRM_ROTATION_ANGLE_0;
            break;
        }

        size_t buffer_size = heap_caps_get_allocated_size(dst_fb);
        if (buffer_size == 0) {
            buffer_size = (size_t)color_bytes * hor_res * ver_res;
            size_t line_size = display_bridge_get_cache_line_size_by_addr(dst_fb);
            if (line_size > 0) {
                buffer_size = LVGL_PORT_PPA_ALIGN_UP(buffer_size, line_size);
            }
        }
        ppa_srm_oper_config_t oper_config = {
            .in.buffer          = src,
            .in.pic_w           = src_stride_px,
            .in.pic_h           = rect_h,
            .in.block_w         = block_w_final,
            .in.block_h         = block_h_final,
            .in.block_offset_x  = block_off_x_final,
            .in.block_offset_y  = block_off_y_final,
            .in.srm_cm          = display_bridge_v8_ppa_color_mode(color_bytes),

               .out.buffer         = dst_fb,
               .out.buffer_size    = buffer_size,
               .out.pic_w          = hor_res,
               .out.pic_h          = ver_res,
               .out.block_offset_x = x_offset,
               .out.block_offset_y = y_offset,
               .out.srm_cm         = display_bridge_v8_ppa_color_mode(color_bytes),

               .rotation_angle     = ppa_rotation,
               .scale_x            = PPA_SCALE_FACTOR_NO_SCALE,
               .scale_y            = PPA_SCALE_FACTOR_NO_SCALE,
               .rgb_swap           = PPA_SWAP_DISABLED,
               .byte_swap          = 0,
               .mode               = PPA_TRANS_MODE_BLOCKING,
        };
        ESP_ERROR_CHECK(ppa_do_scale_rotate_mirror(hw_resource.ppa_handle, &oper_config));
        return;
    }
#endif

    display_rotate_copy_region(src,
                               dst_fb,
                               lv_x_start,
                               lv_y_start,
                               lv_x_end,
                               lv_y_end,
                               src_stride_px,
                               hor_res,
                               ver_res,
                               rotation,
                               color_bytes,
                               impl->block_size_small,
                               impl->block_size_large);
}

/**
 * @brief Rotate and copy full region (uses PPA if available)
 */
static void IRAM_ATTR rotate_copy_region(esp_lv_adapter_display_bridge_v8_t *impl,
                                         const void *from, void *to,
                                         uint16_t x_start, uint16_t y_start,
                                         uint16_t x_end, uint16_t y_end,
                                         uint16_t src_logical_w, uint16_t src_logical_h,
                                         uint16_t dst_physical_w, uint16_t dst_physical_h,
                                         esp_lv_adapter_rotation_t rotation,
                                         uint8_t color_bytes)
{
#if CONFIG_SOC_PPA_SUPPORTED
    if (hw_resource.ppa_handle && (color_bytes == COLOR_BYTES_RGB565 || color_bytes == COLOR_BYTES_RGB888)) {
        ppa_srm_rotation_angle_t ppa_rotation;
        int x_offset = 0, y_offset = 0;
        const uint16_t rect_w = x_end - x_start + 1;
        const uint16_t rect_h = y_end - y_start + 1;

        switch (rotation) {
        case ESP_LV_ADAPTER_ROTATE_90:
            ppa_rotation = PPA_SRM_ROTATION_ANGLE_270;
            x_offset = dst_physical_w - y_end - 1;
            y_offset = x_start;
            break;
        case ESP_LV_ADAPTER_ROTATE_180:
            ppa_rotation = PPA_SRM_ROTATION_ANGLE_180;
            x_offset = dst_physical_w - x_end - 1;
            y_offset = dst_physical_h - y_end - 1;
            break;
        case ESP_LV_ADAPTER_ROTATE_270:
            ppa_rotation = PPA_SRM_ROTATION_ANGLE_90;
            x_offset = y_start;
            y_offset = dst_physical_h - x_end - 1;
            break;
        default:
            ppa_rotation = PPA_SRM_ROTATION_ANGLE_0;
            x_offset = x_start;
            y_offset = y_start;
            break;
        }

        size_t buffer_size = heap_caps_get_allocated_size(to);
        if (buffer_size == 0) {
            buffer_size = (size_t)color_bytes * dst_physical_w * dst_physical_h;
            size_t line_size = display_bridge_get_cache_line_size_by_addr(to);
            if (line_size > 0) {
                buffer_size = LVGL_PORT_PPA_ALIGN_UP(buffer_size, line_size);
            }
        }
        ppa_srm_oper_config_t oper_config = {
            .in.buffer = from,
            .in.pic_w = src_logical_w,
            .in.pic_h = src_logical_h,
            .in.block_w = rect_w,
            .in.block_h = rect_h,
            .in.block_offset_x = x_start,
            .in.block_offset_y = y_start,
            .in.srm_cm = display_bridge_v8_ppa_color_mode(color_bytes),

               .out.buffer = to,
               .out.buffer_size = buffer_size,
               .out.pic_w = dst_physical_w,
               .out.pic_h = dst_physical_h,
               .out.block_offset_x = x_offset,
               .out.block_offset_y = y_offset,
               .out.srm_cm = display_bridge_v8_ppa_color_mode(color_bytes),

               .rotation_angle = ppa_rotation,
               .scale_x = 1.0,
               .scale_y = 1.0,
               .rgb_swap = 0,
               .byte_swap = 0,
               .mode = PPA_TRANS_MODE_BLOCKING,
        };
        ESP_ERROR_CHECK(ppa_do_scale_rotate_mirror(hw_resource.ppa_handle, &oper_config));
        return;
    }
#endif

    display_rotate_copy_region(from,
                               to,
                               x_start,
                               y_start,
                               x_end,
                               y_end,
                               src_logical_w,
                               dst_physical_w,
                               dst_physical_h,
                               rotation,
                               color_bytes,
                               impl->block_size_small,
                               impl->block_size_large);
}

/**********************
 *   HELPER FUNCTIONS
 **********************/

static void copy_diff_repair_from_front_to_back(
    esp_lv_adapter_display_bridge_v8_t *impl,
    const lv_area_t *repair,
    uint16_t repair_count)
{
    const uint16_t hor_res = bridge_h_res(impl);
    const uint8_t color_bytes = bridge_color_bytes(impl);

#if SOC_DMA2D_SUPPORTED
    const uint16_t ver_res = bridge_v_res(impl);
    if (repair_count != 0) {
        display_cache_msync_framebuffer(impl->disp_fb,
                                        impl->runtime.frame_buffer_size);
    }
#endif

    for (uint16_t index = 0; index < repair_count; ++index) {
        lv_area_t rect = repair[index];
        size_t copy_w_px = (size_t)(rect.x2 - rect.x1 + 1);
        size_t copy_h_px = (size_t)(rect.y2 - rect.y1 + 1);

#if SOC_DMA2D_SUPPORTED
        if (display_bridge_dma2d_window_is_compatible(
                    impl->disp_fb, hor_res, rect.x1, copy_w_px, color_bytes) &&
                display_bridge_dma2d_window_is_compatible(
                    impl->draw_fb, hor_res, rect.x1, copy_w_px,
                    color_bytes)) {
#ifdef ESP_ASYNC_COLOR_CONVERT_AVAILABLE
            async_color_convert_request_t transfer = {
                .src_buffer = impl->disp_fb,
                .dst_buffer = impl->draw_fb,
                .src_stride = hor_res,
                .src_height = ver_res,
                .dst_stride = hor_res,
                .dst_height = ver_res,
                .src_x = rect.x1,
                .src_y = rect.y1,
                .dst_x = rect.x1,
                .dst_y = rect.y1,
                .copy_width = copy_w_px,
                .copy_height = copy_h_px,
                DMA2D_PIXEL_FORMAT_FIELD(color_bytes),
            };
#else
            esp_async_fbcpy_trans_desc_t transfer = {
                .src_buffer = impl->disp_fb,
                .dst_buffer = impl->draw_fb,
                .src_buffer_size_x = hor_res,
                .src_buffer_size_y = ver_res,
                .src_offset_x = rect.x1,
                .src_offset_y = rect.y1,
                .dst_buffer_size_x = hor_res,
                .dst_buffer_size_y = ver_res,
                .dst_offset_x = rect.x1,
                .dst_offset_y = rect.y1,
                .copy_size_x = copy_w_px,
                .copy_size_y = copy_h_px,
                DMA2D_PIXEL_FORMAT_FIELD(color_bytes),
            };
#endif
            ESP_ERROR_CHECK(display_bridge_dma2d_copy_sync(
                                &transfer, portMAX_DELAY));
            continue;
        }
#endif

        size_t copy_bytes = copy_w_px * color_bytes;
        uint8_t *src = (uint8_t *)impl->disp_fb +
                       ((size_t)rect.y1 * hor_res + rect.x1) * color_bytes;
        uint8_t *dst = (uint8_t *)impl->draw_fb +
                       ((size_t)rect.y1 * hor_res + rect.x1) * color_bytes;
        for (size_t row = 0; row < copy_h_px; ++row) {
            memcpy(dst, src, copy_bytes);
            src += (size_t)hor_res * color_bytes;
            dst += (size_t)hor_res * color_bytes;
        }
    }
}

static bool display_bridge_v8_prepare_partial_back_buffer(
    esp_lv_adapter_display_bridge_v8_t *impl,
    lv_disp_t *disp_refr,
    bool dirty_to_physical,
    lv_area_t *current,
    uint16_t *current_count,
    uint8_t *target_index,
    bool *reset_tracker)
{
    lv_area_t repair[DISPLAY_BRIDGE_V8_REPAIR_CAPACITY];
    uint16_t repair_count = 0;
    uint16_t pending_count = 0;
    uint8_t source_index = UINT8_MAX;
    bool copy_baseline = true;

    *current_count = 0;
    *target_index = UINT8_MAX;
    *reset_tracker = false;

    bool current_valid = disp_refr != NULL &&
                         display_bridge_v8_diff_capture_current(
                             impl, disp_refr, current, current_count, dirty_to_physical);
    *target_index =
        display_bridge_v8_diff_buffer_index(impl, impl->draw_fb);
    source_index =
        display_bridge_v8_diff_buffer_index(impl, impl->disp_fb);
    *reset_tracker = !current_valid || *target_index == UINT8_MAX ||
                     source_index == UINT8_MAX;

    if (!*reset_tracker) {
        display_bridge_v8_diff_buffer_t *target =
            &impl->diff_tracker.buffers[*target_index];
        pending_count = target->pending_count;
        if (target->valid && display_bridge_v8_diff_subtract(
                    target->pending, target->pending_count,
                    current, *current_count, repair, &repair_count)) {
            display_bridge_v8_diff_buffer_t *source =
                &impl->diff_tracker.buffers[source_index];
            if (repair_count == 0 ||
                    (source->valid &&
                     source->revision == impl->diff_tracker.revision)) {
                copy_baseline = false;
            } else {
                *reset_tracker = true;
            }
        }
    }

    ESP_LOGD(TAG,
             "partial diff: rotated=%u target=%u source=%u baseline=%u"
             " pending=%u current=%u repair=%u revision=%" PRIu32,
             (unsigned)dirty_to_physical, (unsigned)*target_index,
             (unsigned)source_index, (unsigned)copy_baseline,
             (unsigned)pending_count, (unsigned)*current_count,
             (unsigned)repair_count, impl->diff_tracker.revision);
    for (uint16_t index = 0; index < repair_count && !copy_baseline; ++index) {
        ESP_LOGV(TAG,
                 "  repair[%u]: (%" PRId32 ",%" PRId32
                 ")-(%" PRId32 ",%" PRId32 ") size=%" PRId32
                 "x%" PRId32,
                 (unsigned)index,
                 (int32_t)repair[index].x1,
                 (int32_t)repair[index].y1,
                 (int32_t)repair[index].x2,
                 (int32_t)repair[index].y2,
                 (int32_t)(repair[index].x2 - repair[index].x1 + 1),
                 (int32_t)(repair[index].y2 - repair[index].y1 + 1));
    }

    if (copy_baseline) {
        if (disp_refr == NULL) {
            ESP_LOGE(TAG, "No refreshing display for partial baseline");
            return false;
        }
        copy_unrendered_area_from_front_to_back(disp_refr, impl);
    } else {
        copy_diff_repair_from_front_to_back(impl, repair, repair_count);
    }

    return true;
}

/**
 * @brief Copy unrendered areas from front buffer to back buffer
 */
static void copy_unrendered_area_from_front_to_back(lv_disp_t *disp_refr, esp_lv_adapter_display_bridge_v8_t *impl)
{
    uint16_t hor_res = bridge_h_res(impl);
    uint16_t ver_res = bridge_v_res(impl);
    uint8_t color_bytes = bridge_color_bytes(impl);
    esp_lv_adapter_rotation_t rotation = bridge_rotation(impl);

    if (rotation != ESP_LV_ADAPTER_ROTATE_0) {
        for (int i = 0; i < disp_refr->inv_p; i++) {
            lv_area_t *a = &disp_refr->inv_areas[i];
            int x1, y1, x2, y2;
            display_coord_to_phy(a->x1, a->y1, &x1, &y1, rotation, hor_res, ver_res);
            display_coord_to_phy(a->x2, a->y2, &x2, &y2, rotation, hor_res, ver_res);
            a->x1 = LV_MIN(x1, x2);
            a->x2 = LV_MAX(x1, x2);
            a->y1 = LV_MIN(y1, y2);
            a->y2 = LV_MAX(y1, y2);
        }
    }

    typedef struct {
        int x1, y1, x2, y2;
    } rect_t;

    /* Step-1: Build "unsynced" list = FullScreen – Union(dirty) */
    rect_t unsync_rects[LV_INV_BUF_SIZE * 4 + 4];
    int    unsync_cnt = 1;
    unsync_rects[0] = (rect_t) {
        0, 0, hor_res - 1, ver_res - 1
    };

    for (int i = 0; i < disp_refr->inv_p; i++) {
        if (disp_refr->inv_area_joined[i]) {
            continue; /* skip already-joined areas */
        }

        rect_t d = {
            .x1 = disp_refr->inv_areas[i].x1,
            .y1 = disp_refr->inv_areas[i].y1,
            .x2 = disp_refr->inv_areas[i].x2,
            .y2 = disp_refr->inv_areas[i].y2,
        };

        int j = 0;
        while (j < unsync_cnt) {
            rect_t r = unsync_rects[j];

            /* no intersection => keep going */
            bool overlap = !(d.x2 < r.x1 || d.x1 > r.x2 || d.y2 < r.y1 || d.y1 > r.y2);
            if (!overlap) {
                j++;
                continue;
            }

            /* remove r from list */
            for (int k = j; k < unsync_cnt - 1; k++) {
                unsync_rects[k] = unsync_rects[k + 1];
            }
            unsync_cnt--;

            /* split r − d (up to four rectangles) and push back */
            if (d.y1 > r.y1) { /* top slice */
                unsync_rects[unsync_cnt++] = (rect_t) {
                    r.x1, r.y1, r.x2, d.y1 - 1
                };
            }
            if (d.y2 < r.y2) { /* bottom slice */
                unsync_rects[unsync_cnt++] = (rect_t) {
                    r.x1, d.y2 + 1, r.x2, r.y2
                };
            }

            int overlap_y1 = LV_MAX(r.y1, d.y1);
            int overlap_y2 = LV_MIN(r.y2, d.y2);

            if (d.x1 > r.x1) { /* left slice */
                unsync_rects[unsync_cnt++] = (rect_t) {
                    r.x1, overlap_y1, d.x1 - 1, overlap_y2
                };
            }
            if (d.x2 < r.x2) { /* right slice */
                unsync_rects[unsync_cnt++] = (rect_t) {
                    d.x2 + 1, overlap_y1, r.x2, overlap_y2
                };
            }
        }
    }

    if (unsync_cnt == 0) {
        return; /* whole screen was rendered this frame */
    }

    /* Step-2: Merge rectangles which share one axis span to reduce copy */
    bool merged;
    do {
        merged = false;
        for (int i = 0; i < unsync_cnt; i++) {
            for (int j = i + 1; j < unsync_cnt; j++) {
                rect_t *a = &unsync_rects[i];
                rect_t *b = &unsync_rects[j];

                /* Horizontal merge: identical vertical span, x ranges touch/overlap */
                if (a->y1 == b->y1 && a->y2 == b->y2 &&
                        b->x1 <= a->x2 + 1 && b->x2 >= a->x1 - 1) {
                    a->x1 = LV_MIN(a->x1, b->x1);
                    a->x2 = LV_MAX(a->x2, b->x2);

                    for (int k = j; k < unsync_cnt - 1; k++) {
                        unsync_rects[k] = unsync_rects[k + 1];
                    }
                    unsync_cnt--;
                    merged = true;
                    goto MERGE_RESTART; /* restart outer loops */
                }

                /* Vertical merge: identical horizontal span, y ranges touch/overlap */
                if (a->x1 == b->x1 && a->x2 == b->x2 &&
                        b->y1 <= a->y2 + 1 && b->y2 >= a->y1 - 1) {
                    a->y1 = LV_MIN(a->y1, b->y1);
                    a->y2 = LV_MAX(a->y2, b->y2);

                    for (int k = j; k < unsync_cnt - 1; k++) {
                        unsync_rects[k] = unsync_rects[k + 1];
                    }
                    unsync_cnt--;
                    merged = true;
                    goto MERGE_RESTART;
                }
            }
        }
MERGE_RESTART:;
    } while (merged);

    /* Step-3: Copy using DMA2D when available, fallback to CPU memcpy */
#if SOC_DMA2D_SUPPORTED

    if (unsync_cnt > 0) {
        display_cache_msync_framebuffer(impl->disp_fb, impl->runtime.frame_buffer_size);
    }

    for (int idx = 0; idx < unsync_cnt; idx++) {
        rect_t r = unsync_rects[idx];
        size_t copy_w_px = r.x2 - r.x1 + 1;
        size_t copy_h_px = r.y2 - r.y1 + 1;

        int offset_x = r.x1;
        if (display_bridge_dma2d_window_is_compatible(impl->disp_fb, hor_res, offset_x, copy_w_px, color_bytes) &&
                display_bridge_dma2d_window_is_compatible(impl->draw_fb, hor_res, offset_x, copy_w_px, color_bytes)) {
#ifdef ESP_ASYNC_COLOR_CONVERT_AVAILABLE
            async_color_convert_request_t tr = {
                .src_buffer  = impl->disp_fb,
                .dst_buffer  = impl->draw_fb,
                .src_stride  = hor_res,
                .src_height  = ver_res,
                .dst_stride  = hor_res,
                .dst_height  = ver_res,
                .src_x       = offset_x,
                .src_y       = r.y1,
                .dst_x       = offset_x,
                .dst_y       = r.y1,
                .copy_width  = copy_w_px,
                .copy_height = copy_h_px,
                DMA2D_PIXEL_FORMAT_FIELD(color_bytes),
            };
#else
            esp_async_fbcpy_trans_desc_t tr = {
                .src_buffer        = impl->disp_fb,
                .dst_buffer        = impl->draw_fb,
                .src_buffer_size_x = hor_res,
                .src_buffer_size_y = ver_res,
                .dst_buffer_size_x = hor_res,
                .dst_buffer_size_y = ver_res,
                .src_offset_x      = offset_x,
                .src_offset_y      = r.y1,
                .dst_offset_x      = offset_x,
                .dst_offset_y      = r.y1,
                .copy_size_x       = copy_w_px,
                .copy_size_y       = copy_h_px,
                DMA2D_PIXEL_FORMAT_FIELD(color_bytes),
            };
#endif

            /* submit and wait */
            ESP_ERROR_CHECK(display_bridge_dma2d_copy_sync(&tr, portMAX_DELAY));
        } else {
            const int bytes_per_pixel = color_bytes;
            int bytes_per_line  = copy_w_px * bytes_per_pixel;
            uint8_t *src_line = (uint8_t *)impl->disp_fb + (r.y1 * hor_res + r.x1) * bytes_per_pixel;
            uint8_t *dst_line = (uint8_t *)impl->draw_fb  + (r.y1 * hor_res + r.x1) * bytes_per_pixel;

            for (int y = r.y1; y <= r.y2; y++) {
                memcpy(dst_line, src_line, bytes_per_line);
                src_line += hor_res * bytes_per_pixel;
                dst_line += hor_res * bytes_per_pixel;
            }
        }
    }
#else /* !SOC_DMA2D_SUPPORTED */

    const int bytes_per_pixel = color_bytes;
    for (int idx = 0; idx < unsync_cnt; idx++) {
        rect_t r = unsync_rects[idx];
        int width_px        = r.x2 - r.x1 + 1;
        int bytes_per_line  = width_px * bytes_per_pixel;
        uint8_t *src_line = (uint8_t *)impl->disp_fb + (r.y1 * hor_res + r.x1) * bytes_per_pixel;
        uint8_t *dst_line = (uint8_t *)impl->draw_fb  + (r.y1 * hor_res + r.x1) * bytes_per_pixel;

        for (int y = r.y1; y <= r.y2; y++) {
            memcpy(dst_line, src_line, bytes_per_line);
            src_line += hor_res * bytes_per_pixel;
            dst_line += hor_res * bytes_per_pixel;
        }
    }

#endif /* !SOC_DMA2D_SUPPORTED */
}

/**
 * @brief Save current dirty region for later use
 */
static void flush_dirty_save(esp_lv_adapter_display_dirty_region_t *dirty_area)
{
    lv_disp_t *disp = _lv_refr_get_disp_refreshing();
    if (!disp) {
        display_dirty_region_reset(dirty_area);
        return;
    }

    display_dirty_region_capture(dirty_area,
                                 disp->inv_areas,
                                 disp->inv_area_joined,
                                 disp->inv_p);
}

/**
 * @brief Copy dirty region with rotation
 */
static void flush_dirty_copy(esp_lv_adapter_display_bridge_v8_t *impl,
                             void *dst,
                             void *src,
                             esp_lv_adapter_display_dirty_region_t *dirty_area)
{
    esp_lv_adapter_rotation_t rotation = bridge_rotation(impl);
    uint8_t color_bytes = bridge_color_bytes(impl);
    uint16_t logical_w = 0;
    uint16_t logical_h = 0;
    uint16_t physical_w = 0;
    uint16_t physical_h = 0;
    display_bridge_v8_get_rotation_geometry(impl, &logical_w, &logical_h, &physical_w, &physical_h);

    for (int i = 0; i < dirty_area->inv_p; i++) {
        if (dirty_area->inv_area_joined[i] == 0) {
            lv_coord_t x_start = dirty_area->inv_areas[i].x1;
            lv_coord_t x_end   = dirty_area->inv_areas[i].x2;
            lv_coord_t y_start = dirty_area->inv_areas[i].y1;
            lv_coord_t y_end   = dirty_area->inv_areas[i].y2;

            rotate_copy_region(impl, src, dst,
                               x_start, y_start, x_end, y_end,
                               logical_w, logical_h, physical_w, physical_h,
                               rotation, color_bytes);
        }
    }
}

#endif /* LVGL_VERSION_MAJOR < 9 */
