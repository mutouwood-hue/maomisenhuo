(() => {
  // node_modules/.pnpm/@capacitor+core@8.5.3/node_modules/@capacitor/core/dist/index.js
  var ExceptionCode;
  (function(ExceptionCode2) {
    ExceptionCode2["Unimplemented"] = "UNIMPLEMENTED";
    ExceptionCode2["Unavailable"] = "UNAVAILABLE";
  })(ExceptionCode || (ExceptionCode = {}));
  var CapacitorException = class extends Error {
    constructor(message, code, data) {
      super(message);
      this.message = message;
      this.code = code;
      this.data = data;
    }
  };
  var getPlatformId = (win) => {
    var _a, _b;
    if (win === null || win === void 0 ? void 0 : win.androidBridge) {
      return "android";
    } else if ((_b = (_a = win === null || win === void 0 ? void 0 : win.webkit) === null || _a === void 0 ? void 0 : _a.messageHandlers) === null || _b === void 0 ? void 0 : _b.bridge) {
      return "ios";
    } else {
      return "web";
    }
  };
  var createCapacitor = (win) => {
    const capCustomPlatform = win.CapacitorCustomPlatform || null;
    const cap = win.Capacitor || {};
    const Plugins = cap.Plugins = cap.Plugins || {};
    const getPlatform = () => {
      return capCustomPlatform !== null ? capCustomPlatform.name : getPlatformId(win);
    };
    const isNativePlatform = () => getPlatform() !== "web";
    const isPluginAvailable = (pluginName) => {
      const plugin2 = registeredPlugins.get(pluginName);
      if (plugin2 === null || plugin2 === void 0 ? void 0 : plugin2.platforms.has(getPlatform())) {
        return true;
      }
      if (getPluginHeader(pluginName)) {
        return true;
      }
      return false;
    };
    const getPluginHeader = (pluginName) => {
      var _a;
      return (_a = cap.PluginHeaders) === null || _a === void 0 ? void 0 : _a.find((h) => h.name === pluginName);
    };
    const handleError = (err) => win.console.error(err);
    const registeredPlugins = /* @__PURE__ */ new Map();
    const registerPlugin2 = (pluginName, jsImplementations = {}) => {
      const registeredPlugin = registeredPlugins.get(pluginName);
      if (registeredPlugin) {
        console.warn(`Capacitor plugin "${pluginName}" already registered. Cannot register plugins twice.`);
        return registeredPlugin.proxy;
      }
      const platform = getPlatform();
      const pluginHeader = getPluginHeader(pluginName);
      let jsImplementation;
      const loadPluginImplementation = async () => {
        if (!jsImplementation && platform in jsImplementations) {
          jsImplementation = typeof jsImplementations[platform] === "function" ? jsImplementation = await jsImplementations[platform]() : jsImplementation = jsImplementations[platform];
        } else if (capCustomPlatform !== null && !jsImplementation && "web" in jsImplementations) {
          jsImplementation = typeof jsImplementations["web"] === "function" ? jsImplementation = await jsImplementations["web"]() : jsImplementation = jsImplementations["web"];
        }
        return jsImplementation;
      };
      const createPluginMethod = (impl, prop) => {
        var _a, _b;
        if (pluginHeader) {
          const methodHeader = pluginHeader === null || pluginHeader === void 0 ? void 0 : pluginHeader.methods.find((m) => prop === m.name);
          if (methodHeader) {
            if (methodHeader.rtype === "promise") {
              return (options) => cap.nativePromise(pluginName, prop.toString(), options);
            } else {
              return (options, callback) => cap.nativeCallback(pluginName, prop.toString(), options, callback);
            }
          } else if (impl) {
            return (_a = impl[prop]) === null || _a === void 0 ? void 0 : _a.bind(impl);
          }
        } else if (impl) {
          return (_b = impl[prop]) === null || _b === void 0 ? void 0 : _b.bind(impl);
        } else {
          throw new CapacitorException(`"${pluginName}" plugin is not implemented on ${platform}`, ExceptionCode.Unimplemented);
        }
      };
      const createPluginMethodWrapper = (prop) => {
        let remove;
        const wrapper = (...args) => {
          const p = loadPluginImplementation().then((impl) => {
            const fn = createPluginMethod(impl, prop);
            if (fn) {
              const p2 = fn(...args);
              remove = p2 === null || p2 === void 0 ? void 0 : p2.remove;
              return p2;
            } else {
              throw new CapacitorException(`"${pluginName}.${prop}()" is not implemented on ${platform}`, ExceptionCode.Unimplemented);
            }
          });
          if (prop === "addListener") {
            p.remove = async () => remove();
          }
          return p;
        };
        wrapper.toString = () => `${prop.toString()}() { [capacitor code] }`;
        Object.defineProperty(wrapper, "name", {
          value: prop,
          writable: false,
          configurable: false
        });
        return wrapper;
      };
      const addListener = createPluginMethodWrapper("addListener");
      const removeListener = createPluginMethodWrapper("removeListener");
      const addListenerNative = (eventName, callback) => {
        const call = addListener({ eventName }, callback);
        const remove = async () => {
          const callbackId = await call;
          removeListener({
            eventName,
            callbackId
          }, callback);
        };
        const p = new Promise((resolve) => call.then(() => resolve({ remove })));
        p.remove = async () => {
          console.warn(`Using addListener() without 'await' is deprecated.`);
          await remove();
        };
        return p;
      };
      const proxy = new Proxy({}, {
        get(_, prop) {
          switch (prop) {
            // https://github.com/facebook/react/issues/20030
            case "$$typeof":
              return void 0;
            case "toJSON":
              return () => ({});
            case "addListener":
              return pluginHeader ? addListenerNative : addListener;
            case "removeListener":
              return removeListener;
            default:
              return createPluginMethodWrapper(prop);
          }
        }
      });
      Plugins[pluginName] = proxy;
      registeredPlugins.set(pluginName, {
        name: pluginName,
        proxy,
        platforms: /* @__PURE__ */ new Set([...Object.keys(jsImplementations), ...pluginHeader ? [platform] : []])
      });
      return proxy;
    };
    if (!cap.convertFileSrc) {
      cap.convertFileSrc = (filePath) => filePath;
    }
    cap.getPlatform = getPlatform;
    cap.handleError = handleError;
    cap.isNativePlatform = isNativePlatform;
    cap.isPluginAvailable = isPluginAvailable;
    cap.registerPlugin = registerPlugin2;
    cap.Exception = CapacitorException;
    cap.DEBUG = !!cap.DEBUG;
    cap.isLoggingEnabled = !!cap.isLoggingEnabled;
    return cap;
  };
  var initCapacitorGlobal = (win) => win.Capacitor = createCapacitor(win);
  var Capacitor = /* @__PURE__ */ initCapacitorGlobal(typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : typeof global !== "undefined" ? global : {});
  var registerPlugin = Capacitor.registerPlugin;
  var WebPlugin = class {
    constructor() {
      this.listeners = {};
      this.retainedEventArguments = {};
      this.windowListeners = {};
    }
    addListener(eventName, listenerFunc) {
      let firstListener = false;
      const listeners = this.listeners[eventName];
      if (!listeners) {
        this.listeners[eventName] = [];
        firstListener = true;
      }
      this.listeners[eventName].push(listenerFunc);
      const windowListener = this.windowListeners[eventName];
      if (windowListener && !windowListener.registered) {
        this.addWindowListener(windowListener);
      }
      if (firstListener) {
        this.sendRetainedArgumentsForEvent(eventName);
      }
      const remove = async () => this.removeListener(eventName, listenerFunc);
      const p = Promise.resolve({ remove });
      return p;
    }
    async removeAllListeners() {
      this.listeners = {};
      for (const listener in this.windowListeners) {
        this.removeWindowListener(this.windowListeners[listener]);
      }
      this.windowListeners = {};
    }
    notifyListeners(eventName, data, retainUntilConsumed) {
      const listeners = this.listeners[eventName];
      if (!listeners) {
        if (retainUntilConsumed) {
          let args = this.retainedEventArguments[eventName];
          if (!args) {
            args = [];
          }
          args.push(data);
          this.retainedEventArguments[eventName] = args;
        }
        return;
      }
      listeners.forEach((listener) => listener(data));
    }
    hasListeners(eventName) {
      var _a;
      return !!((_a = this.listeners[eventName]) === null || _a === void 0 ? void 0 : _a.length);
    }
    registerWindowListener(windowEventName, pluginEventName) {
      this.windowListeners[pluginEventName] = {
        registered: false,
        windowEventName,
        pluginEventName,
        handler: (event) => {
          this.notifyListeners(pluginEventName, event);
        }
      };
    }
    unimplemented(msg = "not implemented") {
      return new Capacitor.Exception(msg, ExceptionCode.Unimplemented);
    }
    unavailable(msg = "not available") {
      return new Capacitor.Exception(msg, ExceptionCode.Unavailable);
    }
    async removeListener(eventName, listenerFunc) {
      const listeners = this.listeners[eventName];
      if (!listeners) {
        return;
      }
      const index = listeners.indexOf(listenerFunc);
      if (index !== -1) {
        this.listeners[eventName].splice(index, 1);
      }
      if (!this.listeners[eventName].length) {
        this.removeWindowListener(this.windowListeners[eventName]);
      }
    }
    addWindowListener(handle) {
      window.addEventListener(handle.windowEventName, handle.handler);
      handle.registered = true;
    }
    removeWindowListener(handle) {
      if (!handle) {
        return;
      }
      window.removeEventListener(handle.windowEventName, handle.handler);
      handle.registered = false;
    }
    sendRetainedArgumentsForEvent(eventName) {
      const args = this.retainedEventArguments[eventName];
      if (!args) {
        return;
      }
      delete this.retainedEventArguments[eventName];
      args.forEach((arg) => {
        this.notifyListeners(eventName, arg);
      });
    }
  };
  var encode = (str) => encodeURIComponent(str).replace(/%(2[346B]|5E|60|7C)/g, decodeURIComponent).replace(/[()]/g, escape);
  var decode = (str) => str.replace(/(%[\dA-F]{2})+/gi, decodeURIComponent);
  var CapacitorCookiesPluginWeb = class extends WebPlugin {
    async getCookies() {
      const cookies = document.cookie;
      const cookieMap = {};
      cookies.split(";").forEach((cookie) => {
        if (cookie.length <= 0)
          return;
        let [key, value] = cookie.replace(/=/, "CAP_COOKIE").split("CAP_COOKIE");
        key = decode(key).trim();
        value = decode(value).trim();
        cookieMap[key] = value;
      });
      return cookieMap;
    }
    async setCookie(options) {
      try {
        const encodedKey = encode(options.key);
        const encodedValue = encode(options.value);
        const expires = options.expires ? `; expires=${options.expires.replace("expires=", "")}` : "";
        const path = (options.path || "/").replace("path=", "");
        const domain = options.url != null && options.url.length > 0 ? `domain=${options.url}` : "";
        document.cookie = `${encodedKey}=${encodedValue || ""}${expires}; path=${path}; ${domain};`;
      } catch (error) {
        return Promise.reject(error);
      }
    }
    async deleteCookie(options) {
      try {
        document.cookie = `${options.key}=; Max-Age=0`;
      } catch (error) {
        return Promise.reject(error);
      }
    }
    async clearCookies() {
      try {
        const cookies = document.cookie.split(";") || [];
        for (const cookie of cookies) {
          document.cookie = cookie.replace(/^ +/, "").replace(/=.*/, `=;expires=${(/* @__PURE__ */ new Date()).toUTCString()};path=/`);
        }
      } catch (error) {
        return Promise.reject(error);
      }
    }
    async clearAllCookies() {
      try {
        await this.clearCookies();
      } catch (error) {
        return Promise.reject(error);
      }
    }
  };
  var CapacitorCookies = registerPlugin("CapacitorCookies", {
    web: () => new CapacitorCookiesPluginWeb()
  });
  var readBlobAsBase64 = async (blob) => new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const base64String = reader.result;
      resolve(base64String.indexOf(",") >= 0 ? base64String.split(",")[1] : base64String);
    };
    reader.onerror = (error) => reject(error);
    reader.readAsDataURL(blob);
  });
  var normalizeHttpHeaders = (headers = {}) => {
    const originalKeys = Object.keys(headers);
    const loweredKeys = Object.keys(headers).map((k) => k.toLocaleLowerCase());
    const normalized = loweredKeys.reduce((acc, key, index) => {
      acc[key] = headers[originalKeys[index]];
      return acc;
    }, {});
    return normalized;
  };
  var buildUrlParams = (params, shouldEncode = true) => {
    if (!params)
      return null;
    const output = Object.entries(params).reduce((accumulator, entry) => {
      const [key, value] = entry;
      let encodedValue;
      let item;
      if (Array.isArray(value)) {
        item = "";
        value.forEach((str) => {
          encodedValue = shouldEncode ? encodeURIComponent(str) : str;
          item += `${key}=${encodedValue}&`;
        });
        item.slice(0, -1);
      } else {
        encodedValue = shouldEncode ? encodeURIComponent(value) : value;
        item = `${key}=${encodedValue}`;
      }
      return `${accumulator}&${item}`;
    }, "");
    return output.substr(1);
  };
  var buildRequestInit = (options, extra = {}) => {
    const output = Object.assign({ method: options.method || "GET", headers: options.headers }, extra);
    const headers = normalizeHttpHeaders(options.headers);
    const type = headers["content-type"] || "";
    if (typeof options.data === "string") {
      output.body = options.data;
    } else if (type.includes("application/x-www-form-urlencoded")) {
      const params = new URLSearchParams();
      for (const [key, value] of Object.entries(options.data || {})) {
        params.set(key, value);
      }
      output.body = params.toString();
    } else if (type.includes("multipart/form-data") || options.data instanceof FormData) {
      const form = new FormData();
      if (options.data instanceof FormData) {
        options.data.forEach((value, key) => {
          form.append(key, value);
        });
      } else {
        for (const key of Object.keys(options.data)) {
          form.append(key, options.data[key]);
        }
      }
      output.body = form;
      const headers2 = new Headers(output.headers);
      headers2.delete("content-type");
      output.headers = headers2;
    } else if (type.includes("application/json") || typeof options.data === "object") {
      output.body = JSON.stringify(options.data);
    }
    return output;
  };
  var CapacitorHttpPluginWeb = class extends WebPlugin {
    /**
     * Perform an Http request given a set of options
     * @param options Options to build the HTTP request
     */
    async request(options) {
      const requestInit = buildRequestInit(options, options.webFetchExtra);
      const urlParams = buildUrlParams(options.params, options.shouldEncodeUrlParams);
      const url = urlParams ? `${options.url}?${urlParams}` : options.url;
      const response = await fetch(url, requestInit);
      const contentType = response.headers.get("content-type") || "";
      let { responseType = "text" } = response.ok ? options : {};
      if (contentType.includes("application/json")) {
        responseType = "json";
      }
      let data;
      let blob;
      switch (responseType) {
        case "arraybuffer":
        case "blob":
          blob = await response.blob();
          data = await readBlobAsBase64(blob);
          break;
        case "json":
          data = await response.json();
          break;
        case "document":
        case "text":
        default:
          data = await response.text();
      }
      const headers = {};
      response.headers.forEach((value, key) => {
        headers[key] = value;
      });
      return {
        data,
        headers,
        status: response.status,
        url: response.url
      };
    }
    /**
     * Perform an Http GET request given a set of options
     * @param options Options to build the HTTP request
     */
    async get(options) {
      return this.request(Object.assign(Object.assign({}, options), { method: "GET" }));
    }
    /**
     * Perform an Http POST request given a set of options
     * @param options Options to build the HTTP request
     */
    async post(options) {
      return this.request(Object.assign(Object.assign({}, options), { method: "POST" }));
    }
    /**
     * Perform an Http PUT request given a set of options
     * @param options Options to build the HTTP request
     */
    async put(options) {
      return this.request(Object.assign(Object.assign({}, options), { method: "PUT" }));
    }
    /**
     * Perform an Http PATCH request given a set of options
     * @param options Options to build the HTTP request
     */
    async patch(options) {
      return this.request(Object.assign(Object.assign({}, options), { method: "PATCH" }));
    }
    /**
     * Perform an Http DELETE request given a set of options
     * @param options Options to build the HTTP request
     */
    async delete(options) {
      return this.request(Object.assign(Object.assign({}, options), { method: "DELETE" }));
    }
  };
  var CapacitorHttp = registerPlugin("CapacitorHttp", {
    web: () => new CapacitorHttpPluginWeb()
  });
  var SystemBarsStyle;
  (function(SystemBarsStyle2) {
    SystemBarsStyle2["Dark"] = "DARK";
    SystemBarsStyle2["Light"] = "LIGHT";
    SystemBarsStyle2["Default"] = "DEFAULT";
  })(SystemBarsStyle || (SystemBarsStyle = {}));
  var SystemBarType;
  (function(SystemBarType2) {
    SystemBarType2["StatusBar"] = "StatusBar";
    SystemBarType2["NavigationBar"] = "NavigationBar";
  })(SystemBarType || (SystemBarType = {}));
  var SystemBarsPluginWeb = class extends WebPlugin {
    async setStyle() {
      this.unavailable("not available for web");
    }
    async setAnimation() {
      this.unavailable("not available for web");
    }
    async show() {
      this.unavailable("not available for web");
    }
    async hide() {
      this.unavailable("not available for web");
    }
  };
  var SystemBars = registerPlugin("SystemBars", {
    web: () => new SystemBarsPluginWeb()
  });

  // src/ble/protocol.js
  var OP = Object.freeze({ HELLO: 1, GET_STATE: 2, START_LOCAL: 3, PING: 4, SET_FACE: 5, ACK: 128, STATE: 129 });
  var UUIDS = Object.freeze({ service: "e7f1a000-1c9b-4a7e-9d2f-3b8c5e6f7a00", rx: "e7f1a000-1c9b-4a7e-9d2f-3b8c5e6f7a01", tx: "e7f1a000-1c9b-4a7e-9d2f-3b8c5e6f7a02" });
  function bytes(input) {
    if (!(input instanceof Uint8Array) && !Array.isArray(input)) throw new Error("Expected bytes");
    if ([...input].some((value) => !Number.isInteger(value) || value < 0 || value > 255)) throw new Error("Invalid byte");
    return Uint8Array.from(input);
  }
  function encodeRequest(opcode, sequence, payload = []) {
    const value = bytes(payload);
    if (!Number.isInteger(sequence) || sequence < 1 || sequence > 65535) throw new Error("Invalid sequence");
    if (![1, 2, 3, 4, 5, 6, 7, 16, 17, 18, 19].includes(opcode)) throw new Error("Unsupported request opcode");
    if (value.length > 12 || (opcode === 6 || opcode === 7) && value.length !== 0 || opcode === 16 && value.length !== 9 || opcode === 17 && (value.length < 4 || value.length > 12) || opcode === 18 && value.length !== 2 || opcode === 19 && value.length !== 2) throw new Error("Invalid extension payload");
    if (opcode <= 3 && value.length !== 0 || opcode === 4 && value.length > 10 || opcode === 5 && (value.length !== 1 || value[0] > 2)) throw new Error("Invalid request payload");
    const frame = new Uint8Array(20);
    frame.set([66, 74, 1, opcode, sequence & 255, sequence >> 8, value.length, 0]);
    frame.set(value, 8);
    return frame;
  }
  function decodeFrame(input) {
    const frame = bytes(input);
    if (frame.length !== 20 || frame[0] !== 66 || frame[1] !== 74 || frame[2] !== 1 || frame[7] !== 0 || frame[6] > 12 || frame.slice(8 + frame[6]).some((value) => value !== 0)) throw new Error("Malformed BLE local v1 frame");
    const sequence = frame[4] | frame[5] << 8;
    const payload = frame.slice(8, 8 + frame[6]);
    if (frame[3] === OP.ACK) {
      if (sequence === 0 || payload.length < 2 || ![1, 2, 3, 4, 5, 6, 7, 16, 17, 18, 19].includes(payload[0]) || payload[1] > 4) throw new Error("Malformed ACK");
      return { type: "ack", sequence, originalOpcode: payload[0], status: payload[1], data: payload.slice(2) };
    }
    if (frame[3] === OP.STATE && sequence === 0 && payload.length === 10) return { type: "state", state: decodeState(payload) };
    throw new Error("Unexpected inbound opcode or sequence");
  }
  function decodeHello(input) {
    const value = bytes(input);
    if (value.length !== 8 || value[0] !== 1 || value[1] !== 15) throw new Error("Unsupported HELLO version/capabilities");
    return { version: value[0], capabilities: value[1], mac: [...value.slice(2)].map((byte) => byte.toString(16).padStart(2, "0")).join(":") };
  }
  function decodeState(input) {
    const value = bytes(input);
    if (value.length !== 10 || value[3] > 15 || value[4] > 2 || value[5] > 100 && value[5] !== 255 || value[6] > 2 || ![0, 1, 255].includes(value[7])) throw new Error("Malformed device state");
    return { screen: value[0], step: value[1], phase: value[2], flags: { local: !!(value[3] & 1), authenticated: !!(value[3] & 2), tutorial: !!(value[3] & 4), suspended: !!(value[3] & 8) }, face: value[4], battery: value[5] === 255 ? null : value[5], power: ["unknown", "normal", "low"][value[6]], usb: value[7] === 255 ? null : value[7] === 1, revision: value[8] | value[9] << 8 };
  }
  function encodeBase64(input) {
    return btoa(String.fromCharCode(...bytes(input)));
  }
  function decodeBase64(input) {
    return Uint8Array.from(atob(input), (value) => value.charCodeAt(0));
  }

  // src/ble/client.js
  var BleLocalClient = class {
    constructor(transport, { timeoutMs = 5e3, onChange = () => {
    } } = {}) {
      this.transport = transport;
      this.timeoutMs = timeoutMs;
      this.onChange = onChange;
      this.generation = null;
      this.sequence = 0;
      this.pending = null;
      this.listeners = [];
      this.isReady = false;
      this.isInitializing = false;
      this.hello = null;
      this.state = null;
      this.disposed = false;
    }
    async initialize() {
      for (const [name, callback] of [["frame", (event) => this.handleFrame(event)], ["connection", (event) => this.handleConnection(event)], ["device", (event) => this.onChange({ type: "device", ...event })]]) {
        const listener = await this.transport.addListener(name, callback);
        if (this.disposed) await listener.remove();
        else this.listeners.push(listener);
      }
    }
    handleConnection(event) {
      if (this.disposed) return;
      if (event.state !== "ready") {
        this.invalidate("BLE session ended; a mutation result may be unknown");
        this.onChange({ type: "connection", ...event });
        return;
      }
      this.onChange({ type: "connection", ...event });
      if (this.generation === event.generation && (this.isReady || this.isInitializing)) return;
      this.invalidate("New BLE session");
      this.generation = event.generation;
      this.sequence = 0;
      this.isInitializing = true;
      const token = this.generation;
      void (async () => {
        try {
          const hello = decodeHello(await this.request(OP.HELLO, [], true));
          const state = decodeState(await this.request(OP.GET_STATE, [], true));
          if (this.generation !== token) return;
          this.hello = hello;
          this.isReady = true;
          this.isInitializing = false;
          this.onChange({ type: "ready", hello, state: this.acceptState(state) });
        } catch (error) {
          if (this.generation !== token) return;
          this.onChange({ type: "error", message: error.message });
          void this.disconnect();
        }
      })();
    }
    invalidate(reason) {
      this.generation = null;
      this.isReady = false;
      this.isInitializing = false;
      this.hello = null;
      this.state = null;
      if (this.pending) this.settle(this.pending, new Error(reason));
    }
    settle(pending, error, result) {
      if (this.pending !== pending) return;
      clearTimeout(pending.timer);
      this.pending = null;
      if (error) pending.reject(error);
      else pending.resolve(result);
    }
    handleFrame(event) {
      if (this.disposed || event.generation !== this.generation) return;
      let frame;
      try {
        frame = decodeFrame(decodeBase64(event.value));
      } catch (error) {
        this.onChange({ type: "protocolError", message: error.message });
        return;
      }
      if (frame.type === "state") {
        this.acceptState(frame.state);
        return;
      }
      const pending = this.pending;
      if (!pending || frame.sequence !== pending.sequence || frame.originalOpcode !== pending.opcode) return;
      if (frame.status !== 0) {
        this.settle(pending, new Error(`Device rejected opcode ${pending.opcode}: status ${frame.status}`));
        return;
      }
      try {
        if (pending.opcode === OP.HELLO) decodeHello(frame.data);
        if (pending.opcode === OP.GET_STATE) decodeState(frame.data);
        if (pending.opcode === OP.PING && (frame.data.length !== pending.payload.length || frame.data.some((value, index) => value !== pending.payload[index]))) throw new Error("PING echo mismatch");
        pending.ack = frame.data;
        if (pending.written) this.settle(pending, null, frame.data);
      } catch (error) {
        this.settle(pending, error);
      }
    }
    request(opcode, payload = [], internal = false) {
      if (this.disposed || this.generation === null || !internal && !this.isReady) return Promise.reject(new Error("BLE local handshake is not ready"));
      if (this.pending) return Promise.reject(new Error("Wait for the pending command"));
      if (this.sequence >= 65535) return Promise.reject(new Error("Sequence exhausted; disconnect and reconnect before sending more commands"));
      const value = bytes(payload);
      const sequence = this.sequence + 1;
      const frame = encodeRequest(opcode, sequence, value);
      this.sequence = sequence;
      const generation = this.generation;
      return new Promise((resolve, reject) => {
        const pending = { opcode, sequence, payload: value, resolve, reject, written: false, ack: null, timer: null };
        this.pending = pending;
        pending.timer = setTimeout(() => {
          this.settle(pending, new Error("Application ACK timed out; mutation outcome is unknown. No command was retried."));
        }, this.timeoutMs);
        void this.transport.write({ generation, value: encodeBase64(frame) }).then((result) => {
          if (this.pending !== pending || this.generation !== generation) return;
          if (result.generation !== generation) {
            this.settle(pending, new Error("Stale write completion"));
            return;
          }
          pending.written = true;
          if (pending.ack !== null) this.settle(pending, null, pending.ack);
        }).catch((error) => this.settle(pending, error));
      });
    }
    acceptState(state) {
      const delta = this.state === null ? null : state.revision - this.state.revision & 65535;
      if (delta === null || delta > 0 && delta < 32768) {
        this.state = state;
        this.onChange({ type: "state", state });
      }
      return this.state;
    }
    async getState() {
      const token = this.generation;
      const state = decodeState(await this.request(OP.GET_STATE));
      if (token !== this.generation) throw new Error("State belongs to an ended session");
      return this.acceptState(state);
    }
    async disconnect() {
      this.invalidate("Manual disconnect; automatic reconnect stopped");
      await this.transport.disconnect();
    }
    async dispose() {
      this.disposed = true;
      this.invalidate("Client disposed");
      await Promise.all(this.listeners.splice(0).map((listener) => listener.remove()));
      await this.transport.disconnect();
    }
  };

  // src/ble/panel.js
  var text = Object.freeze({ unsupported: "\u7F51\u9875\u9884\u89C8\u4E0D\u8C03\u7528\u84DD\u7259\uFF1B\u8BF7\u5B89\u88C5 Android APK \u540E\u6D4B\u8BD5\u3002", disconnected: "\u5DF2\u65AD\u5F00\uFF0C\u81EA\u52A8\u91CD\u8FDE\u5DF2\u505C\u6B62\u3002", empty: "\u6682\u65E0\u8BBE\u5907\uFF0C\u8BF7\u5148\u626B\u63CF\u3002", unnamed: "\u672A\u547D\u540D\u8BBE\u5907", scanning: "\u6B63\u5728\u626B\u63CF\uFF0C\u6700\u591A 8 \u79D2\u2026", scanDone: "\u626B\u63CF\u5DF2\u7ED3\u675F\u3002\u8BF7\u9009\u62E9\u8BBE\u5907\u3002", permissionGranted: "\u6743\u9650\u5DF2\u5141\u8BB8\uFF0C\u8BF7\u626B\u63CF\u8BBE\u5907\u3002", permissionDenied: "\u84DD\u7259\u6743\u9650\u672A\u5141\u8BB8\uFF1B\u8BF7\u5728\u7CFB\u7EDF\u8BBE\u7F6E\u4E2D\u6388\u6743\u3002", waiting: "\u6B63\u5728\u8FDE\u63A5\u3001\u8BA2\u9605 CCCD \u5E76\u6267\u884C HELLO + GET_STATE\u2026", ready: "\u672C\u5730\u534F\u8BAE\u5C31\u7EEA\uFF08\u4E0D\u662F\u8D26\u53F7\u8BA4\u8BC1\u6216\u8BBE\u5907\u7ED1\u5B9A\uFF09\u3002", commandDone: "\u5DF2\u6536\u5230\u540C\u5E8F\u53F7\u3001\u540C\u64CD\u4F5C\u7801\u7684\u5E94\u7528 ACK\u3002", noState: "\u5C1A\u672A\u6536\u5230\u8BBE\u5907\u72B6\u6001\u3002", working: "\u547D\u4EE4\u5904\u7406\u4E2D\uFF0C\u7B49\u5F85\u8BBE\u5907\u5E94\u7528 ACK\u2026", unexpected: "\u64CD\u4F5C\u5931\u8D25\uFF0C\u8BF7\u91CD\u8BD5\u3002" });
  var connectionLabels = Object.freeze({ connecting: "\u8FDE\u63A5\u4E2D\u2026", discovering: "\u53D1\u73B0 GATT \u670D\u52A1\u4E2D\u2026", subscribing: "\u8BA2\u9605 TX \u901A\u77E5\u4E2D\u2026", ready: "\u4F20\u8F93\u5C31\u7EEA\uFF0C\u534F\u8BAE\u63E1\u624B\u4E2D\u2026", disconnected: "\u8BBE\u5907\u5DF2\u65AD\u5F00\u3002", reconnecting: "\u6B63\u5728\u7B49\u5F85\u6709\u754C\u524D\u53F0\u91CD\u8FDE\u2026" });
  var plugin = registerPlugin("BleLocal");
  function mountPanel() {
    const get = (suffix) => document.getElementById(`ble-local-${suffix}`);
    const dialog = get("dialog");
    if (!dialog) return;
    const status = get("status");
    const error = get("error");
    const devices = get("device");
    const native = Capacitor.getPlatform() === "android" && Capacitor.isPluginAvailable("BleLocal");
    const commandButtons = ["state", "start", "send-ping", "send-face"].map(get);
    let scanning = false;
    let busy = false;
    let granted = false;
    let connected = false;
    const events = new AbortController();
    const client = new BleLocalClient(plugin, { onChange: handleChange });
    window.__companionBle = client;
    function controls() {
      get("permissions").disabled = !native || busy || scanning || connected;
      get("scan").disabled = !native || !granted || scanning || busy || connected;
      get("stop").disabled = !scanning;
      devices.disabled = scanning || connected || devices.options.length === 0 || !devices.value;
      get("connect").disabled = !native || busy || scanning || connected || !devices.value;
      get("disconnect").disabled = !native;
      for (const button of commandButtons) button.disabled = !client.isReady || busy;
    }
    function renderState() {
      get("readout").textContent = client.state ? JSON.stringify({ localIdentityNotBinding: client.hello, state: client.state }, null, 2) : text.noState;
    }
    function handleChange(event) {
      if (event.type === "device") {
        let option = [...devices.options].find((item) => item.value === event.address);
        if (!option) {
          if (devices.options.length === 1 && !devices.options[0].value) devices.replaceChildren();
          option = document.createElement("option");
          option.value = event.address;
          devices.append(option);
        }
        option.textContent = `${event.name || text.unnamed} \xB7 ${event.address} \xB7 ${event.rssi} dBm`;
      } else if (event.type === "connection") {
        connected = ["connecting", "discovering", "subscribing", "ready", "reconnecting"].includes(event.state);
        status.textContent = connectionLabels[event.state] || event.state;
        if (event.reason && event.state === "disconnected") error.textContent = event.reason;
        renderState();
      } else if (event.type === "ready") {
        status.textContent = text.ready;
        connected = true;
        renderState();
      } else if (event.type === "state") renderState();
      else if (event.type === "error" || event.type === "protocolError") error.textContent = event.message;
      controls();
    }
    async function run(action, message = text.working) {
      busy = true;
      error.textContent = "";
      status.textContent = message;
      controls();
      try {
        await action();
      } catch (failure) {
        error.textContent = failure?.message || text.unexpected;
      } finally {
        busy = false;
        controls();
      }
    }
    const on = (suffix, action) => get(suffix).addEventListener("click", action, { signal: events.signal });
    on("open", () => {
      dialog.showModal();
      controls();
      if (!native) status.textContent = text.unsupported;
    });
    dialog.querySelector(".close-button").addEventListener("click", () => dialog.close(), { signal: events.signal });
    dialog.addEventListener("close", () => {
      if (native) void run(async () => {
        await client.disconnect();
        connected = false;
        status.textContent = text.disconnected;
        renderState();
      });
      get("open").focus();
    }, { signal: events.signal });
    on("permissions", () => void run(async () => {
      const result = await plugin.requestBlePermissions();
      granted = result.granted;
      status.textContent = granted ? text.permissionGranted : text.permissionDenied;
    }));
    on("scan", () => void run(async () => {
      scanning = true;
      devices.replaceChildren(new Option(text.empty, ""));
      controls();
      try {
        await plugin.scan({ durationMs: 8e3 });
        status.textContent = text.scanDone;
      } finally {
        scanning = false;
        controls();
      }
    }, text.scanning));
    on("stop", () => void plugin.stopScan().catch((failure) => {
      error.textContent = failure.message;
    }));
    devices.addEventListener("change", controls, { signal: events.signal });
    on("connect", () => void run(async () => {
      await plugin.connect({ address: devices.value });
    }, text.waiting));
    on("disconnect", () => void run(async () => {
      await client.disconnect();
      connected = false;
      status.textContent = text.disconnected;
      renderState();
    }));
    on("state", () => void run(async () => {
      await client.getState();
      status.textContent = text.commandDone;
    }));
    on("start", () => void run(async () => {
      await client.request(OP.START_LOCAL);
      await client.getState();
      status.textContent = text.commandDone;
    }));
    on("send-ping", () => void run(async () => {
      await client.request(OP.PING, new TextEncoder().encode(get("ping").value));
      status.textContent = text.commandDone;
    }));
    on("send-face", () => void run(async () => {
      await client.request(OP.SET_FACE, [Number(get("face").value)]);
      await client.getState();
      status.textContent = text.commandDone;
    }));
    controls();
    if (native) void client.initialize().catch((failure) => {
      error.textContent = failure.message;
    });
    window.addEventListener("pagehide", () => {
      events.abort();
      if (native) void client.dispose().catch(() => {
      });
    }, { once: true });
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", mountPanel, { once: true });
  else mountPanel();
})();
/*! Bundled license information:

@capacitor/core/dist/index.js:
  (*! Capacitor: https://capacitorjs.com/ - MIT License *)
*/
